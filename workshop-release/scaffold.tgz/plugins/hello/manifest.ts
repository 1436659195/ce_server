import type { PluginManifest } from '@core/contract';

/** 集装箱冒烟件:打包脚本自动生成到暂存树,验证 SDK 闭包自洽,不随 tgz 上架。 */
export const helloManifest: PluginManifest = {
  id: 'hello',
  version: '0.0.1',
  name: '冒烟',
  icon: 'puzzle',
  capabilities: [],
  permissions: {},
  scope: 'global',
};
