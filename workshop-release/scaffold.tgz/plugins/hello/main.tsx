import { Button, Text, showToast, downloadToCache } from '@core/shared';

/** 冒烟 UI:组件链(Button/Text)+ toast 链(showToast→Toaster)+ cap 桩链(downloadToCache)。 */
export default function Hello() {
  return (
    <div className="flex flex-col gap-2 p-4">
      <Text>工坊冒烟插件</Text>
      <Button onPress={() => showToast('ok')}>ping</Button>
    </div>
  );
}
void downloadToCache;
