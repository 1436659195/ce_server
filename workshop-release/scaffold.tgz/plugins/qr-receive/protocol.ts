/**
 * 扫传协议 v1 —— 纯视觉文件传输的编码 / 解码(spec 见本目录 PROTOCOL.md,唯一权威)。
 *
 * 设计约束:
 * - 零依赖、纯函数 / 自包含类(iframe 沙箱、测试、发码页移植都不受限)。
 * - 帧文本全 ASCII(base64),jsQR 解码无编码歧义。
 * - LT fountain:任意 K(1+ε) 个不重复数据帧即可还原,容忍漏扫 / 乱序 / 重复 / 中途加入。
 * - 收发两端确定性一致:PRNG = mulberry32(seed),度数与块下标只由 (seed, K) 推导。
 *
 * 这里同时实现 encoder(供测试 roundtrip 与将来 in-app 发送)与 decoder(插件接收用);
 * tools/qr-send.html 内联同算法的 JS 移植,改动必须同步 PROTOCOL.md 与两端。
 */

// ─── 常量(两端契约,改 = 协议 v2)──────────────────────────────────────
/** 协议魔征(帧文本前缀) */
export const MAGIC = 'CEQR1';
/** 每块原始字节数(base64 后数据帧 payload ≈ 660 字符 → QR EC-M v15~16) */
export const CHUNK_BYTES = 480;
/** 单文件硬上限(接收端不信头帧,超了直接终态报错) */
export const MAX_FILE_BYTES = 2 * 1024 * 1024;
/** 头帧未到时,先到的数据帧最多缓冲这么多(防恶意 / 错扫撑爆内存) */
export const MAX_PENDING_FRAMES = 30000;

/** 头帧 JSON 形状(envelope 全 ASCII,可序列化) */
export interface FileMeta {
  v: 1;
  /** 原始文件名(接收端 basename 消毒) */
  name: string;
  /** 文件总字节 */
  size: number;
  /** 全文件 CRC32(十六进制字符串,显式表达「校验和」而非任意 int) */
  crc32: string;
  /** 每块字节数(必须 === CHUNK_BYTES,防两端参数漂移) */
  chunk: number;
}

// ─── 基础原语 ────────────────────────────────────────────────────────

/** mulberry32:32 位确定性 PRNG(两端逐位一致,勿动) */
export function mulberry32(seed: number): () => number {
  let a = seed >>> 0;
  return () => {
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

/** CRC32(IEEE 802.3 多项式,查表法)。返回十六进制字符串(8 位,小写)。 */
export function crc32(bytes: Uint8Array): string {
  let c = ~0;
  for (let i = 0; i < bytes.length; i++) {
    c = CRC_TABLE[(c ^ bytes[i]) & 0xff] ^ (c >>> 8);
  }
  return (~c >>> 0).toString(16).padStart(8, '0');
}

const CRC_TABLE = (() => {
  const t = new Uint32Array(256);
  for (let n = 0; n < 256; n++) {
    let c = n;
    for (let k = 0; k < 8; k++) c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1;
    t[n] = c >>> 0;
  }
  return t;
})();

/** 字节 → base64(atob 手写,无 Node 依赖,iframe / WebView 通用) */
export function bytesToB64(bytes: Uint8Array): string {
  let s = '';
  for (let i = 0; i < bytes.length; i++) s += String.fromCharCode(bytes[i]);
  return btoa(s);
}

/** base64 → 字节 */
export function b64ToBytes(b64: string): Uint8Array {
  const s = atob(b64);
  const out = new Uint8Array(s.length);
  for (let i = 0; i < s.length; i++) out[i] = s.charCodeAt(i);
  return out;
}

/** 文件名消毒:去路径分隔符,空 / 「.」/「..」兜底为 'received' */
export function sanitizeName(name: string): string {
  const base = name.split(/[\\/]/).pop() ?? '';
  const trimmed = base.replace(/[\u0000-\u001f]/g, '').trim();
  return trimmed === '' || trimmed === '.' || trimmed === '..' ? 'received' : trimmed;
}

// ─── 帧文本层 ────────────────────────────────────────────────────────

/** 编码头帧文本 */
export function encodeHeader(meta: FileMeta): string {
  return `${MAGIC}:H:${bytesToB64(new TextEncoder().encode(JSON.stringify(meta)))}`;
}

/** 编码数据帧文本(envelope = seed u32 LE + 块字节) */
export function encodeData(seed: number, block: Uint8Array): string {
  const env = new Uint8Array(4 + block.length);
  new DataView(env.buffer).setUint32(0, seed, true);
  env.set(block, 4);
  return `${MAGIC}:D:${bytesToB64(env)}`;
}

/** 解析一帧文本。非本协议 / 结构坏 → null(调用方静默丢弃)。 */
export function parseFrame(text: string): { kind: 'header'; meta: FileMeta } | { kind: 'data'; seed: number; block: Uint8Array } | null {
  if (!text.startsWith(MAGIC + ':')) return null;
  const kind = text[6];
  const b64 = text.slice(8);
  if (kind === 'H') {
    try {
      const meta = JSON.parse(new TextDecoder().decode(b64ToBytes(b64))) as FileMeta;
      if (meta.v !== 1 || typeof meta.size !== 'number' || typeof meta.chunk !== 'number') return null;
      return { kind: 'header', meta };
    } catch {
      return null;
    }
  }
  if (kind === 'D') {
    try {
      const env = b64ToBytes(b64);
      if (env.length < 5) return null; // seed(4) + 至少 1 字节数据;块长是否 == CHUNK_BYTES 由解码器把关
      const seed = new DataView(env.buffer, env.byteOffset, env.byteLength).getUint32(0, true);
      return { kind: 'data', seed, block: env.subarray(4) };
    } catch {
      return null;
    }
  }
  return null;
}

// ─── LT fountain ─────────────────────────────────────────────────────

/** 度数上限:截断 robust soliton 长尾,采样与解码都便宜(d 大贡献趋零) */
export const MAX_DEGREE = 64;

/**
 * 简化 robust soliton:理想孤子 + d=1 与 d=K/σ 两个尖峰,归一化后截断到 [1, min(K, MAX_DEGREE)]。
 * 小文件(K 小)时 d=1/2 占比高 → peeling 快;这正是「度 1 帧 ≈ systematic」的来源。
 */
function sampleDegree(K: number, rng: () => number): number {
  if (K === 1) return 1;
  const c = 0.1;
  const delta = 0.05;
  const R = Math.max(1, Math.round(c * Math.log(K / delta) * Math.sqrt(K))); // 尖峰位置 ≈ K/R
  // τ 表(只算一次的上限,K ≤ ~4500 → O(K) 可接受,但度数采样每帧都要 → 缓存分布表)
  const dist = degreeDistribution(K, delta, R);
  const r = rng();
  let acc = 0;
  for (let d = 1; d < dist.length; d++) {
    acc += dist[d];
    if (r < acc) return d;
  }
  return dist.length - 1;
}

/** 归一化度数分布表(下标 = 度数;截断重归一化)。按 K 缓存(K 只有头帧后一个值)。 */
const distCache = new Map<number, Float64Array>();
function degreeDistribution(K: number, delta: number, R: number): Float64Array {
  const cached = distCache.get(K);
  if (cached) return cached;
  const maxD = Math.min(K, MAX_DEGREE);
  const mu = new Float64Array(maxD + 1);
  let Z = 0;
  for (let d = 1; d <= maxD; d++) {
    // 理想孤子 ν
    let nu = d === 1 ? 1 / K : 1 / (d * (d - 1));
    // 尖峰 τ
    let tau = 0;
    const iKR = Math.floor(K / R);
    if (d === iKR && iKR > 0) tau = (R * Math.log(delta)) / K; // 负值:robust soliton 允许 μ<0 的项置 0
    else if (d > 0 && d < iKR) tau = R / (d * K);
    mu[d] = Math.max(0, nu + tau);
    Z += mu[d];
  }
  for (let d = 1; d <= maxD; d++) mu[d] /= Z;
  distCache.set(K, mu);
  return mu;
}

/** 从 rng 采 d 个互异下标(拒绝采样;d ≤ MAX_DEGREE << K,期望重试可忽略) */
function sampleIndices(K: number, d: number, rng: () => number): number[] {
  const set = new Set<number>();
  while (set.size < d) set.add(Math.floor(rng() * K));
  return [...set];
}

/** 由 (seed, K) 确定性推导度数与下标 —— 收发两端唯一真源,勿动。 */
export function blockNeighbors(seed: number, K: number): number[] {
  const rng = mulberry32(seed);
  const d = sampleDegree(K, rng);
  return sampleIndices(K, d, rng);
}

/** 发送端:对 chunks 做 XOR 得 fountain 块 */
function xorChunks(chunks: Uint8Array[], indices: number[]): Uint8Array {
  const out = new Uint8Array(CHUNK_BYTES);
  for (const i of indices) {
    const c = chunks[i];
    for (let j = 0; j < CHUNK_BYTES; j++) out[j] ^= c[j];
  }
  return out;
}

// ─── encoder(测试 roundtrip / 将来 in-app 发送用)─────────────────────

export function makeFileMeta(name: string, bytes: Uint8Array): FileMeta {
  return { v: 1, name, size: bytes.length, crc32: crc32(bytes), chunk: CHUNK_BYTES };
}

/**
 * 帧生成器:逐个产出帧文本(seed 从 1 递增,天然不重复)。
 * 头帧插播策略(每 HEADER_EVERY 帧 1 次)是发送端策略,接收端无感知;这里给循环发送的完整序列。
 */
export function* encodeFrames(name: string, bytes: Uint8Array, headerEvery = 16): Generator<string> {
  if (bytes.length > MAX_FILE_BYTES) throw new Error(`超过单文件上限 ${MAX_FILE_BYTES} 字节`);
  const meta = makeFileMeta(name, bytes);
  const K = Math.ceil(bytes.length / CHUNK_BYTES) || 1; // 空文件 K=1(全零块),size=0 校验收口
  const chunks: Uint8Array[] = [];
  for (let i = 0; i < K; i++) {
    const c = new Uint8Array(CHUNK_BYTES);
    c.set(bytes.subarray(i * CHUNK_BYTES, (i + 1) * CHUNK_BYTES));
    chunks.push(c);
  }
  let seed = 0;
  let sinceHeader = headerEvery; // 首帧就是头帧
  for (;;) {
    seed++;
    if (sinceHeader >= headerEvery) {
      yield encodeHeader(meta);
      sinceHeader = 0;
    }
    sinceHeader++;
    yield encodeData(seed, xorChunks(chunks, blockNeighbors(seed, K)));
  }
}

// ─── decoder(插件接收用)──────────────────────────────────────────────

export type FeedResult =
  | { kind: 'ignored' } // 非本协议 / 坏帧 / 重复帧
  | { kind: 'header'; meta: FileMeta }
  | { kind: 'progress'; have: number; need: number }
  | { kind: 'done'; meta: FileMeta; bytes: Uint8Array }
  | { kind: 'error'; message: string }; // 终态:后续 feed 一律 ignored

/**
 * peeling 解码器。
 *
 * 状态:decoded[i](已解出的块)+ 未定帧(degree>1,持 XOR 数据)。度 1 帧直接解出块,
 * 再把该块从所有含它的未定帧里消掉;消到度 1 的帧进 ripple 迭代。重复帧按 seed 去重。
 * 头帧未到时先缓冲数据帧(封顶 MAX_PENDING_FRAMES,溢出报错 —— 现实中头帧 16 帧内必到)。
 */
export class QrReceiver {
  private meta: FileMeta | null = null;
  private K = 0;
  private decoded: Uint8Array[] = [];
  private decodedCount = 0;
  private seen = new Set<number>();
  private pending = new Map<number, Uint8Array>(); // 头帧前的数据帧
  private frames = new Map<number, { indices: number[]; data: Uint8Array }>(); // 未定帧(seed → )
  private byIndex = new Map<number, Set<number>>(); // 块下标 → 含它的未定帧 seed 集
  private terminal: string | null = null;

  get header(): FileMeta | null {
    return this.meta;
  }

  /** 收一帧(jsQR 解出的文本)。幂等安全,非本协议帧静默忽略。 */
  feed(text: string): FeedResult {
    if (this.terminal) return { kind: 'ignored' };
    const frame = parseFrame(text);
    if (!frame) return { kind: 'ignored' };

    if (frame.kind === 'header') return this.onHeader(frame.meta);
    if (!this.meta) {
      if (this.pending.size >= MAX_PENDING_FRAMES) return this.fail('头帧未到而数据帧溢出(请对准发送屏)');
      this.pending.set(frame.seed, frame.block);
      return { kind: 'ignored' };
    }
    return this.onData(frame.seed, frame.block);
  }

  private onHeader(meta: FileMeta): FeedResult {
    if (this.meta) {
      // 已有头帧:同文件重复头帧忽略,不同文件(发码页换了文件)报终态让用户重开
      if (meta.crc32 === this.meta.crc32 && meta.size === this.meta.size) return { kind: 'ignored' };
      return this.fail('检测到另一个文件的帧(发送端已换文件?)请重新开始接收');
    }
    if (meta.size > MAX_FILE_BYTES) return this.fail(`文件 ${meta.size} 字节,超过上限 ${MAX_FILE_BYTES}`);
    if (meta.chunk !== CHUNK_BYTES) return this.fail(`头帧 chunk=${meta.chunk} 与本端 ${CHUNK_BYTES} 不一致(两端版本不匹配)`);
    this.meta = meta;
    this.K = Math.ceil(meta.size / CHUNK_BYTES) || 1;
    this.decoded = new Array(this.K).fill(null);
    // 回放缓冲的数据帧
    for (const [seed, block] of this.pending) this.onData(seed, block);
    this.pending.clear();
    return { kind: 'header', meta };
  }

  /** 尝试收一块。返回进度或完成(完成时内部做拼装 + CRC 校验)。 */
  private onData(seed: number, block: Uint8Array): FeedResult {
    if (this.seen.has(seed) || this.decodedCount === this.K) return { kind: 'ignored' };
    this.seen.add(seed);
    if (block.length !== CHUNK_BYTES) return this.progress(); // 坏块(长度不对)丢弃但不终态
    // 到达时就地消掉已解邻居的贡献(块到达晚于邻居解出,XOR 减掉;只过滤下标不减数据会污染解码)
    const indices: number[] = [];
    for (const i of blockNeighbors(seed, this.K)) {
      const d = this.decoded[i];
      if (d) {
        for (let j = 0; j < CHUNK_BYTES; j++) block[j] ^= d[j];
      } else {
        indices.push(i);
      }
    }
    if (indices.length === 0) return this.progress(); // 信息量全被已解块覆盖,正常现象
    if (indices.length === 1) {
      this.resolve(indices[0], block);
    } else {
      const entry = { indices, data: block };
      this.frames.set(seed, entry);
      for (const i of indices) {
        let s = this.byIndex.get(i);
        if (!s) this.byIndex.set(i, (s = new Set()));
        s.add(seed);
      }
    }
    return this.progress();
  }

  /** 解出块,并从含它的未定帧中消掉(peeling 核心)。显式工作栈,防长链递归爆栈。 */
  private resolve(initial: number, initialData: Uint8Array): void {
    const stack: Array<[number, Uint8Array]> = [[initial, initialData]];
    while (stack.length > 0) {
      const [i, data] = stack.pop()!;
      if (this.decoded[i]) continue;
      this.decoded[i] = data;
      this.decodedCount++;
      const seeds = this.byIndex.get(i);
      if (!seeds) continue;
      this.byIndex.delete(i);
      for (const s of seeds) {
        const f = this.frames.get(s);
        if (!f) continue;
        // 消块:XOR 掉已解数据,下标移除
        for (let j = 0; j < CHUNK_BYTES; j++) f.data[j] ^= data[j];
        f.indices = f.indices.filter((x) => x !== i);
        if (f.indices.length === 1) {
          this.frames.delete(s);
          if (!this.decoded[f.indices[0]]) stack.push([f.indices[0], f.data]);
        }
      }
    }
  }

  private progress(): FeedResult {
    if (this.decodedCount === this.K) return this.assemble();
    return { kind: 'progress', have: this.decodedCount, need: this.K };
  }

  /** 全块解出 → 拼装 → size/CRC 校验(不过 = 终态错误,不落盘) */
  private assemble(): FeedResult {
    const meta = this.meta!;
    const out = new Uint8Array(meta.size);
    for (let i = 0; i < this.K; i++) {
      const c = this.decoded[i];
      out.set(c!.subarray(0, Math.min(CHUNK_BYTES, meta.size - i * CHUNK_BYTES)), i * CHUNK_BYTES);
    }
    const checksum = crc32(out);
    if (checksum !== meta.crc32) {
      return this.fail(`CRC 校验不符(期望 ${meta.crc32},实得 ${checksum})`);
    }
    this.terminal = 'done'; // 成功也是终态:后续 feed 一律 ignored(UI 已拿全文件)
    return { kind: 'done', meta, bytes: out };
  }

  private fail(message: string): FeedResult {
    this.terminal = message;
    return { kind: 'error', message };
  }
}
