/**
 * 扫传接收插件入口 —— 导出 manifest。
 */
export { qrReceiveManifest } from './manifest';
