/**
 * 相机扫描循环 —— getUserMedia + zxing-wasm 逐帧解码(多码并行)。
 *
 * 为什么是 zxing-wasm 而不是 jsQR(QrPairing 用的):
 * - **一次返回图内所有码**(发码页一屏摆 N 个二维码,jsQR 每帧只吐 1 个,并行就白摆了);
 * - WASM 实现单帧 5–15ms(jsQR 50–150ms),解码不再是帧率瓶颈;
 * - 懒加载(zxing_reader.wasm ~1.1MB):动态 import 单独分包,不装插件 / 不开扫描不下载。
 *
 * 协议不变:每个二维码仍是一个独立协议帧,这里只负责把解出的文本逐个经 onText 吐给调用方。
 * 相机失败 / 组件卸载走 stop() 清理。
 */

export interface ScanHandle {
  stop(): void;
}

/**
 * 打开后置相机并进入 rAF 解码循环。
 *
 * @param video  已挂载的 <video>(srcObject 由本函数设置)
 * @param wasmUrl 解码引擎(zxing_reader.wasm)的 URL —— 工坊工件从 ctx.assets.url 取
 *                (format 2 资产包;2026-10-11 迁出 APK 内置,替代原 Vite ?url 资产)
 * @param onText 每解出一帧文本回调一次(一屏多码 → 一帧回调多次;重复帧去重归 QrReceiver 管)
 * @param onError 相机打开失败 / 播放失败(权限拒绝、无相机、引擎缺失等)
 */
export function startScan(
  video: HTMLVideoElement,
  wasmUrl: string,
  onText: (text: string) => void,
  onError: (err: Error) => void,
): ScanHandle {
  let stopped = false;
  let stream: MediaStream | null = null;
  let raf = 0;
  let busy = false; // 上一次 decode 未完不叠加(async 解码与 rAF 错拍,防积压)
  let canvas: HTMLCanvasElement | null = null;

  void (async () => {
    try {
      // 多码并行:整屏要装下 N 个码,分辨率按 1080p 要(720p 下 4 码时单码像素余量不足)
      stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: 'environment', width: { ideal: 1920 }, height: { ideal: 1080 } },
        audio: false,
      });
      if (stopped) {
        stream.getTracks().forEach((t) => t.stop());
        return;
      }
      video.srcObject = stream;
      await video.play();
      // 预热 wasm:立即实例化(fireImmediately)——下载 + 编译在此刻完成,失败直接走 onError 报错。
      // 此前只设 overrides 不实例化,真正的失败发生在首次解码且被静默吞掉,表现为「扫描无反应」
      // (真机踩坑:CSP script-src 'self' 拦 WebAssembly.instantiate,index.html 已加 'wasm-unsafe-eval')。
      const reader = await import('zxing-wasm/reader');
      await reader.prepareZXingModule({
        overrides: { locateFile: () => wasmUrl },
        fireImmediately: true,
      });
    } catch (e) {
      if (!stopped) {
        const msg = e instanceof Error ? e.message : String(e);
        onError(new Error(`解码器初始化失败:${msg}`));
      }
      return;
    }
    let decodeErrors = 0;
    const tick = (): void => {
      if (stopped) return;
      if (!busy) {
        busy = true;
        void decodeFrame(video, () => {
            if (!canvas) {
              canvas = document.createElement('canvas');
              canvas.width = video.videoWidth;
              canvas.height = video.videoHeight;
            }
            return canvas;
          })
          .then((texts) => {
            for (const t of texts) onText(t);
          })
          .catch((e) => {
            // 解码错误不吞:连续失败(3 次)按初始化失败口径上报,别让用户举着手机无反应地等
            if (++decodeErrors >= 3 && !stopped) {
              const msg = e instanceof Error ? e.message : String(e);
              onError(new Error(`解码连续失败:${msg}`));
            }
          })
          .finally(() => {
            busy = false;
          });
      }
      raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
  })();

  return {
    stop(): void {
      stopped = true;
      cancelAnimationFrame(raf);
      stream?.getTracks().forEach((t) => t.stop());
      video.srcObject = null;
    },
  };
}

/** 解当前视频帧,返回本帧解出的所有 QR 文本(无信号 / 无码 → 空数组;canvas 惰性创建且复用)。 */
async function decodeFrame(video: HTMLVideoElement, borrowCanvas: () => HTMLCanvasElement): Promise<string[]> {
  if (!video.videoWidth || !video.videoHeight) return [];
  const canvas = borrowCanvas();
  if (canvas.width !== video.videoWidth) canvas.width = video.videoWidth;
  if (canvas.height !== video.videoHeight) canvas.height = video.videoHeight;
  const ctx = canvas.getContext('2d', { willReadFrequently: true });
  if (!ctx) return [];
  ctx.drawImage(video, 0, 0);
  const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
  const { readBarcodesFromImageData } = await import('zxing-wasm/reader');
  const results = await readBarcodesFromImageData(imageData, {
    formats: ['QRCode'],
    maxNumberOfSymbols: 8, // 发码页最多 6 码,留余量
    tryDownscale: true, // 大帧先试缩图,提速
  });
  return results.map((r) => r.text);
}
