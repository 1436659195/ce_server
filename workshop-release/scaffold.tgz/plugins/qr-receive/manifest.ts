/**
 * 扫传接收插件 manifest —— 起家是全平台第一个「零能力插件」,现在多一道契约菜。
 *
 * 做两件事:摄像头扫另一设备屏幕上的动态二维码流(自定义扫传协议 v1,见 PROTOCOL.md)
 * 本地还原文件 → ① 写 Cache → 拉起系统分享(与「下载」相同的尾巴);② 经契约
 * request/saveToServer 移交底座「选服务器 → 选目录 → 上传」保存流(与系统分享/「打开方式」
 * 同一条流)。仍不碰被控机:唯一能力 op='request'(无路径/exec/网络权限,scope 不绑服务器);
 * 上传目标与目录由用户在平台 UI 里挑,插件零感知。
 *
 * 入口走 sessions(「+」菜单多一项「扫传接收」,占一个全屏 tab;fullscreen slot 没有打开入口,不可用)。
 */
import type { PluginManifest } from '@core/contract';

export const qrReceiveManifest: PluginManifest = {
  id: 'qr-receive',
  name: '扫传接收',
  version: '0.2.0',
  icon: 'scan',
  description:
    '摄像头扫动态二维码接收文件(≤2MB),可分享到其他 app,也可保存到服务器。离线视觉传输,不直碰被控机。',
  author: 'Coding Everywhere',
  date: '2026-08',
  usage:
    '电脑浏览器打开 tools/qr-send.html 选择文件播放动态二维码 → 手机终端 tab「+」→ 扫传接收 → 对准屏幕等待完成 → 分享 / 保存到服务器。',
  capabilities: ['request'],
  permissions: {},
  scope: 'global',
  contributes: {
    sessions: [
      {
        entry: 'receive', // main.tsx 里 export function receive(props: SessionProps)
        sessionType: 'qr-receive',
        label: '扫传接收',
        icon: 'scan',
        keyBar: false, // 无输入,不需要终端按键栏
        singleton: true, // 工具型会话全局一份:双开会各抢一路相机、帧被分抢,已存在时「+」直接切过去
      },
    ],
  },
};
