/**
 * 扫传接收插件 main.tsx —— entry='receive' → export function receive(props: SessionProps)。
 *
 * 态机:idle → scanning →(内部落盘)done / error。
 * - scanning:相机预览 + 扫描线动画;每帧文本喂 QrReceiver(协议解码,见 protocol.ts)。
 *   头帧到达 → 显示文件名/大小;进度 = 已解块 / 总块(K)。漏扫/乱序由协议容忍,UI 只管进度。
 * - done:两个尾巴 —— ① 写 Directory.Cache → 分享按钮拉起系统 Share(files: uri)
 *   (web 降级:Blob URL + <a download>);② 「保存到服务器」:经契约 request/saveToServer
 *   把字节移交底座保存流(选服务器/选目录/上传全在平台 UI,插件零感知 —— import barrier
 *   之下这是唯一通路)。字节留在 ref(≤2MB),再收一个时覆盖。
 * - error:协议终态(换文件/CRC 不符/超上限)或相机失败,红字 + 「重试」。
 *
 * 能力面:只用 op='request'(移交保存流);不直接读写被控机文件。SessionProps.persist/restore
 * 暂不用(断点续扫需要持久化已收帧,v1 不做,收不完就重来 —— fountain 下重扫成本可接受)。
 */
import { useCallback, useEffect, useRef, useState } from 'react';
import { Capacitor } from '@capacitor/core';
import { Filesystem, Directory } from '@capacitor/filesystem';
import { Share } from '@capacitor/share';
import type { SessionProps } from '@core/contract';
import { showToast } from '@core/shared';
import { QrReceiver, bytesToB64, sanitizeName, type FileMeta } from './protocol';
import { startScan, type ScanHandle } from './scan';

type Phase = 'idle' | 'scanning' | 'done' | 'error';

/** 完成后的落盘结果:native 为 Cache uri,web 为 Blob URL */
interface SaveResult {
  filename: string;
  size: number;
  uri?: string; // native:file:// Cache uri
  webUrl?: string; // web:blob: 下载链接
}

/** entry='receive':扫传接收会话组件。 */
export function receive(props: SessionProps): JSX.Element {
  const [phase, setPhase] = useState<Phase>('idle');
  const [meta, setMeta] = useState<FileMeta | null>(null);
  const [have, setHave] = useState(0);
  const [need, setNeed] = useState(0);
  const [saved, setSaved] = useState<SaveResult | null>(null);
  const [error, setError] = useState('');
  const [handingOff, setHandingOff] = useState(false); // 「保存到服务器」invoke 进行中
  /** 最近一次收到的完整字节(保存到服务器用;≤2MB,再收一个覆盖)。 */
  const lastBytesRef = useRef<{ name: string; bytes: Uint8Array } | null>(null);
  // 扫描活性统计:识别帧时间戳(ref 高频写,setState 按拍频刷,防每帧渲染)
  const [stats, setStats] = useState({ frames: 0, fps: 0, lastAt: 0 });
  const frameTimesRef = useRef<number[]>([]);
  const framesTotalRef = useRef(0);
  const lastAtRef = useRef(0);
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const handleRef = useRef<ScanHandle | null>(null);
  const receiverRef = useRef<QrReceiver | null>(null);

  const stopScan = useCallback((): void => {
    handleRef.current?.stop();
    handleRef.current = null;
  }, []);

  // 卸载兜底:停相机
  useEffect(() => () => stopScan(), [stopScan]);

  const start = (): void => {
    receiverRef.current = new QrReceiver();
    setMeta(null);
    setHave(0);
    setNeed(0);
    setSaved(null);
    setError('');
    frameTimesRef.current = [];
    framesTotalRef.current = 0;
    lastAtRef.current = 0;
    setStats({ frames: 0, fps: 0, lastAt: 0 });
    setPhase('scanning');
  };

  // scanning 态:统计 UI 按拍频刷(250ms),别跟着每帧 setState
  useEffect(() => {
    if (phase !== 'scanning') return;
    const t = window.setInterval(() => {
      // 近 4s 滑窗算识别帧率(多码并行一屏回调多次,就是「识别速率」);lastAt 单独记账,滑窗外也不丢
      const now = performance.now();
      frameTimesRef.current = frameTimesRef.current.filter((x) => now - x < 4000);
      setStats({ frames: framesTotalRef.current, fps: frameTimesRef.current.length / 4, lastAt: lastAtRef.current });
    }, 250);
    return () => window.clearInterval(t);
  }, [phase]);

  // scanning 态:video 已挂载 → 开相机进解码循环
  useEffect(() => {
    if (phase !== 'scanning') return;
    const video = videoRef.current;
    if (!video) return;
    let alive = true;

    // 引擎 URL:工件附件(format 2 资产包)。宿主太老没有 ctx.assets → 显式报错不静默。
    const wasmUrl = props.ctx.assets?.url('zxing_reader.wasm') ?? null;
    if (!wasmUrl) {
      setError('宿主不支持工件附件(format 2),请升级 APP 后重试');
      setPhase('error');
      return;
    }
    handleRef.current = startScan(
      video,
      wasmUrl,
      (text) => {
        if (!alive) return;
        // 活性记账:无论是否协议帧(含重复帧),识别到就算「链路活着」
        framesTotalRef.current++;
        frameTimesRef.current.push(performance.now());
        lastAtRef.current = performance.now();
        const r = receiverRef.current?.feed(text);
        if (!r) return;
        if (r.kind === 'header') setMeta(r.meta);
        else if (r.kind === 'progress') {
          setHave(r.have);
          setNeed(r.need);
        } else if (r.kind === 'done') {
          stopScan();
          lastBytesRef.current = { name: sanitizeName(r.meta.name), bytes: r.bytes }; // 保存到服务器用
          void saveFile(sanitizeName(r.meta.name), r.bytes).then(
            (s) => alive && (setSaved(s), setPhase('done')),
            (e) => alive && (setError((e as Error).message), setPhase('error')),
          );
        } else if (r.kind === 'error') {
          stopScan();
          setError(r.message);
          setPhase('error');
        }
      },
      (e) => {
        if (!alive) return;
        setError(`相机不可用:${e.message}`);
        setPhase('error');
      },
    );

    return () => {
      alive = false;
      stopScan();
    };
  }, [phase, stopScan]);

  /** 「保存到服务器」:经契约 request/saveToServer 移交底座保存流(接单即返;后续选服务器/
   *  选目录/上传进度全在平台 UI)。失败(含保存流已打开)toast 提示,留在本页可重试。 */
  const handoffToServer = useCallback(async (): Promise<void> => {
    const last = lastBytesRef.current;
    if (!last || handingOff) return;
    setHandingOff(true);
    try {
      await props.ctx.rpc.invoke({
        op: 'request',
        kind: 'saveToServer',
        scope: { kind: 'global' },
        payload: { name: last.name, content: bytesToB64(last.bytes) },
      });
      showToast('已发起保存:在弹出的面板里选择服务器与目录');
    } catch (e) {
      showToast(`发起保存失败:${(e as Error).message}`, 'error');
    } finally {
      setHandingOff(false);
    }
  }, [handingOff, props.ctx]);

  const ratio = need > 0 ? have / need : 0;
  // 识别活性(渲染时判;stats 250ms 一刷,恰好带动重判)
  const aliveHint: 'receiving' | 'stale' | 'waiting' =
    stats.lastAt === 0 ? 'waiting' : performance.now() - stats.lastAt < 2500 ? 'receiving' : 'stale';
  // ETA:喷泉码实测 ε≈1(还需 ≈(need-have)*2 个有效帧),按近 4s 识别帧率折算
  const etaText =
    aliveHint === 'receiving' && stats.fps > 0 && need > 0
      ? formatEta(Math.max(Math.ceil(((need - have) * 2) / stats.fps), 1))
      : null;

  return (
    <div className="flex h-full flex-col bg-bg text-fg">
      {phase === 'idle' && (
        <div className="flex flex-1 flex-col items-center justify-center gap-4 p-6 text-center">
          <p className="text-[length:var(--fs-lg)] font-semibold">扫传接收</p>
          <p className="max-w-72 text-[length:var(--fs-sm)] leading-relaxed text-fg-muted">
            单文件 ≤ 2MB,适合密钥 / 配置 / 小文件;视觉传输约 1–2 KB/s,大文件请耐心。
          </p>
          <button
            className="h-11 rounded-[var(--radius-md)] bg-accent px-5 text-[length:var(--fs-base)] font-medium text-on-accent tap-scale"
            onClick={start}
          >
            开始扫描
          </button>
        </div>
      )}

      {phase === 'scanning' && (
        <div className="flex flex-1 flex-col items-center justify-center gap-4 p-6">
          <div className="relative aspect-3/4 w-full max-w-sm overflow-hidden rounded-[var(--radius-lg)] bg-black">
            {/* 相机画面由 startScan 挂 srcObject;muted+playsInline 是 WebView 自动播放的前提 */}
            <video ref={videoRef} className="h-full w-full object-cover" muted playsInline />
            {/* 取景框 */}
            <div className="pointer-events-none absolute inset-6 rounded-[var(--radius-md)] border-2 border-white/70" />
            {/* 扫描线 */}
            <div className="pointer-events-none absolute inset-x-6 top-1/2 h-0.5 animate-pulse bg-accent" />
          </div>

          {meta ? (
            <>
              <p className="text-[length:var(--fs-base)] font-medium">{sanitizeName(meta.name)}</p>
              <div className="h-2 w-full max-w-sm overflow-hidden rounded-full bg-elevated">
                <div className="h-full bg-accent transition-[width] duration-300" style={{ width: `${ratio * 100}%` }} />
              </div>
              <p className="text-[length:var(--fs-sm)] text-fg-muted">
                {Math.round(ratio * 100)}% · {have} / {need} 块 · {(meta.size / 1024).toFixed(1)} KB
              </p>
              {aliveHint === 'receiving' && etaText && (
                <p className="text-[length:var(--fs-sm)] text-fg">预计剩余 {etaText}(按当前识别速率)</p>
              )}
            </>
          ) : (
            <p className="text-[length:var(--fs-sm)] text-fg-muted">等待发送屏…对准动态二维码</p>
          )}

          {/* 识别活性:绿点呼吸 = 链路在收帧;2.5s 没解出任何码 → 提示调整 */}
          <div className="flex items-center gap-2 text-[length:var(--fs-sm)]">
            <span
              className={`inline-block h-2 w-2 rounded-full ${aliveHint === 'receiving' ? 'animate-pulse bg-accent' : aliveHint === 'stale' ? 'bg-danger' : 'bg-fg-muted'}`}
            />
            <span className={aliveHint === 'stale' ? 'text-danger' : 'text-fg-muted'}>
              {aliveHint === 'receiving'
                ? `识别中 · ${stats.fps.toFixed(1)} 帧/s · 已收 ${stats.frames} 帧`
                : aliveHint === 'stale'
                  ? '识别中断 · 对准屏幕 / 调整距离 / 避免反光'
                  : '尚未识别到二维码 · 对准发送屏'}
            </span>
          </div>

          <button
            className="text-[length:var(--fs-sm)] text-fg-muted underline underline-offset-4"
            onClick={() => {
              stopScan();
              setPhase('idle');
            }}
          >
            取消
          </button>
        </div>
      )}

      {phase === 'done' && saved && (
        <div className="flex flex-1 flex-col items-center justify-center gap-4 p-6 text-center">
          <p className="text-[length:var(--fs-lg)] font-semibold text-accent">接收完成</p>
          <p className="text-[length:var(--fs-base)] font-medium">{saved.filename}</p>
          <p className="text-[length:var(--fs-sm)] text-fg-muted">{(saved.size / 1024).toFixed(1)} KB · CRC 校验通过</p>
          {saved.uri ? (
            <button
              className="h-11 rounded-[var(--radius-md)] bg-accent px-5 text-[length:var(--fs-base)] font-medium text-on-accent tap-scale"
              onClick={() => void shareSaved(saved)}
            >
              分享文件
            </button>
          ) : (
            saved.webUrl && (
              <a
                className="h-11 rounded-[var(--radius-md)] bg-accent px-5 text-[length:var(--fs-base)] font-medium leading-[44px] text-on-accent tap-scale"
                href={saved.webUrl}
                download={saved.filename}
              >
                下载文件
              </a>
            )
          )}
          {/* 移交底座保存流(契约 request/saveToServer):native/web 均可用(web 走 dev 验证)。 */}
          <button
            className="h-11 rounded-[var(--radius-md)] bg-elevated px-5 text-[length:var(--fs-base)] font-medium text-fg tap-scale disabled:opacity-50"
            disabled={handingOff}
            onClick={() => void handoffToServer()}
          >
            {handingOff ? '正在发起…' : '保存到服务器'}
          </button>
          <button className="text-[length:var(--fs-sm)] text-fg-muted underline underline-offset-4" onClick={start}>
            再收一个
          </button>
        </div>
      )}

      {phase === 'error' && (
        <div className="flex flex-1 flex-col items-center justify-center gap-4 p-6 text-center">
          <p className="text-[length:var(--fs-base)] text-danger">{error}</p>
          <button
            className="h-11 rounded-[var(--radius-md)] bg-elevated px-5 text-[length:var(--fs-base)] font-medium text-fg tap-scale"
            onClick={start}
          >
            重试
          </button>
        </div>
      )}
    </div>
  );
}

/** 秒数 → 人话(90s 内直接秒,再往上 m 分 s 秒;1 小时以上用小时) */
function formatEta(sec: number): string {
  if (sec < 90) return `约 ${sec} 秒`;
  if (sec < 3600) return `约 ${Math.floor(sec / 60)} 分 ${sec % 60} 秒`;
  return `约 ${(sec / 3600).toFixed(1)} 小时`;
}

/** 完成后落盘:native 写 Cache(file:// uri 供 Share);web 降级 Blob URL。 */
async function saveFile(filename: string, bytes: Uint8Array): Promise<SaveResult> {
  if (Capacitor.isNativePlatform()) {
    // 不传 encoding = base64 语义(@capacitor/filesystem v6 约定,download.ts 同)
    const { uri } = await Filesystem.writeFile({
      path: filename,
      data: bytesToB64(bytes),
      directory: Directory.Cache,
      recursive: true,
    });
    return { filename, size: bytes.length, uri };
  }
  // Blob 要原始字节:拷出独立的 ArrayBuffer(Uint8Array 泛型带 ArrayBufferLike,BlobPart 不收)
  const buf = bytes.buffer.slice(bytes.byteOffset, bytes.byteOffset + bytes.byteLength) as ArrayBuffer;
  return { filename, size: bytes.length, webUrl: URL.createObjectURL(new Blob([buf])) };
}

/** 与「下载」相同的分享尾巴:以文件形式发出(微信等收到文件附件,非纯文本)。 */
async function shareSaved(saved: SaveResult): Promise<void> {
  if (!saved.uri) return;
  try {
    await Share.share({ dialogTitle: '扫传接收 · 分享文件', files: [saved.uri] });
  } catch {
    // 用户取消是正常行为,不提示
  }
}
