/**
 * diff 统计(+N −N)—— 手写 LCS 对齐行,零依赖(claudecodeui 同法,~60 行)。
 *
 * 用途:Edit/Write/MultiEdit 工具卡的改动规模徽章,折叠态一眼看出动了多少。
 * 只数 added/removed 行数,不产出逐行 diff(渲染仍用 @core/shared 的 DiffView)。
 *
 * 性能:O(n·m) 但输入天然是局部片段(Edit 的 old/new_string),不会大;
 * LRU 缓存挡住同参数重渲染(流式 tick / 状态翻转),键 = 内容 djb2 哈希(小且不撞)。
 */

export interface DiffStat {
  added: number;
  removed: number;
}

const CACHE_MAX = 100;
const cache = new Map<string, DiffStat>();

/** djb2 字符串哈希(32 位;只作缓存键,不作正确性依赖——碰撞再加长度已够低概率)。 */
function hash(s: string): string {
  let h = 5381;
  for (let i = 0; i < s.length; i++) h = ((h << 5) + h + s.charCodeAt(i)) | 0;
  return `${h.toString(36)}:${s.length}`;
}

function cached(oldText: string, newText: string, compute: () => DiffStat): DiffStat {
  const key = `${hash(oldText)}~${hash(newText)}`;
  const hit = cache.get(key);
  if (hit) return hit;
  const stat = compute();
  cache.set(key, stat);
  if (cache.size > CACHE_MAX) {
    // Map 迭代序 = 插入序:删最旧的一条(LRU 近似)
    const oldest = cache.keys().next().value;
    if (oldest !== undefined) cache.delete(oldest);
  }
  return stat;
}

/** 按行切:空串 = 0 行(不是 1 行空行);容忍 \r\n。 */
function toLines(text: string): string[] {
  if (text === '') return [];
  return text.replace(/\r\n/g, '\n').split('\n');
}

/** 统计 old → new 的增删行数。 */
export function diffStat(oldText: string, newText: string): DiffStat {
  return cached(oldText, newText, () => {
    const a = toLines(oldText);
    const b = toLines(newText);
    // 大输入护栏:LCS 表 O(n·m),1000×1000 行已是 4MB Uint32Array —— 超了退化成粗略计数
    // (整文件 Write/MegaEdit 场景;徽章只要量级感,不要逐行精确)。
    if (a.length * b.length > 1_000_000) {
      return { added: b.length, removed: a.length };
    }
    // LCS 表(倒序填表免递归;i*cols+j 压平成一维)
    const cols = b.length + 1;
    const lcs = new Uint32Array((a.length + 1) * cols);
    for (let i = a.length - 1; i >= 0; i--) {
      for (let j = b.length - 1; j >= 0; j--) {
        lcs[i * cols + j] =
          a[i] === b[j]
            ? lcs[(i + 1) * cols + j + 1] + 1
            : Math.max(lcs[(i + 1) * cols + j], lcs[i * cols + j + 1]);
      }
    }
    // 回溯数增删
    let added = 0;
    let removed = 0;
    let i = 0;
    let j = 0;
    while (i < a.length && j < b.length) {
      if (a[i] === b[j]) {
        i++;
        j++;
      } else if (lcs[(i + 1) * cols + j] >= lcs[i * cols + j + 1]) {
        removed++;
        i++;
      } else {
        added++;
        j++;
      }
    }
    removed += a.length - i;
    added += b.length - j;
    return { added, removed };
  });
}

/** MultiEdit 多段编辑合并统计(按序应用到 current 再统计下一段;edits 字段容错)。 */
export function diffStatMulti(
  oldText: string,
  edits: Array<{ old_string?: unknown; new_string?: unknown }>,
): DiffStat {
  let stat: DiffStat = { added: 0, removed: 0 };
  let current = oldText;
  for (const e of edits) {
    const oldStr = typeof e.old_string === 'string' ? e.old_string : '';
    const newStr = typeof e.new_string === 'string' ? e.new_string : '';
    const next = oldStr === '' ? current : current.replace(oldStr, newStr);
    const s = diffStat(current, next);
    stat = { added: stat.added + s.added, removed: stat.removed + s.removed };
    current = next;
  }
  return stat;
}
