/**
 * CC 对话插件入口 —— 导出 manifest。
 */
import manifest from './manifest';

export default manifest;
