/**
 * CC 对话窗口(终端式插件 session 组件,占整个 tab)。
 *
 * 数据流(happy-coder-analysis.md / plugin-architecture.md §3.2):
 *  - claude 由 **ce 端 Agent SDK runner** 结构化驱动(@anthropic-ai/claude-agent-sdk query();不开终端、不 parse TUI)。
 *  - agentEvents(ce→手机,AgentEvent 帧):text/thinking(含流式 delta)→ 文本气泡;tool-call-start/end → 工具卡;
 *    approval-request → 工具卡置待审 + 按钮;turn-end → 系统消息。
 *  - 用户输入:底部 input → write kind:'stdin'(terminalId=cc session sid)→ ce → agent InputQueue → claude 下一轮。
 *  - 审批:工具卡 允许/拒绝/拒绝并说明 → write kind:'resolveApproval'(reqId)→ ce → canUseTool 回传 → claude 继续。
 *  - 中断:主按钮空输入时变「停止」→ write kind:'agentInterrupt'(terminalId=cc sid)→ ce query.interrupt()(2026-10-01)。
 *
 * **不再订阅 terminalOutput / 不再 strip ANSI** —— claude 输出全是结构化事件,无 ANSI 噪声
 * (治旧版「TUI 输出乱码」根因;见 happy-coder-analysis.md §1)。
 *
 * 2026-10-01 打磨轮(对标 Happy / claudecodeui,「CC 插件粗糙」九连修):
 *  ① 状态条:运行中(脉冲点 + shimmer 动词 + 耗时)/ 等待审批(橙)/ 空闲隐藏 —— 「活着没」一眼可见。
 *  ② work group 折叠:历史轮的思考+工具卡收成「这轮干了 12s · 6 步 +86 −12」一行,可展开。
 *  ③ 降噪:完成态去徽章;Bash 输出折叠「N 行输出」;diff 卡 +N −N 统计;错误卡红边全显。
 *  ④ 图片:tool_result 的 image 块渲染成真图(点击全屏),不再 base64 天书。
 *  ⑤ 滚动:接近底部才吸底 + 「↓ 回到底部」浮钮(读历史不再被硬拽)。
 *  ⑥ 停止:发送/停止合一主按钮(Happy 同款);排队发消息 → 气泡半透明「本轮结束后发送」。
 *  ⑦ 复制:assistant 气泡复制小钮(√ 1.5s);user 气泡长按复制;触感反馈(Android)。
 *  ⑧ 审批回显:决策后按钮行保留、点过的亮其余淡化(Happy 选中回显)。
 *  ⑨ 持久化上限:500 条 + 大结果截断,防 localStorage 膨胀。
 *
 * UI(Apple 风):圆角卡片、用户/助手气泡区分、thinking 折叠;动效参数全部对标 Happy(见 ui.ts)。
 */
import { useEffect, useMemo, useReducer, useRef, useState } from 'react';
import { Button, ClaudeIcon, Markdown, Popover, showToast } from '@core/shared';
import {
  ArrowDown,
  ArrowUp,
  Bell,
  Check,
  ChevronDown,
  Copy,
  Folder,
  Loader,
  MoreHorizontal,
  PenLine,
  Square,
} from 'lucide-react';
import type { AgentModelInfo, SessionProps } from '@core/contract';
import { asAgentEvent, extractOptions, isEditTool } from './events';
import { answerTextOf, parseAskInput } from './askInput';
import { getToolMeta } from './knownTools';
import { ToolBody } from './views/_all';
import { StatusBar } from './views/StatusBar';
import { BashOutputView, ResultView, hasImageBlock } from './views/ResultView';
import {
  copyText,
  ensureConversationStyles,
  formatElapsed,
  formatTokens,
  hapticError,
  hapticLight,
} from './ui';
import { buildRenderItems, type RenderItem } from './renderItems';
import type { Filter } from './renderItems';
import {
  appendUserMessage,
  markAutoApproved,
  markToolCallDecision,
  reduceAgentEvent,
  settleQueuedUserMessages,
  type ConvMessage,
  type ToolCallMsg,
  type ToolState,
} from './conversation';

/** 插件 ctx 的类型(用索引访问,免直 import core 内部 PluginContext,守 import barrier)。 */
type Ctx = SessionProps['ctx'];

// ─── 会话态(reducer)+ 持久化迁移 ──────────────────────────────────────────────
/** 审批模式 —— 对齐 CC TUI 的 Shift+Tab 四档(命名与 SDK PermissionMode 一致):
 *  manual=default 逐个人审 / auto-edit=acceptEdits 改文件免批 / plan=只读规划 /
 *  yolo=bypassPermissions 全部免批(危险)。SDK 另有 dontAsk/auto,TUI 不暴露,此处不做。 */
type Mode = 'manual' | 'auto-edit' | 'plan' | 'yolo';

/** 手机档 → SDK PermissionMode(ce setMode 用)。 */
const MODE_TO_SDK: Record<Mode, 'default' | 'acceptEdits' | 'bypassPermissions' | 'plan'> = {
  manual: 'default',
  'auto-edit': 'acceptEdits',
  plan: 'plan',
  yolo: 'bypassPermissions',
};

/** UI 文案(档位名/说明/危险标)。 */
const MODE_LABEL: Record<Mode, { name: string; desc: string; danger?: boolean }> = {
  manual: { name: '默认(逐个审批)', desc: '每个敏感操作都问你 —— TUI 默认档' },
  'auto-edit': { name: '自动接受编辑', desc: '改文件免批,Bash 等仍问 —— TUI acceptEdits' },
  plan: { name: '计划模式', desc: '只读研究不改东西,出计划让你批 —— TUI plan' },
  yolo: { name: '绕过权限', desc: '全部免批,CC 不再请求任何确认 —— 危险', danger: true },
};

/** 开窗检测状态:exec claude auth status 判安装+登录。 */
type DetectStatus = 'detecting' | 'ready' | 'no-claude' | 'no-login' | 'error';

interface SessionState {
  messages: ConvMessage[];
  mode: Mode;
  filter: Filter;
  /** 当前回合开始时刻(null = 空闲)。任何 agent 事件置起、turn-end 清掉;状态条/停止按钮用。 */
  turnSince: number | null;
  /** 模型名(session-init,B 层 ce;老 ce 无 → undefined)。 */
  model?: string;
  /** 思考强度档(off/low/default/deep;default = 跟随会话)。手机记忆 + 推 ce。 */
  thinking: ThinkingLevel;
  /** 模型覆盖(undefined = 跟随底座)。手机记忆 + 推 ce。 */
  modelOverride?: string;
}

/** 思考强度 —— 官方 effort 档(applyFlagSettings 热切):off 关思考 / low·medium·high·xhigh /
 *  max(部分模型)/ default 清除覆盖回模型默认。模型不支持的档由 CC 静默降级。 */
type ThinkingLevel = 'off' | 'default' | 'low' | 'medium' | 'high' | 'xhigh' | 'max';

/** 官方 effort 档的 UI 文案(动态菜单按模型 supportedEffortLevels 过滤)。 */
const EFFORT_LABEL: Record<string, { name: string; desc: string }> = {
  off: { name: '关闭', desc: '不思考,最快最省' },
  low: { name: '低', desc: '轻量推敲,快' },
  medium: { name: '中', desc: '适中推理' },
  high: { name: '高', desc: '深度推理(模型默认)' },
  xhigh: { name: '超高', desc: '重度推理,需模型支持' },
  max: { name: '最大', desc: '顶级推理,仅部分模型' },
  default: { name: '跟随默认', desc: '清除覆盖,回模型默认档' },
};

/** 当前模型的 effort 档位(动态列表里找当前模型的 supportedEffortLevels;找不到给官方全集)。
 *  只保留已知档(数据来自 SDK,防未来新档炸 UI)。 */
function effortLevelsFor(list: AgentModelInfo[] | null, current: string | undefined): ThinkingLevel[] {
  const known: ThinkingLevel[] = ['low', 'medium', 'high', 'xhigh', 'max'];
  if (list && list.length > 0) {
    const hit =
      list.find((m) => m.value === current) ??
      list.find((m) => m.resolvedModel && m.resolvedModel === current) ??
      list.find((m) => m.supportsEffort === true);
    if (hit?.supportedEffortLevels?.length) {
      return hit.supportedEffortLevels.filter((lv): lv is ThinkingLevel => (known as string[]).includes(lv));
    }
  }
  return ['low', 'medium', 'high', 'xhigh'];
}

/** 模型快捷项(空 = 底座默认;别名走 CC 的 model 别名解析)。 */
const MODEL_CHOICES: Array<{ id: string; name: string; desc: string }> = [
  { id: '', name: '底座默认', desc: '跟随被控机 claude 的默认模型' },
  { id: 'opus', name: 'Opus', desc: '最强,最慢最贵 —— 深度任务' },
  { id: 'sonnet', name: 'Sonnet', desc: '均衡主力' },
  { id: 'haiku', name: 'Haiku', desc: '最快最省 —— 简单任务' },
];

type Action =
  | { type: 'event'; ev: unknown }
  | { type: 'user'; text: string }
  | { type: 'mark'; callId: string; decision: 'allow' | 'deny'; answers?: Record<string, string> }
  | { type: 'auto-approve'; reqId: string; callId: string; tool: string; input: Record<string, unknown> }
  | { type: 'set-mode'; mode: Mode }
  | { type: 'set-thinking'; level: ThinkingLevel }
  | { type: 'set-model'; model?: string }
  | { type: 'set-filter'; filter: Filter };

/** 兼容旧持久化(纯 messages 数组 / {messages,mode,filter})→ 新形状;非法字段兜底默认。 */
function migrateSession(raw: unknown): SessionState {
  if (Array.isArray(raw)) return { messages: raw as ConvMessage[], mode: 'manual', filter: 'all', turnSince: null, thinking: 'default' };
  if (raw && typeof raw === 'object') {
    const o = raw as Partial<SessionState>;
    return {
      messages: Array.isArray(o.messages) ? (o.messages as ConvMessage[]) : [],
      mode: o.mode === 'auto-edit' || o.mode === 'plan' || o.mode === 'yolo' ? o.mode : 'manual',
      filter: o.filter === 'writes' || o.filter === 'pending' ? o.filter : 'all',
      turnSince: null, // 恢复的历史一律空闲(真实状态由下个事件纠正)
      model: typeof o.model === 'string' ? o.model : undefined,
      thinking: ['off', 'low', 'medium', 'high', 'xhigh', 'max'].includes(o.thinking as string)
        ? ((o.thinking === 'low' ? 'low' : (o.thinking as ThinkingLevel)))
        : 'default',
      modelOverride: typeof o.modelOverride === 'string' && o.modelOverride !== '' ? o.modelOverride : undefined,
    };
  }
  return { messages: [], mode: 'manual', filter: 'all', turnSince: null, thinking: 'default' };
}

function sessionReducer(s: SessionState, a: Action): SessionState {
  switch (a.type) {
    case 'event': {
      const ev = asAgentEvent(a.ev);
      if (!ev) return s;
      let messages = reduceAgentEvent(s.messages, ev);
      let turnSince = s.turnSince;
      let model = s.model;
      if (ev.kind === 'turn-end') {
        turnSince = null;
        messages = settleQueuedUserMessages(messages); // 排队气泡归位(CC 已消费)
      } else if (ev.kind === 'session-init') {
        if (typeof (ev as { model?: unknown }).model === 'string') {
          model = (ev as { model: string }).model;
        }
      } else {
        // 任何非收尾事件都是「活着」的证据(deltas/工具/审批/子代理全算)
        turnSince = s.turnSince ?? Date.now();
      }
      return { ...s, messages, turnSince, model };
    }
    case 'user': {
      // 运行中发出 = 进 InputQueue 排队(气泡半透明「本轮结束后发送」);空闲 = 立即开新回合。
      const queued = s.turnSince !== null;
      return {
        ...s,
        messages: appendUserMessage(s.messages, a.text, queued),
        turnSince: s.turnSince ?? Date.now(),
      };
    }
    case 'mark':
      return { ...s, messages: markToolCallDecision(s.messages, a.callId, a.decision, a.answers) };
    case 'auto-approve':
      return {
        ...s,
        messages: markAutoApproved(s.messages, { reqId: a.reqId, callId: a.callId, tool: a.tool, input: a.input }),
      };
    case 'set-mode':
      return { ...s, mode: a.mode };
    case 'set-thinking':
      return { ...s, thinking: a.level };
    case 'set-model':
      return { ...s, modelOverride: a.model };
    case 'set-filter':
      return { ...s, filter: a.filter };
    default:
      return s;
  }
}

// ─── 子组件 ────────────────────────────────────────────────────────────────────

// 工具入参 / diff 渲染已抽到 views/(EditView/WriteView/MultiEditView/BashView/ReadQueryView/…),
// 由 ToolBody 按 tool 名分发(对标 Happy 的 ToolView + views/_all)。见上方 ToolCallCard 调用点。

/** 工具卡状态徽标。完成态零徽章(Happy:completed 无图标;badge 只在非完成态出现)。 */
function stateLabel(state: ToolState, isError?: boolean, autoApproved?: boolean): { text: string; cls: string } | null {
  switch (state) {
    case 'running':
      return autoApproved
        ? { text: '自动放行', cls: 'text-accent' }
        : { text: '执行中', cls: 'text-fg-muted' };
    case 'pending':
      return { text: '请求批准', cls: 'text-accent' };
    case 'denied':
      return { text: '已拒绝', cls: 'text-danger' };
    case 'completed':
      return isError ? { text: '出错', cls: 'text-danger' } : null;
  }
}

/** 运行中工具的秒表(1s 步进,mono;对标 Happy ElapsedView)。 */
function RunningElapsed({ since }: { since: number }) {
  const [, setTick] = useState(0);
  useEffect(() => {
    const t = setInterval(() => setTick((n) => n + 1), 1000);
    return () => clearInterval(t);
  }, []);
  return <span className="shrink-0 font-mono text-[length:var(--fs-xs)] text-fg-muted opacity-70">{formatElapsed(Date.now() - since)}</span>;
}

/** 折叠的读/查/命令摘要:N 条 → 一个可展开条目(活跃轮减噪)。 */
function ReadOpsSummary({ cards }: { cards: ToolCallMsg[] }) {
  const [open, setOpen] = useState(false);
  return (
    <div className="flex flex-col items-start gap-1">
      <button
        type="button"
        onClick={() => setOpen((v) => !v)}
        className="flex items-center gap-1 rounded-[var(--radius-md)] bg-input px-2.5 py-1.5 text-[length:var(--fs-xs)] text-fg-muted shadow-[var(--shadow-sm)]"
      >
        <ChevronDown size={13} className={`transition-transform ${open ? 'rotate-180' : ''}`} />
        <span>{cards.length} 次读 / 查 / 命令</span>
      </button>
      {open && (
        <div className="flex w-full flex-col gap-1">
          {cards.map((c) => {
            const detail =
              (typeof c.input?.file_path === 'string' && c.input.file_path) ||
              (typeof c.input?.pattern === 'string' && `/${c.input.pattern}/`) ||
              (typeof c.input?.command === 'string' && c.input.command) ||
              '';
            return (
              <div
                key={c.id}
                className="truncate rounded-[var(--radius-sm)] bg-input px-2 py-1 text-[length:var(--fs-xs)] text-fg-muted"
              >
                <span className="text-accent">{c.tool}</span>
                {detail && <span className="ml-1 break-all">{detail}</span>}
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}

/** work group 折叠头 + 展开体(对标 Happy AgentWorkGroupHeader):
 *  「这轮干了 12s · 6 步 +86 −12」一行;展开平铺成员(照常走 MessageView)。 */
function WorkGroup({ item, ctx, onApprove, onDeny, onDenyWithReason, onAnswer }: {
  item: Extract<RenderItem, { kind: 'group' }>;
  ctx: Ctx;
  onApprove: (callId: string) => void;
  onDeny: (callId: string) => void;
  onDenyWithReason: (callId: string, reqId: string, reason: string) => void;
  onAnswer: (callId: string, answers: Record<string, string>) => void;
}) {
  const [open, setOpen] = useState(false);
  const duration = item.durationMs ?? item.endedAt - item.startedAt;
  return (
    <div className="flex flex-col items-stretch gap-1">
      <button
        type="button"
        onClick={() => setOpen((v) => !v)}
        className="flex items-center gap-1.5 self-start rounded-[var(--radius-md)] bg-input px-2.5 py-1.5 text-[length:var(--fs-xs)] text-fg-muted shadow-[var(--shadow-sm)]"
      >
        <ChevronDown size={13} className={`shrink-0 transition-transform ${open ? 'rotate-180' : ''}`} />
        <span>这轮干了 {formatElapsed(duration)}</span>
        <span className="opacity-60">· {item.items.length} 步</span>
        {(item.diff.added > 0 || item.diff.removed > 0) && (
          <span className="font-mono">
            {item.diff.added > 0 && <span className="text-success">+{item.diff.added}</span>}
            {item.diff.added > 0 && item.diff.removed > 0 && <span> </span>}
            {item.diff.removed > 0 && <span className="text-danger">−{item.diff.removed}</span>}
          </span>
        )}
      </button>
      {open && (
        <div className="flex flex-col gap-2 border-l border-border pl-2">
          {item.items.map((m) => (
            <MessageView
              key={m.id}
              msg={m}
              ctx={ctx}
              onApprove={onApprove}
              onDeny={onDeny}
              onDenyWithReason={onDenyWithReason}
              onAnswer={onAnswer}
            />
          ))}
        </div>
      )}
    </div>
  );
}

/** AskUserQuestion 待审面板(Happy InlineQuestionForm 同形态):选项先选中后提交,
 *  单选 radio / 多选 checkbox;提交 = 答案随审批回程(resolveApproval.answers)回灌工具入参 ——
 *  答案作为工具结果返回给模型(TUI 同构),不再另发 stdin。 */
function AskAnswerPanel({
  msg,
  onAnswer,
  onDeny,
}: {
  msg: ToolCallMsg;
  onAnswer: (callId: string, answers: Record<string, string>) => void;
  onDeny: (callId: string) => void;
}) {
  const questions = parseAskInput(msg.input);
  /** 每问已选下标集(单选只留一个,多选累加)。 */
  const [selections, setSelections] = useState<Record<number, number[]>>({});
  if (questions.length === 0) return null;
  const toggle = (qi: number, oi: number, multi: boolean): void => {
    hapticLight();
    setSelections((prev) => {
      const cur = prev[qi] ?? [];
      if (multi) {
        return { ...prev, [qi]: cur.includes(oi) ? cur.filter((x) => x !== oi) : [...cur, oi] };
      }
      return { ...prev, [qi]: cur.includes(oi) ? [] : [oi] };
    });
  };
  const allAnswered = questions.every((_q, qi) => (selections[qi]?.length ?? 0) > 0);
  const submit = (): void => {
    if (!allAnswered) return;
    // 键 = 问题原文(CC 的 answers 语义);值 = 选中项 label 逗号连接(Happy 同款)
    const answers: Record<string, string> = {};
    for (let qi = 0; qi < questions.length; qi++) {
      const labels = (selections[qi] ?? [])
        .map((oi) => answerTextOf(questions[qi]!.options[oi]!))
        .filter(Boolean);
      if (labels.length) answers[questions[qi]!.question || `问题${qi + 1}`] = labels.join(', ');
    }
    onAnswer(msg.callId, answers);
  };
  return (
    <div className="mt-1 flex flex-col gap-2.5">
      {questions.map((q, qi) => {
        const picked = selections[qi] ?? [];
        return (
          <div key={qi} className="flex flex-col gap-1.5">
            {q.question && (
              <div className="whitespace-pre-wrap break-words text-[length:var(--fs-sm)] font-medium text-fg">
                {q.header && (
                  <span className="mr-1.5 rounded-[var(--radius-sm)] bg-input px-1.5 py-0.5 font-mono text-[10px] font-normal uppercase text-fg-muted">
                    {q.header}
                  </span>
                )}
                {q.question}
              </div>
            )}
            <div className="flex flex-col gap-1">
              {q.options.map((o, oi) => {
                const selected = picked.includes(oi);
                return (
                  <button
                    key={oi}
                    type="button"
                    onClick={() => toggle(qi, oi, q.multiSelect)}
                    className={
                      'flex min-h-11 items-start gap-2.5 rounded-[var(--radius-md)] border px-3 py-2.5 text-left transition-colors ' +
                      (selected ? 'border-accent bg-accent-soft' : 'border-border bg-input active:bg-elevated')
                    }
                  >
                    {q.multiSelect ? (
                      <span
                        className={
                          'mt-0.5 flex size-5 shrink-0 items-center justify-center rounded-[4px] border-2 ' +
                          (selected ? 'border-accent bg-accent text-on-accent' : 'border-fg-muted')
                        }
                      >
                        {selected && <Check size={13} />}
                      </span>
                    ) : (
                      <span
                        className={
                          'mt-0.5 flex size-5 shrink-0 items-center justify-center rounded-full border-2 ' +
                          (selected ? 'border-accent' : 'border-fg-muted')
                        }
                      >
                        {selected && <span className="size-2.5 rounded-full bg-accent" />}
                      </span>
                    )}
                    <span className="min-w-0 flex-1">
                      <span className="block text-[length:var(--fs-sm)] font-medium text-fg">{o.label}</span>
                      {o.description && (
                        <span className="mt-0.5 block text-[length:var(--fs-xs)] leading-relaxed text-fg-muted">
                          {o.description}
                        </span>
                      )}
                    </span>
                  </button>
                );
              })}
              {q.multiSelect && <span className="text-[10px] text-fg-muted">可多选</span>}
            </div>
          </div>
        );
      })}
      <div className="flex gap-2">
        <Button variant="accent" size="sm" onClick={submit} disabled={!allAnswered}>
          提交
        </Button>
        <Button variant="ghost" size="sm" onClick={() => onDeny(msg.callId)}>
          都不选(拒绝)
        </Button>
      </div>
    </div>
  );
}

/** 工具调用卡:state 驱动;pending 显 [允许][拒绝][拒绝并说明](允许带呼吸环);
 *  决策后按钮行保留、点过的亮其余淡化(选中回显);完成态零徽章、错误红边全显。 */
function ToolCallCard({
  msg,
  ctx,
  onApprove,
  onDeny,
  onDenyWithReason,
  onAnswer,
}: {
  msg: ToolCallMsg;
  ctx: Ctx;
  onApprove: (callId: string) => void;
  onDeny: (callId: string) => void;
  onDenyWithReason: (callId: string, reqId: string, reason: string) => void;
  onAnswer: (callId: string, answers: Record<string, string>) => void;
}) {
  const [editing, setEditing] = useState(false);
  const [reason, setReason] = useState('');

  // auto-edit 自动放行的卡(运行中 / 完成)→ 折叠一行,不占视线
  if (msg.autoApproved && (msg.state === 'running' || msg.state === 'completed')) {
    return (
      <div className="flex justify-start">
        <div className="rounded-[var(--radius-md)] bg-input px-2.5 py-1.5 text-[length:var(--fs-xs)] text-fg-muted shadow-[var(--shadow-sm)]">
          <span className="text-accent">自动放行</span> {msg.tool || '工具'}
          {typeof msg.input?.file_path === 'string' && (
            <span className="ml-1 break-all">{msg.input.file_path}</span>
          )}
        </div>
      </div>
    );
  }

  const label = stateLabel(msg.state, msg.isError, msg.autoApproved);
  const meta = getToolMeta(msg.tool);
  const MetaIcon = meta.icon;
  const reqId = msg.reqId; // 局部 const:让 TS 在下面三元里把 reqId 窄化成 string
  const errored = msg.state === 'completed' && msg.isError === true;
  return (
    <div className="flex justify-start">
      <div
        className={
          'w-[92%] rounded-[var(--radius-lg)] border bg-panel p-2.5 shadow-[var(--shadow-sm)] ' +
          (errored ? 'border-danger/50' : 'border-border')
        }
      >
        <div className="mb-1.5 flex items-center gap-2">
          {MetaIcon && <MetaIcon size={13} className="shrink-0 text-accent" />}
          <span className="rounded-[var(--radius-sm)] bg-accent-soft px-2 py-0.5 text-[length:var(--fs-xs)] text-accent">
            {msg.tool || '工具'}
          </span>
          {label && <span className={`text-[length:var(--fs-xs)] ${label.cls}`}>{label.text}</span>}
          {msg.state === 'running' && <RunningElapsed since={msg.ts} />}
        </div>
        <div className="max-h-[40vh] overflow-auto">
          {/* AskUserQuestion 待审:渲染交互式问答面板(问题+可点选项),不再走只读 ToolBody */}
          {msg.state === 'pending' && msg.tool === 'AskUserQuestion' ? (
            <AskAnswerPanel msg={msg} onAnswer={onAnswer} onDeny={onDeny} />
          ) : (
            <ToolBody msg={msg} ctx={ctx} />
          )}
          {/* 子代理(Task/Agent)的内部消息:递归用完整 MessageView 嵌套渲染
              (对标 Happy ToolCall.children)。递归在 ToolCallCard↔MessageView 同文件内,
              TaskView 保持纯叶子 → 无 views↔CcConversation 循环依赖。 */}
          {msg.children && msg.children.length > 0 && (
            <div className="mt-1.5 flex flex-col gap-1.5 border-l border-border pl-2">
              {msg.children.map((c) => (
                <MessageView
                  key={c.id}
                  msg={c}
                  ctx={ctx}
                  onApprove={onApprove}
                  onDeny={onDeny}
                  onDenyWithReason={onDenyWithReason}
                  onAnswer={onAnswer}
                />
              ))}
            </div>
          )}
          {/* 完成态结果:读/查类默认不显(文件正文/粘贴是噪声;含图片块例外 —— 读图就是要看图);
              Bash 折叠「N 行输出」(无错时);错误永远全显(排障第一现场)。 */}
          {msg.state === 'completed' && msg.result !== undefined && (
            errored ? (
              <ResultView result={msg.result} />
            ) : msg.tool === 'Bash' ? (
              <BashOutputView result={msg.result} />
            ) : meta.category === 'read-query' && !hasImageBlock(msg.result) ? null : (
              <ResultView result={msg.result} />
            )
          )}
        </div>
        {msg.state === 'pending' && reqId && (
          editing ? (
            <div className="mt-2 flex flex-col gap-1.5">
              <textarea
                value={reason}
                onChange={(e) => setReason(e.target.value)}
                rows={2}
                placeholder="说明要怎么改(拒绝后发给 CC)"
                className="resize-none rounded-[var(--radius-sm)] border border-border bg-input px-2 py-1.5 text-[length:var(--fs-sm)] text-fg outline-none focus:border-accent"
              />
              <div className="flex gap-2">
                <Button
                  variant="danger"
                  size="sm"
                  onClick={() => {
                    onDenyWithReason(msg.callId, reqId, reason);
                    setEditing(false);
                  }}
                >
                  发送并拒绝
                </Button>
                <Button variant="ghost" size="sm" onClick={() => setEditing(false)}>
                  取消
                </Button>
              </div>
            </div>
          ) : (
            <div className="mt-2 flex flex-wrap gap-2">
              {/* 允许:呼吸环(Happy PermissionActionButton 的 1.44s 呼吸,主动作抬眼) */}
              <span className="relative inline-flex">
                <span
                  aria-hidden
                  className="ce-cc-breathe pointer-events-none absolute -inset-px rounded-[var(--radius-md)] border-2 border-current text-accent"
                />
                <Button variant="accent" size="sm" onClick={() => onApprove(msg.callId)}>
                  允许
                </Button>
              </span>
              <Button variant="danger" size="sm" onClick={() => onDeny(msg.callId)}>
                拒绝
              </Button>
              <Button variant="ghost" size="sm" onClick={() => setEditing(true)}>
                拒绝并说明
              </Button>
            </div>
          )
        )}
        {/* 决策回显:点过的按钮亮、其余淡化(Happy 选中回显)—— 手机上事后能查「当时批了啥」 */}
        {msg.state !== 'pending' && msg.decision && !msg.autoApproved && (
          <div className="mt-2 flex flex-wrap gap-2">
            <span
              className={
                'rounded-[var(--radius-md)] px-2.5 py-1 text-[length:var(--fs-xs)] ' +
                (msg.decision === 'allow'
                  ? 'bg-accent-soft font-medium text-accent'
                  : 'text-fg-muted opacity-50')
              }
            >
              {msg.decision === 'allow' ? '✓ 允许' : '✕ 拒绝'}
            </span>
            <span className="rounded-[var(--radius-md)] px-2.5 py-1 text-[length:var(--fs-xs)] text-fg-muted opacity-50">
              {msg.decision === 'allow' ? '拒绝' : '允许'}
            </span>
          </div>
        )}
      </div>
    </div>
  );
}

/** thinking 气泡:默认折叠,点头部展开/收起(思考块常很长,折叠减噪)。 */
function ThinkingMessage({ msg }: { msg: Extract<ConvMessage, { role: 'assistant' }> }) {
  const [open, setOpen] = useState(false);
  return (
    <div className="flex justify-start">
      <button
        type="button"
        onClick={() => setOpen((v) => !v)}
        className="flex max-w-[92%] items-center gap-1 rounded-[var(--radius-md)] bg-input px-2.5 py-1.5 text-[length:var(--fs-xs)] text-fg-muted shadow-[var(--shadow-sm)]"
      >
        <ChevronDown size={13} className={`transition-transform ${open ? 'rotate-180' : ''}`} />
        <span>思考过程</span>
      </button>
      {open && (
        <div className="mt-1 max-w-[92%] whitespace-pre-wrap break-words rounded-[var(--radius-md)] border border-border bg-elevated px-3 py-2 text-[length:var(--fs-xs)] text-fg-muted">
          {msg.text}
        </div>
      )}
    </div>
  );
}

/** 复制小钮:copy → check 1.5s 复位(Happy MessageCopyButton 同款)。 */
function CopyButton({ text }: { text: string }) {
  const [done, setDone] = useState(false);
  return (
    <button
      type="button"
      aria-label="复制"
      className="mt-0.5 flex h-6 w-6 shrink-0 items-center justify-center self-end rounded-full text-fg-muted opacity-60 active:opacity-100"
      onClick={() => {
        void copyText(text).then((ok) => {
          if (!ok) return showToast('复制失败', 'error');
          hapticLight();
          setDone(true);
          setTimeout(() => setDone(false), 1500);
        });
      }}
    >
      {done ? <Check size={13} className="text-success" /> : <Copy size={13} />}
    </button>
  );
}

/** 长按复制的 user 气泡(400ms 长按;对标 Happy LongPressCopyable,菜单免了——只有一个动作)。 */
function UserBubble({ msg }: { msg: Extract<ConvMessage, { role: 'user' }> }) {
  /** 长按计时器;grace:排队标注 1s 内不显(Happy:快速 ack 不闪文案)。 */
  const [showQueued, setShowQueued] = useState(false);
  const timer = useRef<ReturnType<typeof setTimeout> | null>(null);
  useEffect(() => {
    if (!msg.queued) return;
    const t = setTimeout(() => setShowQueued(true), 1000);
    return () => clearTimeout(t);
  }, [msg.queued]);
  const startPress = (): void => {
    timer.current = setTimeout(() => {
      timer.current = null;
      void copyText(msg.text).then((ok) => {
        if (ok) {
          hapticLight();
          showToast('已复制', 'success');
        }
      });
    }, 400);
  };
  const cancelPress = (): void => {
    if (timer.current) {
      clearTimeout(timer.current);
      timer.current = null;
    }
  };
  return (
    <div className="flex flex-col items-end gap-0.5">
      <div
        className={
          'max-w-[85%] select-none whitespace-pre-wrap break-words rounded-[var(--radius-lg)] bg-accent-soft px-3 py-2 text-[length:var(--fs-sm)] text-fg shadow-[var(--shadow-sm)] transition-opacity ' +
          (msg.queued ? 'opacity-55' : '')
        }
        onTouchStart={startPress}
        onTouchEnd={cancelPress}
        onTouchMove={cancelPress}
        onContextMenu={(e) => {
          // 桌面/长按系统菜单:拦截,行为统一为复制
          e.preventDefault();
          startPress();
          setTimeout(cancelPress, 420);
        }}
      >
        {msg.text}
      </div>
      {msg.queued && showQueued && (
        <span className="pr-1 text-[10px] text-fg-muted">本轮结束后发送</span>
      )}
    </div>
  );
}

/** 单条消息渲染(按 role 分支)。 */
function MessageView({
  msg,
  ctx,
  onApprove,
  onDeny,
  onDenyWithReason,
  onAnswer,
}: {
  msg: ConvMessage;
  ctx: Ctx;
  onApprove: (callId: string) => void;
  onDeny: (callId: string) => void;
  onDenyWithReason: (callId: string, reqId: string, reason: string) => void;
  onAnswer: (callId: string, answers: Record<string, string>) => void;
}) {
  if (msg.role === 'user') {
    return (
      <div className="flex justify-end">
        <UserBubble msg={msg} />
      </div>
    );
  }
  if (msg.role === 'assistant') {
    if (msg.isThinking) return <ThinkingMessage msg={msg} />;
    if (!msg.text.trim()) return null;
    return (
      <div className="flex flex-col items-start gap-0.5">
        <div className="max-w-[92%] rounded-[var(--radius-lg)] bg-elevated px-3 py-2 text-[length:var(--fs-sm)] text-fg shadow-[var(--shadow-sm)]">
          <Markdown>{msg.text}</Markdown>
        </div>
        <CopyButton text={msg.text} />
      </div>
    );
  }
  if (msg.role === 'system') {
    // 失败才打断视觉(红);完成胶囊只在本轮内显示(历史轮被 work group 头取代)
    const failed = msg.text === 'CC 出错';
    return (
      <div className="flex flex-col items-center gap-0.5">
        <span
          className={
            'rounded-full px-2.5 py-1 text-[length:var(--fs-xs)] ' +
            (failed ? 'bg-danger/15 text-danger' : 'bg-input text-fg-muted')
          }
        >
          {msg.text}
          {msg.durationMs !== undefined && !failed && ` · ${formatElapsed(msg.durationMs)}`}
          {msg.usage && (msg.usage.inputTokens !== undefined || msg.usage.outputTokens !== undefined) && (
            <span className="ml-1 font-mono opacity-70">
              ↑{formatTokens(msg.usage.inputTokens ?? 0)} ↓{formatTokens(msg.usage.outputTokens ?? 0)}
              {msg.usage.costUsd !== undefined && msg.usage.costUsd > 0 ? ` · $${msg.usage.costUsd.toFixed(2)}` : ''}
            </span>
          )}
        </span>
      </div>
    );
  }
  return (
    <ToolCallCard
      msg={msg}
      ctx={ctx}
      onApprove={onApprove}
      onDeny={onDeny}
      onDenyWithReason={onDenyWithReason}
      onAnswer={onAnswer}
    />
  );
}

// ─── 主组件 ────────────────────────────────────────────────────────────────────

/** 持久化上限:500 条 + 大结果截断(localStorage 有 5MB 级预算;图片/长输出是膨胀主力)。 */
const PERSIST_MAX_MESSAGES = 500;
const PERSIST_MAX_RESULT_CHARS = 8000;

/** 存盘前瘦身:截消息数、截大结果(图片→占位,字符串→截断)。内存里仍是全量。 */
function forPersist(state: SessionState): SessionState {
  const msgs = state.messages.slice(-PERSIST_MAX_MESSAGES).map((m) => {
    if (m.role !== 'tool-call' || m.result === undefined || m.result === null) return m;
    if (typeof m.result === 'string') {
      return m.result.length > PERSIST_MAX_RESULT_CHARS
        ? { ...m, result: `${m.result.slice(0, PERSIST_MAX_RESULT_CHARS)}…(截断存储)` }
        : m;
    }
    if (Array.isArray(m.result)) {
      // 块数组:图片换占位(几十 KB~几 MB 的 base64 不进盘),文本截断
      const slim = (m.result as Array<{ type?: string; text?: string; source?: unknown }>).map((b) =>
        b && b.type === 'image' ? { type: 'text', text: '[图片(未持久化,重进会话不保留)]' } : b,
      );
      return { ...m, result: slim };
    }
    return m;
  });
  return { ...state, messages: msgs };
}

export function CcConversation({ ctx, terminalId, cwd, persist, restore }: SessionProps) {
  ensureConversationStyles();
  const [state, dispatch] = useReducer(sessionReducer, undefined, () => migrateSession(restore<unknown>()));
  const { messages, mode, filter, turnSince, model, thinking, modelOverride } = state;
  /** mode 的 ref:让 subscribe 回调闭包读到最新 mode(不重订阅)。 */
  const modeRef = useRef(mode);
  modeRef.current = mode;
  const thinkingRef = useRef(thinking);
  thinkingRef.current = thinking;
  const modelRef = useRef(modelOverride);
  modelRef.current = modelOverride;
  const [input, setInput] = useState('');
  const [sending, setSending] = useState(false);
  /** 发送失败抖动(Happy Shaker:300ms;失败 = toast + 抖 + 错误触感,三通道合一)。 */
  const [shake, setShake] = useState(false);
  /** 中断 inflight(防连点)。 */
  const [stopping, setStopping] = useState(false);
  // 开窗检测:exec claude --version 判安装。有历史(claude 之前能用)→ 直接 ready;否则显检测动画。
  const [detect, setDetect] = useState<DetectStatus>(() => (messages.length > 0 ? 'ready' : 'detecting'));
  const [probeNonce, setProbeNonce] = useState(0);
  /** 输入框「⋯」菜单开关(过滤三档收纳于此,换输入条干净)。 */
  const [menuOpen, setMenuOpen] = useState(false);
  /** 「⋯」菜单锚点按钮(Popover 贴其正下方)。 */
  const menuBtnRef = useRef<HTMLButtonElement>(null);
  /** 模式选择菜单(四档,对齐 TUI)开关 + 锚点。 */
  const [modeMenuOpen, setModeMenuOpen] = useState(false);
  const modeBtnRef = useRef<HTMLButtonElement>(null);
  /** 模型动态列表(/model 真列表;菜单首次打开拉一次;null = 未拉到 → 回落静态快捷档)。 */
  const [modelList, setModelList] = useState<AgentModelInfo[] | null>(null);
  /** 模型列表拉取中(下拉框禁用态提示)。 */
  const [modelFetching, setModelFetching] = useState(false);
  /** 思考滑块拖动中的本地预览位(松手才提交 RPC;null = 未在拖)。 */
  const [sliderIdx, setSliderIdx] = useState<number | null>(null);
  /** 审批 inflight:reqId → 防重复发 RPC(manual/auto 共用)。 */
  const pendingApprove = useRef(new Set<string>());

  // ── 滚动:贴底才吸底(Happy maintainVisibleContentPosition 的 web 等价);
  //    上滚即放手,浮出「回到底部」(距底 >300px,Happy 阈值)。
  const scrollRef = useRef<HTMLDivElement | null>(null);
  const stickRef = useRef(true);
  const [showJump, setShowJump] = useState(false);
  const onScroll = (): void => {
    const el = scrollRef.current;
    if (!el) return;
    const dist = el.scrollHeight - el.scrollTop - el.clientHeight;
    stickRef.current = dist < 120;
    setShowJump(dist > 300);
  };
  useEffect(() => {
    if (!stickRef.current) return;
    // 双 rAF:等 markdown/代码高亮/图片把高度撑开之后再锚底,免得锚在半空
    requestAnimationFrame(() =>
      requestAnimationFrame(() => {
        const el = scrollRef.current;
        if (el && stickRef.current) el.scrollTop = el.scrollHeight;
      }),
    );
  }, [messages]);

  // 微信级持久化:state 变化即存(杀 app 重开 restore 还原);存前瘦身(上限防膨胀)。
  useEffect(() => {
    persist(forPersist(state));
  }, [state, persist]);

  /** 当前待审批的工具卡数(状态条 waiting 态 + 输入框胶囊共用)。 */
  const pendingCount = useMemo(
    () => messages.filter((m) => m.role === 'tool-call' && m.state === 'pending').length,
    [messages],
  );
  const running = turnSince !== null;

  /** 停止当前回合(agentInterrupt,C 层加菜;老 ce 报错 → 提示降级)。 */
  const stopTurn = async (): Promise<void> => {
    if (!terminalId || stopping || !running) return;
    setStopping(true);
    hapticLight();
    try {
      await ctx.rpc.invoke({
        op: 'write',
        kind: 'agentInterrupt',
        scope: ctx.scope,
        payload: { terminalId },
      });
      showToast('已请求停止', 'success');
    } catch {
      hapticError();
      showToast('停止失败(被控机 ce 版本过旧?)', 'error');
    } finally {
      setStopping(false);
    }
  };

  /** 开窗检测:exec `claude auth status` → 判安装+登录(mount 跑一次 + 重试时跑)。
   *  claude auth status 输出 JSON {loggedIn: bool}(实测)—— 优先解析 loggedIn 字段(比 exit code 稳);
   *  解析失败 → 退回 exit code(0=ready / 1=no-login / 127=no-claude);
   *  老 claude 无 auth 子命令(exit 1 + "unknown command")→ 乐观放行 ready(登录留首消息)。 */
  useEffect(() => {
    let alive = true;
    ctx.rpc
      .invoke({ op: 'exec', command: 'claude auth status', scope: ctx.scope })
      .then((r) => {
        if (!alive) return;
        const txt = `${r.stderr}\n${r.stdout}`;
        if (r.exitCode === 127 || /not (found|recognized)/i.test(txt)) {
          setDetect('no-claude');
          return;
        }
        // 优先解析 JSON loggedIn 字段(实测 claude auth status 总输出 JSON)
        try {
          const loggedIn = (JSON.parse(r.stdout) as { loggedIn?: unknown }).loggedIn;
          if (loggedIn === true) return setDetect('ready');
          if (loggedIn === false) return setDetect('no-login');
        } catch {
          /* 非 JSON → 退回 exit code */
        }
        if (r.exitCode === 0) setDetect('ready');
        else if (r.exitCode === 1) {
          setDetect(/unknown (command|subcommand)|usage:|not a valid command/i.test(txt) ? 'ready' : 'no-login');
        } else setDetect('error');
      })
      .catch(() => {
        if (alive) setDetect('error');
      });
    return () => {
      alive = false;
    };
  }, [ctx, probeNonce]);

  /** agentEvents 订阅(terminal scope):ce 端 agent-runner 推来的结构化事件 → 归约成消息。
   *  auto-edit 模式下,改文件工具(Write/Edit/…)的 approval-request 直接自动 allow + 标 autoApproved
   *  (跳过 pending、不显审批按钮);其余事件正常归约。 */
  useEffect(() => {
    let cancel: (() => void) | undefined;
    ctx.rpc
      .subscribe(
        { op: 'subscribe', stream: 'agentEvents', scope: ctx.scope },
        (chunk) => {
          if (!('data' in chunk)) return;
          const ev = asAgentEvent(chunk.data);
          if (!ev) return;
          // 手机侧兜底 belt(ce setMode 推送失败/老 ce 时仍可用;新 ce 下 CC 多数根本不问):
          // yolo = 任何工具全放行;auto-edit = 只放改文件。
          const tool = ev.kind === 'approval-request' && typeof ev.tool === 'string' ? ev.tool : '';
          const beltHit =
            modeRef.current === 'yolo' || (modeRef.current === 'auto-edit' && isEditTool(tool));
          if (ev.kind === 'approval-request' && beltHit) {
            const reqId = typeof ev.reqId === 'string' ? ev.reqId : '';
            const callId = typeof ev.callId === 'string' ? ev.callId : '';
            const inputObj = (ev.input && typeof ev.input === 'object' ? ev.input : {}) as Record<string, unknown>;
            if (reqId) void autoApprove(reqId, callId, tool || 'unknown', inputObj);
            return; // 不进 pending
          }
          dispatch({ type: 'event', ev: chunk.data });
        },
      )
      .then(({ cancel: c }) => {
        cancel = c;
        // 恢复会话:手机记着的非默认设置推给 ce(新会话/重连后 SDK 侧归位)
        if (modeRef.current !== 'manual') pushModeToCe(modeRef.current);
        if (thinkingRef.current !== 'default') {
          void ctx.rpc.invoke({ op: 'write', kind: 'agentThinking', scope: ctx.scope, payload: { terminalId: terminalId ?? '', level: thinkingRef.current } }).catch(() => undefined);
        }
        if (modelRef.current) {
          void ctx.rpc.invoke({ op: 'write', kind: 'agentSetModel', scope: ctx.scope, payload: { terminalId: terminalId ?? '', model: modelRef.current } }).catch(() => undefined);
        }
      })
      .catch(() => undefined);
    return () => {
      cancel?.();
    };
  }, [ctx]);

  /** 发送文本(输入框 / 选项 chip 共用):本地回显 + write stdin(ce 端 cc sid 路由到 agent InputQueue)。
   *  fromInput=true 时清输入框(选项 chip 不清)。对齐旧 App.vue handleSendText 的「auto-append \r」。 */
  const sendText = async (text: string, fromInput: boolean): Promise<void> => {
    const t = text.trim();
    if (!t || sending) return;
    if (!terminalId) {
      showToast('终端 ID 缺失', 'error');
      return;
    }
    setSending(true);
    try {
      dispatch({ type: 'user', text: t });
      await ctx.rpc.invoke({
        op: 'write',
        kind: 'stdin',
        scope: ctx.scope,
        terminalId,
        payload: t + '\r',
      });
      if (fromInput) setInput('');
    } catch (e) {
      hapticError();
      setShake(true);
      setTimeout(() => setShake(false), 320);
      showToast(`发送失败:${(e as Error).message}`, 'error');
    } finally {
      setSending(false);
    }
  };

  /** 人工审批:乐观标 state + 发 resolveApproval(allow/deny)。answers = AskUserQuestion 答案
   *  (随审批回程捎给 ce 合并进工具入参;老 ce 忽略该字段)。 */
  const resolveApproval = async (
    callId: string,
    reqId: string,
    decision: 'allow' | 'deny',
    answers?: Record<string, string>,
  ): Promise<void> => {
    if (!reqId || pendingApprove.current.has(reqId)) return;
    pendingApprove.current.add(reqId);
    dispatch({ type: 'mark', callId, decision, answers });
    try {
      await ctx.rpc.invoke({
        op: 'write',
        kind: 'resolveApproval',
        scope: ctx.scope,
        payload: { reqId, decision, ...(answers ? { answers } : {}) },
      });
    } catch {
      /* 失败:卡已乐观标;v1 静默 */
    } finally {
      pendingApprove.current.delete(reqId);
    }
  };

  /** auto-edit 自动放行:标 running+autoApproved + 发 resolveApproval(allow)。manual 切 auto 时也用它清积压。 */
  const autoApprove = async (
    reqId: string,
    callId: string,
    tool: string,
    inputObj: Record<string, unknown>,
  ): Promise<void> => {
    if (!reqId || pendingApprove.current.has(reqId)) return;
    pendingApprove.current.add(reqId);
    dispatch({ type: 'auto-approve', reqId, callId, tool, input: inputObj });
    try {
      await ctx.rpc.invoke({
        op: 'write',
        kind: 'resolveApproval',
        scope: ctx.scope,
        payload: { reqId, decision: 'allow' },
      });
    } catch {
      /* 静默:已标 autoApproved,ce 侧重连重发兜底 */
    } finally {
      pendingApprove.current.delete(reqId);
    }
  };

/** 回答 AskUserQuestion:批准 + 答案随审批回程(resolveApproval.answers)→ ce 合并进工具入参,
 *  答案作为工具结果返回给模型(TUI 同构;对齐 Happy sessionAllow updatedInput 通道)。 */
const onAnswer = (callId: string, answers: Record<string, string>): void => {
  hapticLight();
  const m = findCard(callId);
  if (m?.reqId) void resolveApproval(callId, m.reqId, 'allow', answers);
};

  const findCard = (callId: string): ToolCallMsg | undefined =>
    messages.find((m): m is ToolCallMsg => m.role === 'tool-call' && m.callId === callId && !!m.reqId);

  const onApprove = (callId: string): void => {
    const m = findCard(callId);
    if (m?.reqId) {
      void resolveApproval(callId, m.reqId, 'allow');
      // 计划通过 → 自动切回默认模式(Happy permissionHandler 同款;否则 CC 困在 plan 档)
      if (m.tool === 'ExitPlanMode') setMode('manual');
    }
  };
  const onDeny = (callId: string): void => {
    const m = findCard(callId);
    if (m?.reqId) void resolveApproval(callId, m.reqId, 'deny');
  };
  /** 拒绝并说明:拒绝该操作 + 把说明作为新消息发给 CC(让它改方案)。均用现有 write 能力,不动 ce。 */
  const onDenyWithReason = async (callId: string, reqId: string, reason: string): Promise<void> => {
    await resolveApproval(callId, reqId, 'deny');
    const t = reason.trim();
    if (t && terminalId) {
      try {
        await ctx.rpc.invoke({
          op: 'write',
          kind: 'stdin',
          scope: ctx.scope,
          terminalId,
          payload: t + '\r',
        });
      } catch {
        showToast('说明发送失败', 'error');
      }
    }
  };

  /** 切权限模式(对齐 TUI 四档):①推 ce(SDK setPermissionMode + 本地兜底;老 ce 报错 → 静默,
   *  手机侧 belt 仍生效);②清积压(yolo 放全部 / auto-edit 放改文件);③plan/yolo 有 toast 提示。 */
  const setMode = (next: Mode): void => {
    if (next === mode) return;
    dispatch({ type: 'set-mode', mode: next });
    void ctx.rpc
      .invoke({
        op: 'write',
        kind: 'agentSetMode',
        scope: ctx.scope,
        payload: { terminalId: terminalId ?? '', mode: MODE_TO_SDK[next] },
      })
      .catch(() => undefined); // 老 ce 不认识该 op → 手机侧 belt 兜底,不弹错
    for (const m of messages) {
      if (m.role !== 'tool-call' || m.state !== 'pending' || !m.reqId) continue;
      if (next === 'yolo' || (next === 'auto-edit' && isEditTool(m.tool))) {
        void autoApprove(m.reqId, m.callId, m.tool, m.input);
      }
    }
    showToast(next === 'yolo' ? '已切到绕过权限:CC 不再请求任何确认' : `已切换:${MODE_LABEL[next].name}`, next === 'yolo' ? 'error' : 'success');
  };

  /** 会话打开/模式恢复:把手机侧记忆的模式推给 ce(subscribe 建立后跑一次)。 */
  const pushModeToCe = (m: Mode): void => {
    void ctx.rpc
      .invoke({
        op: 'write',
        kind: 'agentSetMode',
        scope: ctx.scope,
        payload: { terminalId: terminalId ?? '', mode: MODE_TO_SDK[m] },
      })
      .catch(() => undefined);
  };
  /** 切思考强度(setMaxThinkingTokens 热调;老 ce 提示降级)。 */
  const setThinking = (level: ThinkingLevel): void => {
    if (level === thinking) return;
    dispatch({ type: 'set-thinking', level });
    hapticLight();
    void ctx.rpc
      .invoke({ op: 'write', kind: 'agentThinking', scope: ctx.scope, payload: { terminalId: terminalId ?? '', level } })
      .catch(() => showToast('思考强度切换失败(ce 版本过旧?)', 'error'));
  };
  /** 切模型(SDK setModel 运行时热切;空 = 底座默认;老 ce 提示降级)。 */
  const setModelOverride = (m: string): void => {
    if (m === (modelOverride ?? '')) return;
    dispatch({ type: 'set-model', model: m || undefined });
    hapticLight();
    void ctx.rpc
      .invoke({ op: 'write', kind: 'agentSetModel', scope: ctx.scope, payload: { terminalId: terminalId ?? '', model: m || undefined } })
      .catch(() => showToast('模型切换失败(ce 版本过旧?)', 'error'));
  };

  // CC 最后一条非 thinking 文本里的「可选方案」→ 输入框上方快捷 chip(诉求③:不套审批,直接选)。
  const options = useMemo(() => {
    for (let i = messages.length - 1; i >= 0; i--) {
      const m = messages[i];
      if (m.role === 'assistant' && !m.isThinking) return extractOptions(m.text);
    }
    return [];
  }, [messages]);

  const items = buildRenderItems(messages, filter);

  // 检测失败态(未装 / 未登录 / 检测失败)→ 全屏提示,不显对话 + 输入框。detecting/ready 走下方正常 UI。
  if (detect === 'no-claude' || detect === 'no-login' || detect === 'error') {
    const retry = (): void => {
      setDetect('detecting');
      setProbeNonce((n) => n + 1);
    };
    return (
      <div className="ce-cc-detect flex h-full flex-col items-center justify-center gap-3 px-6 text-center">
        <ClaudeIcon size={48} className="opacity-40" />
        {detect === 'no-claude' ? (
          <>
            <div className="text-[length:var(--fs-md)] font-semibold text-fg">未安装 claude</div>
            <div className="max-w-xs text-[length:var(--fs-xs)] leading-relaxed text-fg-muted">
              被控机未检测到 claude。请在被控机安装 <code className="rounded bg-input px-1">claude</code> 后重试。
            </div>
          </>
        ) : detect === 'no-login' ? (
          <>
            <div className="text-[length:var(--fs-md)] font-semibold text-fg">claude 未登录</div>
            <div className="max-w-xs text-[length:var(--fs-xs)] leading-relaxed text-fg-muted">
              被控机的 claude 未登录。请在被控机运行 <code className="rounded bg-input px-1">claude login</code>(或{' '}
              <code className="rounded bg-input px-1">claude auth login</code>)登录后重试。
            </div>
          </>
        ) : (
          <>
            <div className="text-[length:var(--fs-md)] font-semibold text-fg">检测失败</div>
            <div className="max-w-xs text-[length:var(--fs-xs)] leading-relaxed text-fg-muted">
              无法连接被控机检测 claude,请确认 ce 已连接后重试。
            </div>
          </>
        )}
        <Button variant="default" size="sm" onClick={retry}>
          {detect === 'error' ? '重试' : '重新检测'}
        </Button>
      </div>
    );
  }

  return (
    <div className="ce-cc-conv flex h-full flex-col bg-base">
      <div className="relative min-h-0 flex-1">
        <div
          ref={scrollRef}
          onScroll={onScroll}
          className="h-full overflow-y-auto px-3 py-3 [scrollbar-width:thin]"
          style={{
            // 底部渐隐:对话滚到底(接近输入框)内容淡出融入 cc 根 bg-base,免硬切。
            // 只 mask 底部 32px(顶部由 App main 的顶栏下渐隐 overlay 负责)。
            WebkitMaskImage: 'linear-gradient(to bottom, black calc(100% - 32px), transparent)',
            maskImage: 'linear-gradient(to bottom, black calc(100% - 32px), transparent)',
          }}
        >
          <div className="mx-auto flex max-w-3xl flex-col gap-2.5">
            {messages.length === 0 && (
              <div className="mt-16 flex flex-col items-center gap-3 text-fg-muted">
                <ClaudeIcon size={48} className={detect === 'detecting' ? 'animate-pulse' : ''} />
                <div className="text-[length:var(--fs-lg)] font-semibold text-fg">claude code</div>
                {cwd ? (
                  <div className="flex items-center gap-1.5 rounded-[var(--radius-sm)] bg-input px-2 py-1 text-[length:var(--fs-xs)]">
                    <Folder size={12} className="shrink-0 opacity-70" />
                    <code className="break-all">{cwd}</code>
                  </div>
                ) : null}
                {detect === 'detecting' && (
                  <div className="flex items-center gap-1.5 text-[length:var(--fs-xs)]">
                    <Loader size={12} className="animate-spin" />
                    <span>检测 claude…</span>
                  </div>
                )}
              </div>
            )}
            {items.map((it) =>
              it.kind === 'readops' ? (
                <ReadOpsSummary key={`grp-${it.cards[0].id}`} cards={it.cards} />
              ) : it.kind === 'group' ? (
                <WorkGroup
                  key={`wg-${it.startedAt}`}
                  item={it}
                  ctx={ctx}
                  onApprove={onApprove}
                  onDeny={onDeny}
                  onDenyWithReason={onDenyWithReason}
                  onAnswer={onAnswer}
                />
              ) : (
                <MessageView
                  key={it.msg.id}
                  msg={it.msg}
                  ctx={ctx}
                  onApprove={onApprove}
                  onDeny={onDeny}
                  onDenyWithReason={onDenyWithReason}
                  onAnswer={onAnswer}
                />
              ),
            )}
          </div>
        </div>
        {/* 跳底按钮:滚离 300px 浮现(Happy 阈值;轻 fade 提示,150ms) */}
        {showJump && (
          <button
            type="button"
            aria-label="回到底部"
            onClick={() => {
              const el = scrollRef.current;
              if (el) el.scrollTo({ top: el.scrollHeight, behavior: 'smooth' });
              stickRef.current = true;
            }}
            className="absolute bottom-3 right-3 flex size-8 items-center justify-center rounded-full border border-border bg-panel/90 text-fg shadow-[var(--shadow-sm)] transition-opacity duration-150 active:opacity-70"
          >
            <ArrowDown size={14} />
          </button>
        )}
      </div>

      <div className="px-3 pt-1 pb-[calc(0.5rem+env(safe-area-inset-bottom))]">
        <div className="mx-auto flex max-w-3xl flex-col gap-1.5">
          {/* 状态条:CC 在跑/等你批,一眼可见(Happy AgentInputStatusRow) */}
          <StatusBar running={running} runningSince={turnSince} pendingCount={pendingCount} model={model} />
          {/* CC 文本给的「可选方案」快捷 chip —— 临时浮在输入框上方(仅 CC 这轮给选项时显)。
              与下方输入框内的能力胶囊视觉区分:这是「这轮让你选」,非「你的能力设置」。 */}
          {options.length > 0 && (
            <div className="flex flex-wrap gap-1.5">
              {options.map((o) => (
                <button
                  key={o.prefix}
                  type="button"
                  onClick={() => void sendText(o.text, false)}
                  title={o.text}
                  className="max-w-full truncate rounded-[var(--radius-md)] border border-border bg-input px-2.5 py-1 text-[length:var(--fs-xs)] text-fg tap-scale active:translate-y-px"
                >
                  {o.text}
                </button>
              ))}
            </div>
          )}
          {/* 一体化胶囊输入框(对标 DeepSeek 新版):文本区在上,底部控件行收所有入口 ——
              左:auto-edit 能力胶囊(点亮=自动放行改文件,警示红)+ 待审批提示胶囊(有时才显);
              右:⋯ 菜单(过滤三档)+ 发送键(状态化:有字才高亮)。输入条本身保持干净。 */}
          <div
            className={
              'rounded-[var(--radius-lg)] border border-border bg-panel shadow-[0_0_16px_rgba(0,0,0,0.14)] transition-colors focus-within:border-accent ' +
              (shake ? 'ce-cc-shake' : '')
            }
          >
            <textarea
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === 'Enter' && !e.shiftKey) {
                  e.preventDefault();
                  void sendText(input, true);
                }
              }}
              rows={1}
              placeholder="输入消息(Enter 发送)"
              className="block max-h-[30vh] min-h-[56px] w-full resize-none bg-transparent px-3 pt-3 text-[length:var(--fs-sm)] text-fg outline-none placeholder:text-fg-muted"
            />
            <div className="flex items-end gap-1.5 px-2 pb-2 pt-1">
              {/* 权限模式胶囊(对齐 TUI 四档):点开菜单选;非默认档常亮抬眼(yolo 警示红)。 */}
              <button
                type="button"
                ref={modeBtnRef}
                onClick={() => setModeMenuOpen(true)}
                className={
                  'inline-flex h-[30px] items-center gap-1 rounded-full px-2.5 text-[length:var(--fs-xs)] tap-scale transition-colors ' +
                  (mode === 'yolo'
                    ? 'bg-danger text-white'
                    : mode === 'manual'
                      ? 'border border-border text-fg-secondary hover:text-fg'
                      : 'bg-accent-soft text-accent')
                }
              >
                <PenLine size={12} className="shrink-0" />
                {mode === 'manual' ? '默认' : mode === 'auto-edit' ? '自动编辑' : mode === 'plan' ? '计划模式' : '绕过权限'}
              </button>
              {/* 模式菜单:四档 = TUI Shift+Tab 的循环集(命名对齐;yolo 红字警示)。 */}
              <Popover open={modeMenuOpen} onClose={() => setModeMenuOpen(false)} anchor={modeBtnRef} width={252} placement="top">
                <div className="px-2.5 py-1 text-[length:var(--fs-xs)] text-fg-muted">权限模式(同 TUI)</div>
                {(['manual', 'auto-edit', 'plan', 'yolo'] as const).map((m) => {
                  const info = MODE_LABEL[m];
                  return (
                    <button
                      key={m}
                      type="button"
                      onClick={() => {
                        setMode(m);
                        setModeMenuOpen(false);
                      }}
                      className={
                        'flex w-full flex-col items-start rounded-[var(--radius-sm)] px-2.5 py-1.5 text-left tap-scale ' +
                        (mode === m ? 'bg-input' : 'hover:bg-input')
                      }
                    >
                      <span className={'text-[length:var(--fs-sm)] ' + (mode === m ? 'text-accent' : info.danger ? 'text-danger' : 'text-fg')}>
                        {info.name}
                        {mode === m && <Check size={12} className="ml-1 inline" />}
                      </span>
                      <span className="text-[length:var(--fs-xs)] text-fg-muted">{info.desc}</span>
                    </button>
                  );
                })}
              </Popover>
              {/* 待审批提示胶囊:仅 pending>0 显,点 → 切 pending 视图(高频审查一键直达;
                  过滤的另两档藏 ⋯ 菜单,输入条更干净)。 */}
              {pendingCount > 0 && (
                <button
                  type="button"
                  onClick={() => dispatch({ type: 'set-filter', filter: 'pending' })}
                  className="inline-flex h-[30px] items-center gap-1 rounded-full bg-accent px-2.5 text-[length:var(--fs-xs)] text-on-accent tap-scale active:translate-y-px"
                >
                  <Bell size={12} className="shrink-0 animate-pulse" />
                  {pendingCount} 待审批
                </button>
              )}
              <div className="flex-1" />
              {/* ⋯ 更多:过滤三档(视图筛选,非常驻;收进菜单换输入条干净) */}
              <button
                type="button"
                ref={menuBtnRef}
                onClick={() => {
                setMenuOpen(true);
                // /model 真列表:菜单首次打开拉一次(老 ce / 会话未起 → 保持静态回落)
                if (modelList === null && !modelFetching && terminalId) {
                  setModelFetching(true);
                  void ctx.rpc
                    .invoke({ op: 'read', kind: 'agentSupportedModels', terminalId, scope: ctx.scope })
                    .then((list) => {
                      if (Array.isArray(list) && list.length > 0) setModelList(list as AgentModelInfo[]);
                    })
                    .catch(() => undefined)
                    .finally(() => setModelFetching(false));
                }
              }}
                aria-label="更多"
                className="flex h-5 w-5 mr-2.5 shrink-0 items-center justify-center rounded-full border border-current text-fg-secondary tap-scale hover:bg-elevated active:translate-y-px"
              >
                <MoreHorizontal size={14} />
              </button>
              {/* 主按钮二合一(Happy resolveAgentInputPrimaryAction):空输入 + 运行中 = 停止(醒目红);
                  有字 = 发送(accent);空闲无字 = 淡禁用。 */}
              {running && !input.trim() ? (
                <button
                  type="button"
                  onClick={() => void stopTurn()}
                  disabled={stopping}
                  aria-label="停止"
                  className={
                    'flex h-[30px] w-[30px] shrink-0 items-center justify-center rounded-full bg-danger text-white tap-scale transition-all disabled:opacity-60 ' +
                    (stopping ? '' : 'active:translate-y-px')
                  }
                >
                  {stopping ? <Loader size={14} className="animate-spin" /> : <Square size={12} fill="currentColor" />}
                </button>
              ) : (
                <button
                  type="button"
                  onClick={() => {
                    hapticLight();
                    void sendText(input, true);
                  }}
                  disabled={!input.trim() || sending}
                  aria-label="发送"
                  className={
                    'flex shrink-0 items-center justify-center rounded-full tap-scale transition-all disabled:pointer-events-none disabled:opacity-40 ' +
                    (input.trim()
                      ? 'h-[30px] w-[30px] border border-transparent bg-accent text-on-accent active:translate-y-px'
                      : 'h-5 w-5 border border-current text-fg-secondary')
                  }
                >
                  <ArrowUp size={input.trim() ? 16 : 14} />
                </button>
              )}
            </div>
          </div>
        </div>
      </div>
      {/* ⋯ 菜单:过滤三档(全部 / 仅改动 / 仅待审批)—— 视图筛选非能力,藏菜单不占输入条。 */}
      <Popover open={menuOpen} onClose={() => setMenuOpen(false)} anchor={menuBtnRef} width={272} placement="top">
        <div className="px-2.5 pb-0.5 pt-1.5 text-[length:var(--fs-xs)] text-fg-muted">显示</div>
        {(['all', 'writes', 'pending'] as const).map((f) => (
          <button
            key={f}
            type="button"
            onClick={() => {
              dispatch({ type: 'set-filter', filter: f });
              setMenuOpen(false);
            }}
            className={
              'flex w-full items-center justify-between rounded-[var(--radius-sm)] px-2.5 py-1.5 text-left text-[length:var(--fs-sm)] tap-scale ' +
              (filter === f ? 'text-accent' : 'text-fg hover:bg-input')
            }
          >
            <span>{f === 'all' ? '全部消息' : f === 'writes' ? '仅改动' : '仅待审批'}</span>
            {filter === f && <Check size={14} className="shrink-0" />}
          </button>
        ))}
        <div className="mx-2.5 my-1 border-t border-border" />
        {/* 思考强度 = 滑块(离散档;档位集按当前模型 supportedEffortLevels;「跟随默认」作首档)。
            拖动只改本地预览,松手(pointerup/keyup/blur)才提交 —— onChange 连发 RPC 的风暴闸。 */}
        {(() => {
          const stops: ThinkingLevel[] = ['default', 'off', ...effortLevelsFor(modelList, modelOverride ?? model)];
          // 当前档不在 stops(换了模型后旧档掉出)→ 显示真实档名,滑块停在最近法位
          const realIdx = stops.indexOf(thinking);
          const idx = realIdx >= 0 ? realIdx : sliderIdx ?? 0;
          const shown: ThinkingLevel = realIdx >= 0 ? thinking : (stops[sliderIdx ?? 0] ?? 'default');
          const info = EFFORT_LABEL[shown] ?? { name: shown, desc: '' };
          return (
            <div className="flex flex-col gap-0.5 px-2.5 py-1.5">
              <div className="flex items-center justify-between">
                <span className="text-[length:var(--fs-xs)] text-fg-muted">思考强度</span>
                <span className="text-[length:var(--fs-xs)] text-accent">{info.name}</span>
              </div>
              <input
                type="range"
                min={0}
                max={stops.length - 1}
                step={1}
                value={Math.max(0, Math.min(idx, stops.length - 1))}
                onChange={(e) => setSliderIdx(Number(e.target.value))}
                onPointerUp={() => {
                  const next = stops[sliderIdx ?? idx];
                  if (next) setThinking(next);
                }}
                onKeyUp={(e) => {
                  if (e.key === 'ArrowLeft' || e.key === 'ArrowRight' || e.key === 'Home' || e.key === 'End') {
                    const next = stops[sliderIdx ?? idx];
                    if (next) setThinking(next);
                  }
                }}
                onBlur={() => {
                  const next = stops[sliderIdx ?? idx];
                  if (next && next !== thinking) setThinking(next);
                }}
                aria-label="思考强度"
                className="h-6 w-full touch-none accent-accent"
              />
              <span className="truncate text-[10px] text-fg-muted">{info.desc}</span>
            </div>
          );
        })()}
        <div className="mx-2.5 my-1 border-t border-border" />
        {/* 模型 = 下拉框(原生 select,Android 上是系统选择器;/model 真列表优先,拉不到回落静态档)。 */}
        <div className="flex items-center gap-2 px-2.5 py-1.5">
          <span className="shrink-0 text-[length:var(--fs-xs)] text-fg-muted">模型</span>
          <select
            value={modelOverride ?? ''}
            onChange={(e) => setModelOverride(e.target.value)}
            aria-label="模型"
            disabled={modelFetching}
            className="min-w-0 flex-1 rounded-[var(--radius-sm)] border border-border bg-input px-2 py-1.5 text-[length:var(--fs-sm)] text-fg outline-none disabled:opacity-60"
          >
            {/* 当前覆盖值不在列表(列表刷新后旧档掉出)→ 兜底补一项,防 select 显示空白 */}
            {(modelOverride && !(modelList ?? []).some((m) => m.value === modelOverride) && modelList
              ? [{ id: modelOverride, name: `${modelOverride}(当前)` }]
              : []
            ).map((m) => (
              <option key={m.id} value={m.id}>
                {m.name}
              </option>
            ))}
            {(modelList
              ? [{ id: '', name: '底座默认' }, ...modelList.map((m) => ({ id: m.value, name: m.displayName }))]
              : MODEL_CHOICES.map((m) => ({ id: m.id, name: m.name }))
            ).map((m) => (
              <option key={m.id || 'default'} value={m.id}>
                {m.name}
              </option>
            ))}
          </select>
        </div>
      </Popover>
    </div>
  );
}
