/**
 * CC 对话插件 manifest —— 终端式 Claude 对话（类似 Happy Coder）。
 *
 * claude 由 ce 端 Agent SDK 结构化驱动（不开终端、不 parse TUI），手机订阅 agentEvents
 * 显示对话、发 stdin 输入、工具卡审批。CC 专属知识（事件→消息归约、工具入参渲染）全住本插件。
 *
 * 平台不硬编码 CC：manifest.contributes.sessions 让平台「+」菜单动态多一项「CC 对话」（卸载即减一项）。
 *
 * M14 后台通知触发器（声明 notify 能力 + 两个后台触发器，数据非代码 —— 平台 TriggerEvaluator 评估）：
 *  - cc-done：CC 完成（turn-end 事件）→ 后台 / 熄屏时弹系统通知「CC 完成」。
 *  - cc-approval：CC 待审批（approval-request 事件）→ 后台 / 熄屏时弹「CC 待审批」。
 */
import type { PluginManifest } from '@core/contract';

const manifest: PluginManifest = {
  id: 'cc-conversation',
  name: 'claude code',
  description: 'Claude Code 移动对话（ce 端 Agent SDK 驱动，结构化呈现文本/工具/审批）。',
  icon: 'claude',
  version: '1.0.0', // 1.0.0:商店取消转「可开启分区」(官方渠道 formal;APP 自带保留 id 隔离) // 0.9.2:菜单自审六修 —— 滑块松手才提交(防拖动连发 RPC)/档位集按用户所选模型/当前值兜底/菜单向上展开不盖输入条
  author: 'Coding Everywhere',
  date: '2026-07',
  usage: '终端 tab「+」→ CC 对话；与 ce 端 claude 对话（需被控机装 claude 并登录）。支持工具审批、后台完成 / 待审通知。',
  // agentEvents 订阅（subscribe）/ readFile 算 diff（read）/ resolveApproval+stdin（write）/ 通知触发器（notify）/
  // exec 探针（开窗检测 claude 是否安装 —— exec 白名单只放 claude）
  capabilities: ['subscribe', 'read', 'write', 'notify', 'exec'],
  permissions: {
    // 算 diff 需读 CC 可能改的任意文件 → readPaths 全开；敏感路径（.env/.ssh/密钥）由 permissions.ts ALWAYS-DENY 兜底
    readPaths: ['/**'],
    // 开窗检测用 exec 跑 `claude --version`;程序名白名单只放 claude(别的命令一律拒)
    execCommands: ['claude'],
  },
  scope: 'server', // CC 跑在被控机（per-server）；agentEvents 由该 server 的 tunnel 推来
  // 服务器级插件(2026-09-24 定案):每台被控机显式装,安装时 preflight 逐项检测被控机环境
  installLevel: 'server',
  requirements: [{ check: 'binary', name: 'claude' }], // 被控机须装 claude(which 可验)
  contributes: {
    // 终端式会话：占一个 tab，entry 指向 main.tsx 的 'CcConversation' export
    sessions: [
      {
        entry: 'CcConversation', // main.tsx 里 export function CcConversation(props: SessionProps)
        sessionType: 'cc',
        label: 'CC 对话',
        icon: 'claude',
        keyBar: false, // 终端式插件是结构化输入，不需要终端按键栏
        folderBound: true, // 在文件夹里干活(该文件夹=CC 的项目)→ 也进文件树「创建」(2026-09-27 定规)
        agent: true, // 编码智能体会话(工坊开发入口的选择清单按此列,2026-09-28)
      },
    ],
  },
  // M14 后台通知触发器：平台评估（manifest.triggers 数据，非代码）；app 后台 / 熄屏时弹系统通知；前台时 toast
  triggers: [
    {
      id: 'cc-done',
      when: 'agentResult', // 命中 turn-end 事件（ce 端 Agent SDK runner 一轮收尾）
      title: 'CC 完成',
      body: 'CC 一轮结束 · {{status}}', // turn-end 带 status（completed/failed）
    },
    {
      id: 'cc-approval',
      when: 'approvalPending', // 命中 approval-request 事件（canUseTool blocking，带 reqId）
      title: 'CC 待审批',
      body: '{{tool}} 等待你的批准',
    },
  ],
};

export default manifest;
