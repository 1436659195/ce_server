/**
 * 消息列表 → 渲染项(纯函数;work group 折叠的核心逻辑,对标 Happy useGroupedMessages)。
 *
 * 三层降噪(从粗到细):
 *  1. work group:已完结的历史轮,中间过程(思考 + 全部已完成工具卡)折成一行「这轮干了 12s · 6 步」;
 *     正在进行的最后一轮(最后一条 user 消息之后)永不折叠,被拒/出错/待审卡永不折叠。
 *  2. readops:最新一轮里连续的 读/查/命令 完成卡折成「N 次读/查/命令」摘要(旧行为,保留)。
 *  3. 过滤:仅改动(隐藏读查噪声)/ 仅待审批。
 *
 * 折叠头可展开看全部成员;组头带 +N −N 改动统计(Edit/Write 卡汇总)。
 */
import type { ConvMessage, ToolCallMsg } from './conversation';
import { diffStat } from './diffstat';
import { isCollapsibleWhenDone } from './knownTools';

export type RenderItem =
  | { kind: 'single'; msg: ConvMessage }
  | { kind: 'readops'; cards: ToolCallMsg[] }
  | {
      kind: 'group';
      /** 被折叠的成员(思考 + 已完成工具卡),按原顺序。 */
      items: ConvMessage[];
      /** 轮次开始时间(首个成员 ts)。 */
      startedAt: number;
      /** 轮次结束时间(末个成员 ts;没有成员时 0 —— 不会发生,组至少 1 项)。 */
      endedAt: number;
      /** turn-end 带来的精确轮耗时(比 ts 差准;老 ce 无 → 用 ts 差)。 */
      durationMs?: number;
      /** 成员里 Edit/Write 类卡的改动合计(+added,−removed)。 */
      diff: { added: number; removed: number };
    };

export type Filter = 'all' | 'writes' | 'pending';

/** 工具卡是否可入 work group(完成且无错;被拒/出错/待审卡保持独立可见 —— 决策和故障不折叠)。 */
function groupable(m: ConvMessage): boolean {
  return m.role === 'tool-call' && m.state === 'completed' && !m.isError;
}

/** 一张工具卡的改动量(Edit/MultiEdit/Write;其他工具 0)。 */
function cardDiff(m: ConvMessage): { added: number; removed: number } {
  if (m.role !== 'tool-call') return { added: 0, removed: 0 };
  const i = m.input as Record<string, unknown>;
  const str = (v: unknown): string => (typeof v === 'string' ? v : '');
  if (m.tool === 'Edit') {
    return diffStat(str(i.old_string), str(i.new_string));
  }
  if (m.tool === 'Write') {
    // Write 无旧文(全新文件)→ 全新增;覆写场景旧文手机拿不到,统计按新增算(与 Happy 一致)
    return diffStat('', str(i.content));
  }
  if (m.tool === 'MultiEdit' && Array.isArray(i.edits)) {
    let added = 0;
    let removed = 0;
    for (const e of i.edits as Array<{ old_string?: unknown; new_string?: unknown }>) {
      const s = diffStat(str(e?.old_string), str(e?.new_string));
      added += s.added;
      removed += s.removed;
    }
    return { added, removed };
  }
  return { added: 0, removed: 0 };
}

/** 把消息列表转成渲染项(主入口)。 */
export function buildRenderItems(messages: ConvMessage[], filter: Filter): RenderItem[] {
  if (filter !== 'all') return buildFiltered(messages, filter);

  const items: RenderItem[] = [];

  // 活跃区下界:最后一条 user 消息;没有 user 消息(极端:restore 的纯 agent 流)→ 最后一个
  // turn-end 系统标记之后;连标记都没有 → 全活跃(首轮未完结,什么都不能折)。
  let historyEnd = 0;
  for (let i = messages.length - 1; i >= 0; i--) {
    const m = messages[i]!;
    if (m.role === 'user') {
      historyEnd = i;
      break;
    }
    if (m.role === 'system' && (m.text === 'CC 已完成' || m.text === 'CC 出错')) {
      historyEnd = i + 1; // 标记本身归历史(它的轮已完结)
      break;
    }
  }

  // ── 历史区:相邻的 groupable 卡 + 思考 → 折成一个 work group(文本/系统/被拒/出错卡保持独立)。
  let buf: ConvMessage[] = [];
  let diff = { added: 0, removed: 0 };
  let lastWasGroup = false;
  const flushGroup = (): void => {
    if (buf.length === 0) return;
    items.push({
      kind: 'group',
      items: buf,
      startedAt: buf[0]!.ts,
      endedAt: buf[buf.length - 1]!.ts,
      diff,
    });
    buf = [];
    diff = { added: 0, removed: 0 };
    lastWasGroup = true;
  };
  for (let i = 0; i < historyEnd; i++) {
    const m = messages[i]!;
    const foldable = m.role === 'assistant' && m.isThinking === true ? true : groupable(m);
    if (foldable) {
      buf.push(m);
      const d = cardDiff(m);
      diff = { added: diff.added + d.added, removed: diff.removed + d.removed };
      continue;
    }
    flushGroup();
    // 「CC 已完成」胶囊被组头取代(组头自带耗时/步数);没有组头接替(纯问答轮)→ 保留。
    if (m.role === 'system' && m.text === 'CC 已完成' && lastWasGroup) continue;
    items.push({ kind: 'single', msg: m });
  }
  flushGroup();

  // ── 活跃区:旧行为(连续读查折 readops)。
  appendLive(items, messages.slice(historyEnd));
  return items;
}

/** 活跃区渲染:连续 ≥2 张 读/查/命令 完成卡 → readops 摘要;单张不折(一张卡不值得一个组)。 */
function appendLive(items: RenderItem[], msgs: ConvMessage[]): void {
  let buf: ToolCallMsg[] = [];
  const flush = (): void => {
    if (buf.length >= 2) items.push({ kind: 'readops', cards: buf });
    else for (const c of buf) items.push({ kind: 'single', msg: c });
    buf = [];
  };
  for (const m of msgs) {
    const noise = m.role === 'tool-call' && m.state === 'completed' && !m.isError && isCollapsibleWhenDone(m.tool);
    if (noise) {
      buf.push(m as ToolCallMsg);
    } else {
      flush();
      items.push({ kind: 'single', msg: m });
    }
  }
  flush();
}

/** 过滤视图(仅改动 / 仅待审批):不折组,直接按谓词留单条(原行为)。 */
function buildFiltered(messages: ConvMessage[], filter: Filter): RenderItem[] {
  const items: RenderItem[] = [];
  for (const m of messages) {
    if (filter === 'writes') {
      // 隐藏读/查/Bash 噪声,聚焦改文件/出错/待审
      if (m.role === 'tool-call' && m.state === 'completed' && !m.isError && isCollapsibleWhenDone(m.tool)) continue;
      // 历史轮的完成胶囊也藏(组头不存在于此视图;信息由改动卡自身承载)
      if (m.role === 'system' && m.text === 'CC 已完成') continue;
    } else {
      // pending:只留待审卡 + 文本/系统上下文(隐藏已完成/已拒卡)
      if (m.role === 'tool-call' && m.state !== 'pending') continue;
    }
    items.push({ kind: 'single', msg: m });
  }
  return items;
}
