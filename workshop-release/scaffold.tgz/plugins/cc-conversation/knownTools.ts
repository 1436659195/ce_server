/**
 * CC 工具元数据注册表 —— 对标 Happy Coder 的 knownTools.tsx(单一事实源)。
 *
 * 每个 CC 工具的 类别 / 标题 / 图标 / 完成是否折叠 全集中在此。
 * ce 与 core 不知「Write 是改文件」「Read 是读」—— 这层 CC 专属知识住本插件
 * (守 CLAUDE.md 第 4 条:不为某个 agent 单独造 ce 接口,平台只当哑管道)。
 *
 * 消费方:
 *  - events.ts 的 isEditTool / isCollapsibleWhenDone(re-export,向后兼容旧导入 + 测试)。
 *  - CcConversation 工具卡头部(图标)、buildRenderItems(折叠判断)。
 *  - views/_all.tsx 按 category 决定紧凑行 / 卡片(预留 minimal)。
 *
 * 未列出的工具 / mcp__* → getToolMeta 返 'other' / 'mcp' 兜底,不崩(CC 加新工具零改动)。
 */
import {
  Bot,
  FileDiff,
  FileEdit,
  FilePlus,
  FileSearch,
  Folder,
  FolderSearch,
  GitBranch,
  Globe,
  HelpCircle,
  ListChecks,
  NotebookPen,
  Puzzle,
  Rocket,
  Search,
  SquareTerminal,
  type LucideIcon,
} from 'lucide-react';

export type ToolCategory = 'edit' | 'exec' | 'read-query' | 'plan' | 'interact' | 'mcp' | 'other';

export interface ToolMeta {
  category: ToolCategory;
  /** 卡片标题(展示用;头部仍显原始 tool 名以稳定可读 + 测试断言)。 */
  title?: string;
  icon?: LucideIcon;
  /** completed 且无错 → 折叠进「N 次读/查/命令」摘要(减噪)。 */
  collapsible?: boolean;
}

/** 已知 CC 工具注册表。未列出 → getToolMeta 返 {category:'other'} 兜底。 */
export const knownTools: Record<string, ToolMeta> = {
  // 改文件(auto-edit 自动放行集;对齐 ce 端 PreToolUse 写类拦截)
  Write: { category: 'edit', title: '写文件', icon: FilePlus },
  Edit: { category: 'edit', title: '编辑', icon: FileEdit },
  MultiEdit: { category: 'edit', title: '批量编辑', icon: FileDiff },
  NotebookEdit: { category: 'edit', title: '编辑 Notebook', icon: NotebookPen },
  // 执行
  Bash: { category: 'exec', title: '命令', icon: SquareTerminal, collapsible: true },
  // 读 / 查(完成折叠,减噪)
  Read: { category: 'read-query', title: '读文件', icon: FileSearch, collapsible: true },
  Grep: { category: 'read-query', title: '搜索内容', icon: Search, collapsible: true },
  Glob: { category: 'read-query', title: '查找文件', icon: FolderSearch, collapsible: true },
  LS: { category: 'read-query', title: '列目录', icon: Folder, collapsible: true },
  WebFetch: { category: 'read-query', title: '抓取网页', icon: Globe, collapsible: true },
  WebSearch: { category: 'read-query', title: '搜索网页', icon: Globe, collapsible: true },
  // 计划 / 子任务
  Task: { category: 'plan', title: '子任务', icon: Rocket },
  Agent: { category: 'plan', title: '子代理', icon: Bot },
  TodoWrite: { category: 'plan', title: '待办清单', icon: ListChecks },
  ExitPlanMode: { category: 'plan', title: '退出计划', icon: GitBranch },
  // 交互
  AskUserQuestion: { category: 'interact', title: '向你提问', icon: HelpCircle },
};

/** 取工具元数据。mcp__* 前缀 → 通用 mcp 项(标题去前缀);未知 → {category:'other'} 兜底。 */
export function getToolMeta(tool: string): ToolMeta {
  if (tool.startsWith('mcp__')) {
    return { category: 'mcp', title: tool.replace(/^mcp__/, ''), icon: Puzzle };
  }
  return knownTools[tool] ?? { category: 'other' };
}

/** 工具是否算「改文件」(auto-edit 模式自动放行;对齐 events 旧 isEditTool 语义)。 */
export function isEditTool(tool: string): boolean {
  return getToolMeta(tool).category === 'edit';
}

/** 工具完成(无错)时是否折叠进摘要(读/查/命令减噪)。 */
export function isCollapsibleWhenDone(tool: string): boolean {
  return getToolMeta(tool).collapsible === true;
}
