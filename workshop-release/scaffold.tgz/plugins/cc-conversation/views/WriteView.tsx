/**
 * Write 工具视图:文件名 + 异步 readFile 取旧内容算 diff(取不到/新文件/二进制 → 降级只显新内容)。
 * 从旧 WriteDiff 抽出(行为零变化)。CC file_path 是 OS 绝对路径,readFile 走 Jupyter 多半取不到 → 降级。
 */
import { useEffect, useState } from 'react';
import { CodeBlock, DiffView } from '@core/shared';
import { diffStat } from '../diffstat';
import type { ToolViewProps } from './types';
import { DiffStatBadge } from './DiffStatBadge';

export function WriteView({ msg, ctx }: ToolViewProps) {
  const filePath = typeof msg.input.file_path === 'string' ? msg.input.file_path : '';
  const newText = typeof msg.input.content === 'string' ? msg.input.content : '';
  const [oldText, setOldText] = useState<string | null>(null);

  useEffect(() => {
    // 无新内容(content)→ 没东西可 diff,不读旧文件(对齐旧行为:Write 无 content 不发 readFile)。
    if (!filePath || !newText) return;
    let alive = true;
    ctx.rpc
      .invoke({ op: 'read', kind: 'readFile', path: filePath, scope: ctx.scope })
      .then((res) => {
        if (alive && !res.tooLarge && !res.binary && typeof res.text === 'string') setOldText(res.text);
      })
      .catch(() => undefined);
    return () => {
      alive = false;
    };
  }, [filePath, newText, ctx]);

  const stat = diffStat('', newText);
  return (
    <div className="flex flex-col gap-1.5">
      {filePath && (
        <div className="flex items-center gap-2">
          <span className="break-all text-[length:var(--fs-xs)] text-fg-muted">{filePath}</span>
          <DiffStatBadge {...stat} />
        </div>
      )}
      {/* 先显新内容(无 flash),拿到旧内容后升级成 diff */}
      {oldText === null ? (
        <CodeBlock code={newText.slice(0, 4000)} lang="text" />
      ) : (
        <DiffView oldText={oldText} newText={newText.slice(0, 4000)} />
      )}
    </div>
  );
}
