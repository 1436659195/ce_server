/**
 * TodoWrite 工具视图:待办清单 + 进度(claudecodeui 的 TodoList 同款)。
 *  - 顶部细进度条(完成占比)+「2/5」;
 *  - 三态:完成 = 勾 + 划线置灰;进行中 = 蓝点脉冲 + 高亮;待办 = 空圈;
 *  - CC input:{todos:[{content,status:'pending'|'in_progress'|'completed',...}]}。
 */
import { Check, Circle, Loader } from 'lucide-react';
import type { ToolViewProps } from './types';

interface Todo {
  content?: string;
  status?: string;
}

export function TodoView({ msg }: ToolViewProps) {
  const todos = (Array.isArray(msg.input.todos) ? msg.input.todos : []) as Todo[];
  if (!todos.length) return null;
  const done = todos.filter((t) => t?.status === 'completed').length;
  return (
    <div className="flex flex-col gap-1.5">
      <div className="flex items-center gap-2">
        <div className="h-1 flex-1 overflow-hidden rounded-full bg-input">
          <div
            className="h-full rounded-full bg-success transition-all"
            style={{ width: `${Math.round((done / todos.length) * 100)}%` }}
          />
        </div>
        <span className="shrink-0 font-mono text-[length:var(--fs-xs)] text-fg-muted">
          {done}/{todos.length}
        </span>
      </div>
      <div className="flex flex-col gap-1">
        {todos.map((t, i) => {
          const status = typeof t?.status === 'string' ? t.status : 'pending';
          const content = typeof t?.content === 'string' ? t.content : '';
          const isActive = status === 'in_progress';
          const Icon = status === 'completed' ? Check : isActive ? Loader : Circle;
          return (
            <div
              key={i}
              className={`flex items-start gap-1.5 text-[length:var(--fs-xs)] ${
                status === 'completed' ? 'text-fg-muted line-through' : isActive ? 'text-accent' : 'text-fg'
              }`}
            >
              <Icon
                size={13}
                className={`mt-0.5 shrink-0 ${isActive ? 'ce-cc-pulse-dot' : ''} ${
                  status === 'completed' ? 'text-success' : ''
                }`}
              />
              <span className="break-all">
                {content}
                {isActive && <span className="ml-1.5 text-[10px] opacity-70">← 进行中</span>}
              </span>
            </div>
          );
        })}
      </div>
    </div>
  );
}
