/**
 * Bash 工具视图:终端风命令行(对标 Happy CommandView)—— 恒深色底、绿色 `$` 前缀、
 * 命令白字 mono。输出不在这里:stdout 由 ToolCallCard 折叠成「N 行输出」(BashOutputView)。
 */
import type { ToolViewProps } from './types';

export function BashView({ msg }: ToolViewProps) {
  const command = typeof msg.input.command === 'string' ? msg.input.command : '';
  if (!command) return null;
  return (
    <div className="rounded-[var(--radius-sm)] bg-[#1E1E1E] px-3 py-2">
      <div className="flex items-baseline gap-2 font-mono text-[length:var(--fs-sm)] leading-relaxed">
        <span className="shrink-0 font-semibold text-[#34C759]">$</span>
        <span className="whitespace-pre-wrap break-all text-[#E0E0E0]">{command}</span>
      </div>
    </div>
  );
}
