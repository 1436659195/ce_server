/**
 * AskUserQuestion 工具视图(聊天内记录,running/completed 态)。
 *
 *  - 待审【交互】在 ToolCallCard 的 AskAnswerPanel(radio/checkbox 选中 + 提交);
 *  - 本视图是流里的记录:未答显问题+选项只读行;已答(Happy 同款)收起成「header: 答案」回显。
 * 入参解析走 askInput.parseAskInput(2026-10-01 修:CC 真实 schema 是嵌套 questions[])。
 */
import { parseAskInput } from '../askInput';
import type { ToolViewProps } from './types';

export function AskUserQuestionView({ msg }: ToolViewProps) {
  const questions = parseAskInput(msg.input);
  const answered = msg.answers;

  // 已答 → 回显「header: 答案」(Happy submitted 态;键是问题原文)
  if (answered && Object.keys(answered).length > 0) {
    return (
      <div className="flex flex-col gap-1">
        {questions.map((q, qi) => (
          <div key={qi} className="flex items-baseline gap-1.5">
            {q.header && <span className="shrink-0 text-fg-muted">{q.header}:</span>}
            <span className="text-fg">{answered[q.question] ?? '—'}</span>
          </div>
        ))}
        {/* 兜底:答案键与问题对不上(异常场景)也把原始键值显出来,不吞 */}
        {questions.length === 0 &&
          Object.entries(answered).map(([k, v]) => (
            <div key={k} className="flex items-baseline gap-1.5">
              <span className="text-fg">{v}</span>
            </div>
          ))}
      </div>
    );
  }

  return (
    <div className="flex flex-col gap-1.5">
      {questions.map((q, qi) => (
        <div key={qi} className="flex flex-col gap-1">
          {q.question && (
            <div className="whitespace-pre-wrap break-words text-[length:var(--fs-sm)] text-fg">
              {q.header && <span className="mr-1.5 text-accent">[{q.header}]</span>}
              {q.question}
            </div>
          )}
          {q.options.length > 0 && (
            <div className="flex flex-col gap-0.5">
              {q.options.map((o, i) => (
                <div key={i} className="flex items-baseline gap-1.5 truncate">
                  <span className="shrink-0 text-accent">{o.label}</span>
                  {o.description && <span className="truncate text-fg-muted">{o.description}</span>}
                </div>
              ))}
            </div>
          )}
        </div>
      ))}
    </div>
  );
}
