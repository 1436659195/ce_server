/**
 * MultiEdit 工具视图:文件名 + 每条 edit 一段 diff(edits:[{old_string,new_string,replace_all}])。
 */
import { DiffView } from '@core/shared';
import { diffStat } from '../diffstat';
import type { ToolViewProps } from './types';
import { DiffStatBadge } from './DiffStatBadge';

export function MultiEditView({ msg }: ToolViewProps) {
  const filePath = typeof msg.input.file_path === 'string' ? msg.input.file_path : '';
  const edits = Array.isArray(msg.input.edits) ? msg.input.edits : [];
  // 合并统计:逐段累加(不模拟应用 —— 徽章只要量级感,重叠替换的误差可接受)
  const stat = edits.reduce(
    (acc, e) => {
      const o = typeof e?.old_string === 'string' ? e.old_string : '';
      const n = typeof e?.new_string === 'string' ? e.new_string : '';
      const s = diffStat(o, n);
      return { added: acc.added + s.added, removed: acc.removed + s.removed };
    },
    { added: 0, removed: 0 },
  );
  return (
    <div className="flex flex-col gap-1.5">
      {filePath && (
        <div className="flex items-center gap-2">
          <span className="break-all text-[length:var(--fs-xs)] text-fg-muted">{filePath}</span>
          <DiffStatBadge {...stat} />
        </div>
      )}
      {edits.map((e, i) => {
        const o = typeof e?.old_string === 'string' ? e.old_string : '';
        const n = typeof e?.new_string === 'string' ? e.new_string : '';
        return <DiffView key={i} oldText={o} newText={n} />;
      })}
    </div>
  );
}
