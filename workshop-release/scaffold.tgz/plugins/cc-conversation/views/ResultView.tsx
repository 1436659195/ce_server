/**
 * 工具结果渲染(ToolCallCard completed 态的内容区)。
 *
 * 修 base64 天书:tool_result 的 content 数组里 type:'image' 块(CC 截图/读图返回)
 * 之前被塞进 <pre>/JSONViewer 刷一屏 base64 —— 现在渲染成真图(圆角限宽,点击全屏看)。
 * 文本块照旧截断;未知形状回落 JSONViewer。
 */
import { useState } from 'react';
import { JSONViewer } from '@core/shared';
import { X } from 'lucide-react';

const TEXT_MAX = 2000;

type Block = { kind: 'text'; text: string } | { kind: 'image'; mediaType: string; data: string };

/** content block 的松散形状(SDK tool_result:字符串或块数组)。 */
interface RawBlock {
  type?: string;
  text?: string;
  source?: { type?: string; media_type?: string; data?: string };
}

/** result → 可渲染块序列。字符串 = 单文本;块数组 = 拆 text/image;其他(对象) = json 兜底。 */
function blocksOf(result: unknown): Block[] | { kind: 'json' } {
  if (result === undefined || result === null) return [];
  if (typeof result === 'string') return [{ kind: 'text', text: result }];
  if (Array.isArray(result)) {
    const out: Block[] = [];
    for (const b of result as RawBlock[]) {
      if (b && b.type === 'image' && b.source?.type === 'base64' && typeof b.source.data === 'string') {
        out.push({ kind: 'image', mediaType: b.source.media_type ?? 'image/png', data: b.source.data });
      } else if (b && b.type === 'text' && typeof b.text === 'string') {
        out.push({ kind: 'text', text: b.text });
      }
    }
    return out;
  }
  return { kind: 'json' };
}

/** result 里有没有图片块(Read 工具读图 → 结果必须显示,不能按读类噪声藏掉)。 */
export function hasImageBlock(result: unknown): boolean {
  if (!Array.isArray(result)) return false;
  return (result as RawBlock[]).some((b) => b && b.type === 'image');
}

/** 图片查看器(点击全屏,再点关闭 —— 手机审查截图的最小可用放大)。 */
function ImageLightbox({ src, onClose }: { src: string; onClose: () => void }) {
  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 p-4"
      onClick={onClose}
      role="presentation"
    >
      <img src={src} alt="工具输出图片" className="max-h-full max-w-full rounded-[var(--radius-md)]" />
      <button
        type="button"
        aria-label="关闭"
        onClick={onClose}
        className="absolute right-4 top-4 flex size-9 items-center justify-center rounded-full bg-white/15 text-white tap-scale"
      >
        <X size={18} />
      </button>
    </div>
  );
}

export function ResultView({ result }: { result: unknown }) {
  const [lightbox, setLightbox] = useState<string | null>(null);
  const blocks = blocksOf(result);
  if (Array.isArray(blocks) && blocks.length === 0) return null;

  if (!Array.isArray(blocks)) {
    return (
      <div className="mt-1.5 max-h-[20vh] overflow-auto rounded-[var(--radius-sm)] bg-input p-1.5 text-[length:var(--fs-xs)] text-fg-muted">
        <JSONViewer data={result} />
      </div>
    );
  }

  return (
    <div className="mt-1.5 flex max-h-[40vh] flex-col gap-1.5 overflow-auto rounded-[var(--radius-sm)] bg-input p-1.5 text-[length:var(--fs-xs)] text-fg-muted">
      {blocks.map((b, i) =>
        b.kind === 'text' ? (
          <pre key={i} className="whitespace-pre-wrap break-all">
            {b.text.length > TEXT_MAX ? `${b.text.slice(0, TEXT_MAX)}…(截断)` : b.text}
          </pre>
        ) : (
          (() => {
            const src = `data:${b.mediaType};base64,${b.data}`;
            return (
              <button
                key={i}
                type="button"
                onClick={() => setLightbox(src)}
                className="overflow-hidden rounded-[var(--radius-sm)] border border-border"
                aria-label="查看图片"
              >
                <img src={src} alt="工具输出图片" className="max-h-64 w-auto max-w-full" />
              </button>
            );
          })()
        ),
      )}
      {lightbox && <ImageLightbox src={lightbox} onClose={() => setLightbox(null)} />}
    </div>
  );
}

/** Bash 完成态输出:默认只显「N 行输出」可展开(对标 claudecodeui 折叠态行数;错误永远全显由调用方控制)。 */
export function BashOutputView({ result }: { result: unknown }) {
  const [open, setOpen] = useState(false);
  const text =
    typeof result === 'string'
      ? result
      : Array.isArray(result)
        ? (result as RawBlock[])
            .filter((b) => b && b.type === 'text' && typeof b.text === 'string')
            .map((b) => b.text)
            .join('\n')
        : '';
  const lines = text ? text.replace(/\n$/, '').split('\n').length : 0;
  if (!lines) return null;
  if (!open) {
    return (
      <button
        type="button"
        onClick={() => setOpen(true)}
        className="mt-1.5 rounded-[var(--radius-sm)] bg-input px-2 py-1 text-left text-[length:var(--fs-xs)] text-fg-muted"
      >
        {lines} 行输出
      </button>
    );
  }
  return (
    <div className="mt-1.5 max-h-[40vh] overflow-auto rounded-[var(--radius-sm)] bg-input p-1.5 text-[length:var(--fs-xs)] text-fg-muted">
      <pre className="whitespace-pre-wrap break-all">
        {text.length > TEXT_MAX ? `${text.slice(0, TEXT_MAX)}…(截断)` : text}
      </pre>
    </div>
  );
}
