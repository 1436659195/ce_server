/**
 * 默认 / 兜底工具视图:未知工具 + MCP 工具(mcp__*)→ JSON 展示入参。
 * 保证 CC 新增工具 / 未特化工具不崩(对标 Happy DefaultToolView 的 JSON 回退)。
 */
import { JSONViewer } from '@core/shared';
import type { ToolViewProps } from './types';

export function DefaultToolView({ msg }: ToolViewProps) {
  return <JSONViewer data={msg.input} />;
}
