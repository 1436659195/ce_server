/**
 * Task / Agent(子代理)工具视图:只渲染 subagent_type + description 描述行。
 *
 * 子代理的内部消息(children)由 ToolCallCard 统一递归渲染(完整 MessageView 嵌套,
 * 对标 Happy ToolCall.children)—— 本视图保持纯叶子,避免 views → CcConversation 循环依赖。
 * CC input:{description, subagent_type, prompt, ...}。
 */
import type { ToolViewProps } from './types';

export function TaskView({ msg }: ToolViewProps) {
  const description = typeof msg.input.description === 'string' ? msg.input.description : '';
  const subagentType = typeof msg.input.subagent_type === 'string' ? msg.input.subagent_type : '';
  if (!description && !subagentType) return null;
  return (
    <div className="text-[length:var(--fs-xs)] text-fg-muted">
      {subagentType && <span className="text-accent">{subagentType}</span>}
      {subagentType && description && ' '}
      <span className="break-all">{description}</span>
    </div>
  );
}
