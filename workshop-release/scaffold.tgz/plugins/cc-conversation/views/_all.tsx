/**
 * 工具视图分发注册表 —— 对标 Happy Coder 的 views/_all.tsx。
 *
 * 按 tool 名分发到专用视图组件;未注册 → DefaultToolView(JSON 回退);
 * mcp__* 前缀 → DefaultToolView(通用)。getToolViewComponent 是唯一分发入口。
 *
 * 新增工具特化 = 在 toolViewRegistry 加一行 + 建 views/XxxView.tsx;不动 CcConversation。
 */
import type { ComponentType } from 'react';
import type { ToolViewProps } from './types';
import { AskUserQuestionView } from './AskUserQuestionView';
import { BashView } from './BashView';
import { DefaultToolView } from './DefaultToolView';
import { EditView } from './EditView';
import { ExitPlanView } from './ExitPlanView';
import { MultiEditView } from './MultiEditView';
import { ReadQueryView } from './ReadQueryView';
import { TaskView } from './TaskView';
import { TodoView } from './TodoView';
import { WriteView } from './WriteView';

/** 工具名 → 视图组件 的注册表。 */
export const toolViewRegistry: Record<string, ComponentType<ToolViewProps>> = {
  // 改文件(diff)
  Edit: EditView,
  Write: WriteView,
  MultiEdit: MultiEditView,
  // 执行
  Bash: BashView,
  // 读 / 查(紧凑行)
  Read: ReadQueryView,
  Grep: ReadQueryView,
  Glob: ReadQueryView,
  LS: ReadQueryView,
  WebFetch: ReadQueryView,
  WebSearch: ReadQueryView,
  // 计划 / 子任务
  Task: TaskView,
  Agent: TaskView,
  TodoWrite: TodoView,
  ExitPlanMode: ExitPlanView,
  // 交互
  AskUserQuestion: AskUserQuestionView,
};

/** 取工具的专用视图;mcp__* 与未注册工具 → DefaultToolView(JSON 回退)。 */
export function getToolViewComponent(tool: string): ComponentType<ToolViewProps> {
  if (tool.startsWith('mcp__')) return DefaultToolView;
  return toolViewRegistry[tool] ?? DefaultToolView;
}

/** 工具卡内容区分发(ToolCallCard 唯一调用点)。 */
export function ToolBody({ msg, ctx }: ToolViewProps) {
  const View = getToolViewComponent(msg.tool);
  return <View msg={msg} ctx={ctx} />;
}

// re-export 类型供 CcConversation 复用
export type { ToolViewProps } from './types';
