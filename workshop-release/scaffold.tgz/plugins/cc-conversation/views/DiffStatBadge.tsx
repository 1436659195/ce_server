/**
 * diff 统计徽章(+N −N)—— claudecodeui 的 DiffStatsBadge 同款:绿/索单色,一眼改动量。
 * added=0 隐藏 + 段,removed=0 隐藏 − 段;两者都 0 返 null。
 */
export function DiffStatBadge({ added, removed }: { added: number; removed: number }) {
  if (added === 0 && removed === 0) return null;
  return (
    <span className="inline-flex shrink-0 items-center gap-1 font-mono text-[length:var(--fs-xs)]">
      {added > 0 && <span className="text-success">+{added}</span>}
      {removed > 0 && <span className="text-danger">−{removed}</span>}
    </span>
  );
}
