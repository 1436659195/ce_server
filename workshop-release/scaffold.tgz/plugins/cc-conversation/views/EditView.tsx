/**
 * Edit 工具视图:文件名 + 内联 diff(old_string → new_string,无需 readFile)。
 * 从旧 DiffPreview(Edit 分支)+ ToolInput 抽出。CC 专属:知 Edit 的字段。
 */
import { DiffView } from '@core/shared';
import { diffStat } from '../diffstat';
import type { ToolViewProps } from './types';
import { DiffStatBadge } from './DiffStatBadge';

export function EditView({ msg }: ToolViewProps) {
  const filePath = typeof msg.input.file_path === 'string' ? msg.input.file_path : '';
  const oldText = typeof msg.input.old_string === 'string' ? msg.input.old_string : '';
  const newText = typeof msg.input.new_string === 'string' ? msg.input.new_string : '';
  const stat = diffStat(oldText, newText);
  return (
    <div className="flex flex-col gap-1.5">
      {filePath && (
        <div className="flex items-center gap-2">
          <span className="break-all text-[length:var(--fs-xs)] text-fg-muted">{filePath}</span>
          <DiffStatBadge {...stat} />
        </div>
      )}
      <DiffView oldText={oldText} newText={newText} />
    </div>
  );
}
