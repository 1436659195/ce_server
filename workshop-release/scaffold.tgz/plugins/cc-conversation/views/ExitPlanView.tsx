/**
 * ExitPlanMode 工具视图:展示计划正文(plan 字段)。CC 退出计划模式时携带的计划总结。
 */
import type { ToolViewProps } from './types';

export function ExitPlanView({ msg }: ToolViewProps) {
  const plan = typeof msg.input.plan === 'string' ? msg.input.plan : '';
  if (!plan) return null;
  return (
    <div className="whitespace-pre-wrap break-words text-[length:var(--fs-sm)] text-fg">{plan}</div>
  );
}
