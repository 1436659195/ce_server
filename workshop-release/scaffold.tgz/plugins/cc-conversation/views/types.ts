/**
 * 工具视图层共享类型 —— 对标 Happy Coder 的 ToolViewProps。
 * 与 CcConversation 解耦:视图只依赖 ConvMessage(归约后的块)+ ctx.rpc,不碰 core 内部。
 */
import type { SessionProps } from '@core/contract';
import type { ToolCallMsg } from '../conversation';

/** 插件 ctx 的类型(用索引访问,免直 import core 内部 PluginContext,守 import barrier)。 */
export type Ctx = SessionProps['ctx'];

/** 每个工具视图的统一入参(对标 Happy ToolViewProps)。 */
export interface ToolViewProps {
  msg: ToolCallMsg;
  ctx: Ctx;
}
