/**
 * 状态条(对标 Happy AgentInputStatusRow + StatusDot)—— 输入框上方一行,给「CC 活着没」的实时反馈。
 *
 * 三态(优先级从高到低):
 *  - waiting:有工具待审批 → 橙点脉冲 +「N 个操作等你批准」(#FF9500,Happy 同色)。
 *  - running:回合进行中 → 蓝点脉冲 + shimmer 动词(轮换)+ 耗时(1s 步进;Happy:点 2s 脉冲/词随机)。
 *  - idle:不渲染(整行隐藏,不占视线)。
 *
 * 状态全部由手机侧派生(turnSince / pendingCount),不依赖 ce 新事件 —— 老 ce 也能用。
 */
import { useEffect, useMemo, useState } from 'react';
import { formatElapsed } from '../ui';

/** 运行动词池(产品性格所在;Happy 88 个英文词的中文对偶,4s 一换)。 */
const VERBS = [
  '推敲中',
  '翻找中',
  '琢磨中',
  '敲打中',
  '比对中',
  '梳理中',
  '检索中',
  '推演中',
  '打磨中',
  '翻检中',
  '构思中',
  '核对中',
  '酝酿中',
  '掘进中',
  '编织中',
  '校准中',
];

const pickVerb = (): string => VERBS[Math.floor(Math.random() * VERBS.length)]!;

/** 每秒跳一次的 now(仅 active 时起 interval;elapsed 计时用)。 */
function useTick(active: boolean): number {
  const [now, setNow] = useState(() => Date.now());
  useEffect(() => {
    if (!active) return;
    const t = setInterval(() => setNow(Date.now()), 1000);
    return () => clearInterval(t);
  }, [active]);
  return now;
}

export function StatusBar({
  running,
  runningSince,
  pendingCount,
  model,
}: {
  running: boolean;
  runningSince: number | null;
  pendingCount: number;
  /** 模型名(session-init 带来,B 层 ce;老 ce 无 → 不显)。 */
  model?: string;
}) {
  const waiting = pendingCount > 0;
  // 跑动词:进入 running 时随机选一个;每 4s 换(Happy 是 state 变化才换,我们加 4s 轮换更有活感)。
  const [verb, setVerb] = useState(pickVerb);
  useEffect(() => {
    if (!running) return;
    setVerb(pickVerb());
    const t = setInterval(() => setVerb(pickVerb()), 4000);
    return () => clearInterval(t);
  }, [running]);
  const now = useTick(running && !waiting);
  const elapsed = useMemo(
    () => (running && runningSince !== null ? formatElapsed(now - runningSince) : ''),
    [running, runningSince, now],
  );

  if (!running && !waiting) return null;
  if (waiting) {
    return (
      <div className="flex min-h-5 items-center gap-1.5 px-0.5 text-[length:var(--fs-xs)] text-[#FF9500]">
        <span className="ce-cc-pulse-dot inline-block size-1.5 rounded-full bg-[#FF9500]" />
        <span>
          {pendingCount} 个操作等你批准 —— CC 停在原地,批了才继续
        </span>
      </div>
    );
  }
  return (
    <div className="flex min-h-5 items-center gap-1.5 px-0.5 text-[length:var(--fs-xs)] text-accent">
      <span className="ce-cc-pulse-dot inline-block size-1.5 rounded-full bg-accent" />
      <span className="ce-cc-shimmer font-medium" style={{ '--ce-cc-shimmer-hl': 'rgba(125,211,252,0.9)' } as React.CSSProperties}>
        {verb}…
      </span>
      {elapsed && <span className="font-mono opacity-60">{elapsed}</span>}
      {model && <span className="ml-auto truncate font-mono opacity-40">{model}</span>}
    </div>
  );
}
