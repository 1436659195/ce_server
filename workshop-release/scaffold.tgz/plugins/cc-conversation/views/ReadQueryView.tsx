/**
 * 读/查类工具视图(Read/Grep/Glob/LS/WebFetch/WebSearch):紧凑一行(路径/pattern/url/query)。
 * 这类工具完成态还会被 buildRenderItems 折叠进「N 次读/查/命令」摘要(见 CcConversation)。
 */
import type { ToolViewProps } from './types';

export function ReadQueryView({ msg }: ToolViewProps) {
  const i = msg.input;
  const detail =
    (typeof i.file_path === 'string' && i.file_path) ||
    (typeof i.pattern === 'string' && `/${i.pattern}/`) ||
    (typeof i.path === 'string' && i.path) ||
    (typeof i.url === 'string' && i.url) ||
    (typeof i.query === 'string' && i.query) ||
    '';
  return (
    <div className="break-all text-[length:var(--fs-xs)] text-fg-muted">
      {detail || '(无参数)'}
    </div>
  );
}
