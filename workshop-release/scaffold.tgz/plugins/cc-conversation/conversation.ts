/**
 * CC 对话窗口 —— 消息模型 + reducer(纯函数,易测)。
 *
 * 把 ce 侧 agent-runner 推来的**结构化 AgentEvent**(text/thinking/tool-call-start/end/turn-end/
 * approval-request/resolved)归约成有序消息列表,给 CcConversation 渲染。CC 专属知识(事件→消息归约)
 * 住本文件 = 插件里(ce 是哑管道,平台不知 CC 是何物)。
 *
 * 不再 strip ANSI / 订阅 terminalOutput —— claude 由 ce 端 Agent SDK 结构化驱动(非 TUI),
 * 文本/thinking/工具调用都是结构化事件,无 ANSI 噪声(治旧版「TUI 输出乱码」根因)。
 *
 * 消息类型(对齐 Happy Coder 的 4 类 + 工具卡状态机):
 *  - user       用户输入(底部 input 发的 stdin,本地回显)
 *  - assistant  claude 文本回复(text 事件累积;isThinking=true 是思考块,折叠显示)
 *  - tool-call  工具调用卡(state:running→[pending 审批]→completed/denied;callId 贯穿 start/approval/end)
 *  - system     系统消息(turn-end:CC 完成 / 出错)
 */
import { eventParentCallId, type AgentEvent } from './events';

/** 工具卡状态机:running 执行中 / pending 待审批 / completed 完成 / denied 已拒。 */
export type ToolState = 'running' | 'pending' | 'completed' | 'denied';

export type ConvMessage =
  | {
      id: string;
      role: 'user';
      text: string;
      ts: number;
      /** 乐观排队:CC 还在跑上一轮时发出(InputQueue 里排着)→ 气泡半透明 + 「本轮结束后发送」。 */
      queued?: boolean;
    }
  | { id: string; role: 'assistant'; text: string; ts: number; isThinking?: boolean }
  | {
      id: string;
      role: 'tool-call';
      callId: string;
      tool: string;
      input: Record<string, unknown>;
      state: ToolState;
      /** 审批 reqId(approval-request 带来;resolveApproval 回传用它)。无 = 不需审批(读类工具)。 */
      reqId?: string;
      /** 工具结果(tool-call-end 带来;completed 态展示)。 */
      result?: unknown;
      isError?: boolean;
      /** auto-edit 模式自动放行(折叠显「已自动放行」,与人工审批卡区分)。 */
      autoApproved?: boolean;
      /** 用户点过的决策(allow/deny)—— 卡片回显「当时点了哪个按钮」,其余淡化(对标 Happy 选中回显)。 */
      decision?: 'allow' | 'deny';
      /** AskUserQuestion 的答案(键=问题原文,值=选中项逗号连接)—— 已答回显用(2026-10-01)。 */
      answers?: Record<string, string>;
      /** 子代理(Task/Agent)的内部消息(带 parentCallId 的事件归到这里,递归)。 */
      children?: ConvMessage[];
      ts: number;
    }
  | {
      id: string;
      role: 'system';
      text: string;
      ts: number;
      /** 一轮耗时(turn-end.durationMs;work group 折叠头「这轮干了 N 秒」用)。 */
      durationMs?: number;
      /** 本轮用量(B 层 ce 带来;completed 态系统条/historia 折叠头展示)。 */
      usage?: TurnUsage;
    };

/** 一轮的 token 用量 / 成本(B 层 ce 端从 SDK result 消息带出;老 ce 不带 → 字段缺省,UI 不显)。 */
export interface TurnUsage {
  inputTokens?: number;
  outputTokens?: number;
  costUsd?: number;
  numTurns?: number;
}

/** 工具调用消息(视图层 views/ 用)。 */
export type ToolCallMsg = Extract<ConvMessage, { role: 'tool-call' }>;

let _seq = 0;
function genId(prefix: string): string {
  return `${prefix}_${Date.now().toString(36)}_${(_seq++).toString(36)}`;
}

/** 添加用户消息。用户提交自然分隔回合:下一条 assistant 文本/thinking 开新气泡(不并入上一回合)。
 *  queued:CC 还在跑上一轮时发出(排队),UI 半透明标注「本轮结束后发送」。 */
export function appendUserMessage(state: ConvMessage[], text: string, queued = false): ConvMessage[] {
  return [...state, { id: genId('u'), role: 'user', text, ts: Date.now(), ...(queued ? { queued: true } : {}) }];
}

/** 把一段 text 事件累积到最后一条**非 thinking** assistant 气泡;否则新建。
 *  空字符串透传(no-op)。同回合多条 text 事件(少见)并入同一气泡。 */
export function appendAssistantText(state: ConvMessage[], text: string): ConvMessage[] {
  if (!text) return state;
  const last = state[state.length - 1];
  if (last && last.role === 'assistant' && !last.isThinking) {
    return [...state.slice(0, -1), { ...last, text: last.text + text }];
  }
  return [...state, { id: genId('a'), role: 'assistant', text, ts: Date.now() }];
}

/** 把一段 thinking 事件累积到最后一条 thinking 气泡;否则新建(独立于 text,折叠显示)。 */
export function appendThinking(state: ConvMessage[], text: string): ConvMessage[] {
  if (!text) return state;
  const last = state[state.length - 1];
  if (last && last.role === 'assistant' && last.isThinking) {
    return [...state.slice(0, -1), { ...last, text: last.text + text }];
  }
  return [...state, { id: genId('t'), role: 'assistant', text, ts: Date.now(), isThinking: true }];
}

/** 从事件去掉 parentCallId(并入父卡 children 时消费掉这层路由,以顶层事件方式归约)。 */
function stripParentCallId(ev: AgentEvent): AgentEvent {
  if (!('parentCallId' in ev)) return ev;
  const copy: Record<string, unknown> = { ...(ev as Record<string, unknown>) };
  delete copy.parentCallId;
  return copy as AgentEvent;
}

/** 把子代理事件并入 callId===parentCallId 的工具卡 children(树内递归搜索,支持多层嵌套)。
 *  找到父卡 → 以顶层事件方式(stripParentCallId)归约进它的 children;找不到 → 返原 list。 */
function appendChildToTree(messages: ConvMessage[], parentCallId: string, ev: AgentEvent): ConvMessage[] {
  let found = false;
  const next = messages.map((m) => {
    if (m.role !== 'tool-call') return m;
    if (m.callId === parentCallId) {
      found = true;
      return { ...m, children: reduceAgentEvent(m.children ?? [], stripParentCallId(ev)) };
    }
    if (m.children && m.children.length > 0) {
      const updated = appendChildToTree(m.children, parentCallId, ev);
      if (updated !== m.children) {
        found = true;
        return { ...m, children: updated };
      }
    }
    return m;
  });
  return found ? next : messages;
}

/** agent 事件 → 消息(reducer)。未知 kind 忽略(向前兼容:ce 加新事件不破插件)。 */
export function reduceAgentEvent(state: ConvMessage[], ev: AgentEvent): ConvMessage[] {
  // 子代理(Task/Agent)内部事件带 parentCallId → 归到父工具卡的 children(树内递归搜索)。
  // 顶层事件(无 parentCallId)走下面 switch 正常归约。
  const parent = eventParentCallId(ev);
  if (parent) return appendChildToTree(state, parent, ev);
  switch (ev.kind) {
    case 'text':
      return appendAssistantText(state, typeof ev.text === 'string' ? ev.text : '');
    case 'thinking':
      return appendThinking(state, typeof ev.text === 'string' ? ev.text : '');
    // 流式增量(B 层 ce 开 includePartialMessages 后推;老 ce 不发这俩 kind,零影响)。
    // 与整块 text/thinking 同一归约:累积进当前气泡(打字机效果 = 增量粒度更细而已)。
    case 'text-delta':
      return appendAssistantText(state, typeof ev.text === 'string' ? ev.text : '');
    case 'thinking-delta':
      return appendThinking(state, typeof ev.text === 'string' ? ev.text : '');
    case 'tool-call-start': {
      const callId = typeof ev.callId === 'string' ? ev.callId : '';
      if (!callId || state.some((m) => m.role === 'tool-call' && m.callId === callId)) return state;
      return [
        ...state,
        {
          id: genId('tc'),
          role: 'tool-call',
          callId,
          tool: typeof ev.tool === 'string' ? ev.tool : 'unknown',
          input: (ev.input && typeof ev.input === 'object' ? ev.input : {}) as Record<string, unknown>,
          state: 'running',
          ts: Date.now(),
        },
      ];
    }
    case 'tool-call-end': {
      const callId = typeof ev.callId === 'string' ? ev.callId : '';
      const isError = ev.isError === true;
      const result = 'result' in ev ? (ev as { result?: unknown }).result : undefined;
      // 找对应工具卡 → 置 completed + 结果;找不到(理论不会,防御)→ 补一张已完成卡
      let found = false;
      const next = state.map((m) => {
        if (m.role === 'tool-call' && m.callId === callId && m.state !== 'denied') {
          found = true;
          return { ...m, state: 'completed' as ToolState, result, isError };
        }
        return m;
      });
      if (found) return next;
      return [
        ...state,
        {
          id: genId('tc'),
          role: 'tool-call',
          callId,
          tool: '',
          input: {},
          state: 'completed',
          result,
          isError,
          ts: Date.now(),
        },
      ];
    }
    case 'approval-request': {
      const reqId = typeof ev.reqId === 'string' ? ev.reqId : '';
      const callId = typeof ev.callId === 'string' ? ev.callId : '';
      if (!reqId) return state;
      // 挂到同 callId 的工具卡 → pending + reqId;找不到 → 补一张 pending 卡(canUseTool 理论在
      //   tool-call-start 之后,但 ce 顺序不保证时防御)。
      // 审批卡断线加固(方案B):ce 重连后重发 approval-request 不得打回用户已决策的卡 ——
      //   denied(用户拒过)/ 已挂同 reqId(此 approval 来过,用户可能已 allow→running)保持原状。
      let found = false;
      const next = state.map((m) => {
        if (m.role === 'tool-call' && m.callId === callId) {
          found = true;
          if (m.state === 'denied' || m.reqId === reqId) return m; // 重发幂等:不打回已决策卡
          return { ...m, state: 'pending' as ToolState, reqId };
        }
        return m;
      });
      if (found) return next;
      // fallback 补卡前再查同 reqId(重复 approval-request 不补第二张)。
      if (state.some((m) => m.role === 'tool-call' && m.reqId === reqId)) return state;
      return [
        ...state,
        {
          id: genId('tc'),
          role: 'tool-call',
          callId,
          tool: typeof ev.tool === 'string' ? ev.tool : 'unknown',
          input: (ev.input && typeof ev.input === 'object' ? ev.input : {}) as Record<string, unknown>,
          state: 'pending',
          reqId,
          ts: Date.now(),
        },
      ];
    }
    case 'approval-resolved': {
      const reqId = typeof ev.reqId === 'string' ? ev.reqId : '';
      const denied = ev.resolved !== 'approved';
      if (!reqId) return state;
      // approved → 工具继续跑(running,等 tool-call-end);denied → denied。
      return state.map((m) =>
        m.role === 'tool-call' && m.reqId === reqId
          ? { ...m, state: (denied ? 'denied' : 'running') as ToolState }
          : m,
      );
    }
    case 'turn-end': {
      const failed = ev.status !== 'completed';
      // B 层 ce 从 SDK result 带出耗时/用量;老 ce 只有 status → 字段缺省,UI 按「无」渲染。
      const durationMs = typeof ev.durationMs === 'number' ? ev.durationMs : undefined;
      const rawUsage = (ev as { usage?: unknown }).usage;
      const usage = turnUsageOf(rawUsage);
      const usageFields = {
        ...(durationMs !== undefined ? { durationMs } : {}),
        ...(usage ? { usage } : {}),
      };
      return [
        ...state,
        {
          id: genId('s'),
          role: 'system',
          text: failed ? 'CC 出错' : 'CC 已完成',
          ts: Date.now(),
          ...usageFields,
        },
      ];
    }
    case 'turn-start':
    case 'session-init':
    default:
      // turn-start / session-init(模型名/会话 id,B 层)/ 未知 → 不产消息(向前兼容)。
      return state;
  }
}

/** 从 turn-end 的 usage 字段(形状随 ce 版本浮动)收紧成 TurnUsage;一个数都没有 → undefined。 */
function turnUsageOf(raw: unknown): TurnUsage | undefined {
  if (!raw || typeof raw !== 'object') return undefined;
  const o = raw as Record<string, unknown>;
  const num = (v: unknown): number | undefined => (typeof v === 'number' && Number.isFinite(v) ? v : undefined);
  const usage: TurnUsage = {
    inputTokens: num(o.inputTokens),
    outputTokens: num(o.outputTokens),
    costUsd: num(o.costUsd),
    numTurns: num(o.numTurns),
  };
  return usage.inputTokens !== undefined || usage.outputTokens !== undefined || usage.costUsd !== undefined
    ? usage
    : undefined;
}

/** 一轮结束:所有排队中的用户消息已被 CC 消费(排队气泡归位,不再半透明)。 */
export function settleQueuedUserMessages(state: ConvMessage[]): ConvMessage[] {
  if (!state.some((m) => m.role === 'user' && m.queued)) return state;
  return state.map((m) => (m.role === 'user' && m.queued ? { ...m, queued: false } : m));
}

/** 用户点 tool-call 卡「允许/拒绝」→ 乐观标 state(不等 approval-resolved 回程)。
 *  allow → running(按钮隐、等 tool-call-end);deny → denied。
 *  不存在的 callId → 返原 state(同引用,reducer 稳定性)。 */
export function markToolCallDecision(
  state: ConvMessage[],
  callId: string,
  decision: 'allow' | 'deny',
  answers?: Record<string, string>,
): ConvMessage[] {
  let changed = false;
  const next = state.map((m) => {
    if (m.role === 'tool-call' && m.callId === callId && m.state === 'pending') {
      changed = true;
      return {
        ...m,
        state: (decision === 'allow' ? 'running' : 'denied') as ToolState,
        decision,
        ...(answers ? { answers } : {}),
      };
    }
    return m;
  });
  return changed ? next : state;
}

/** auto-edit 模式:收到改文件工具的 approval-request → 直接标 running + autoApproved(跳过 pending,
 *  不显审批按钮)。已有同 callId 卡(由 tool-call-start 先建)→ 更新标志;无 → 补一张(防御)。
 *  denied 卡不动(用户已拒,不打回)。 */
export function markAutoApproved(
  state: ConvMessage[],
  info: { reqId: string; callId: string; tool: string; input: Record<string, unknown> },
): ConvMessage[] {
  let found = false;
  const next = state.map((m) => {
    if (m.role === 'tool-call' && m.callId === info.callId && m.state !== 'denied') {
      found = true;
      return { ...m, state: 'running' as ToolState, autoApproved: true, reqId: info.reqId };
    }
    return m;
  });
  if (found) return next;
  return [
    ...state,
    {
      id: genId('tc'),
      role: 'tool-call',
      callId: info.callId,
      tool: info.tool,
      input: info.input,
      state: 'running',
      autoApproved: true,
      reqId: info.reqId,
      ts: Date.now(),
    },
  ];
}
