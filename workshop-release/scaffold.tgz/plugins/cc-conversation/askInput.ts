/**
 * AskUserQuestion 入参解析(2026-10-01 修「选项渲染不出来」)。
 *
 * 根因:CC 真实工具 schema 是嵌套形状
 *   { questions: [{ question, header, options: [{ label, description }], multiSelect }] }
 * 而旧视图按扁平 { question, options:[{header|label}] } 读 → 字段对不上,正文/选项全空。
 * 这里做单一归一化:新旧两形状 → AskQuestion[],渲染层只吃归一化结果。
 */

export interface AskOption {
  label: string;
  description: string;
}

export interface AskQuestion {
  question: string;
  header: string;
  options: AskOption[];
  multiSelect: boolean;
}

const str = (v: unknown): string => (typeof v === 'string' ? v : '');

/** 归一化一个选项:真实形状 label 必填;旧扁平形状 header/label 混用,description 兜底。 */
function normOption(o: unknown): AskOption | null {
  if (!o || typeof o !== 'object') return null;
  const r = o as Record<string, unknown>;
  const label = str(r.label) || str(r.header);
  const description = str(r.description);
  if (!label && !description) return null;
  return { label: label || description, description };
}

/** 解析 AskUserQuestion 的 input → 问题列表;什么都解析不出 → [](渲染层降级为普通审批卡)。 */
export function parseAskInput(input: Record<string, unknown> | undefined): AskQuestion[] {
  if (!input || typeof input !== 'object') return [];
  // 真实形状:{ questions: [...] }
  const rawQuestions = (input as { questions?: unknown }).questions;
  if (Array.isArray(rawQuestions)) {
    const out: AskQuestion[] = [];
    for (const q of rawQuestions) {
      if (!q || typeof q !== 'object') continue;
      const r = q as Record<string, unknown>;
      const options = Array.isArray(r.options)
        ? r.options.map(normOption).filter((o): o is AskOption => o !== null)
        : [];
      const question = str(r.question);
      if (!question && options.length === 0) continue;
      out.push({
        question,
        header: str(r.header),
        options,
        multiSelect: r.multiSelect === true,
      });
    }
    return out;
  }
  // 旧扁平形状(我们自己的测试夹具/历史持久化):{ question, options:[...] }
  const question = str((input as { question?: unknown }).question);
  const rawOptions = (input as { options?: unknown }).options;
  const options = Array.isArray(rawOptions)
    ? rawOptions.map(normOption).filter((o): o is AskOption => o !== null)
    : [];
  if (!question && options.length === 0) return [];
  return [{ question, header: '', options, multiSelect: false }];
}

/** 选项提交时发给 CC 的文本:label 优先,无 label 用 description(TUI 等价:模型看 label)。 */
export function answerTextOf(o: AskOption): string {
  return o.label || o.description;
}
