/**
 * CC 对话插件 —— 事件层(ce 侧 Agent SDK runner 推来的结构化事件)。
 *
 * 数据流(happy-coder-analysis.md / plugin-architecture.md §3.2):
 *   ce 端 agent-runner 用 @anthropic-ai/claude-agent-sdk 的 query() 跑 claude(不开终端、不 parse TUI),
 *   把 SDKMessage(assistant text/thinking/tool_use · user tool_result · system.init · result)
 *   映射成本文件的 AgentEvent 结构化事件 → AgentEvent 帧(type 7)加密推手机。
 *   手机 CC 对话窗口订阅 agentEvents 能力 → reduceAgentEvent 归约成消息列表渲染。
 *
 * 这是 ce 与手机的**共享契约**(ce 侧 agent-runner 产、手机侧消费)。CC 专属知识(事件→消息归约、
 * 工具入参渲染)住本文件 + conversation.ts = 插件里(ce 是哑管道,平台不知 CC 是何物)。
 *
 * 设计参考 Happy Coder 的 session-protocol 事件集(turn-start/text{+thinking}/tool-call-start/
 * tool-call-end/turn-end),经审视取其最小完备子集 + 审批(approval-request/resolved)。
 */

/**
 * ce → 手机 的 agent 事件(AgentEvent 帧载荷)。
 *
 * 工具调用生命周期:start(assistant tool_use)→ [approval-request(canUseTool blocking)] →
 *   end(user tool_result)。callId 贯穿三者(SDK 的 tool_use_id;canUseTool options.toolUseID 同值)。
 * 审批:reqId 是手机回传的 key(resolveApproval RPC 用);callId 把审批挂到对应工具卡。
 *
 * 末条 `{ kind: string; ... }` 兜底 = 向前兼容(ce 加新事件 kind 不破老插件,未知 kind 归约时忽略)。
 */
export type AgentEvent =
  // 一轮生命周期
  | { kind: 'turn-start' }
  | {
      kind: 'turn-end';
      status: 'completed' | 'failed';
      durationMs?: number;
      /** 本轮用量(B 层 ce 2026-10-01 带出;老 ce 缺省)。 */
      usage?: { inputTokens?: number; outputTokens?: number; costUsd?: number; numTurns?: number };
    }
  // 模型输出(完整块)
  | { kind: 'text'; text: string; parentCallId?: string }
  | { kind: 'thinking'; text: string; parentCallId?: string }
  // 流式增量(B 层 ce 开 includePartialMessages 后推;打字机效果。老 ce 不发,零影响)
  | { kind: 'text-delta'; text: string; parentCallId?: string }
  | { kind: 'thinking-delta'; text: string; parentCallId?: string }
  // 会话元信息(system/init 提炼:模型名/会话 id;B 层)
  | { kind: 'session-init'; model: string; sessionId?: string }
  // 工具调用
  | { kind: 'tool-call-start'; callId: string; tool: string; input: Record<string, unknown>; parentCallId?: string }
  | { kind: 'tool-call-end'; callId: string; result?: unknown; isError?: boolean; parentCallId?: string }
  // 审批(canUseTool blocking;同 callId 挂到 tool-call 卡)
  | { kind: 'approval-request'; reqId: string; callId: string; tool: string; input: Record<string, unknown> }
  | { kind: 'approval-resolved'; reqId: string; resolved: 'approved' | 'denied' }
  // 向前兼容兜底
  | { kind: string; [k: string]: unknown };

/** 把任意对象窄化成 AgentEvent(防字段缺失;非对象 / 无字符串 kind → null 丢弃)。 */
export function asAgentEvent(raw: unknown): AgentEvent | null {
  if (!raw || typeof raw !== 'object') return null;
  const o = raw as { kind?: unknown };
  if (typeof o.kind !== 'string') return null;
  return raw as AgentEvent;
}

/**
 * 取事件的 parentCallId(子代理 Task/Agent 的内部事件带它,标归属父工具卡)。
 * 无 / 非字符串 → null(顶层事件)。经 fallback 兜底成员读取,不要求每个 kind 显式声明。
 */
export function eventParentCallId(ev: AgentEvent): string | null {
  const v = (ev as { parentCallId?: unknown }).parentCallId;
  return typeof v === 'string' ? v : null;
}

// ─── 工具分类(CC 专属知识:哪些工具算「改文件」「读/查噪声」)──────────────────
// 单一事实源在 ./knownTools(对标 Happy knownTools.tsx);此处仅向后兼容 re-export
// (向后兼容:events.test.ts 仍以相对路径引本文件,行为零变化)

export { isEditTool, isCollapsibleWhenDone } from './knownTools';

// ─── CC 文本里的「可选方案」提取(诉求③:选项选择不要套审批)───────────────────
// CC 常以「1. 方案A 2. 方案B … 你选哪个?」结尾让你选 —— 从文本抽成可点 chip,
// 点哪个就把选项文本作 stdin 发出(比手打快,且不弹 binary 审批框)。纯展示派生,不入消息流。

export interface ChatOption {
  /** 编号/字母前缀(如 '1' / 'A')。 */
  prefix: string;
  /** 选项正文(发送时用)。 */
  text: string;
}

/** 行首编号/字母列表项:"1." / "1、" / "1)" / "A." / "a)" + 空格 + 正文。 */
const OPTION_LINE = /^\s*(\d{1,2}|[A-Za-z])\s*[.、)]\s+(.+?)\s*$/;
/** 「在让你选」的语气线索(需命中才提取,免把普通编号步骤误当选项)。 */
const CHOICE_HINT = /哪个|选择|倾向|要不要|还是|你来定|你决定|which|choose|prefer|or\s+\w+\s*[?？]/i;

/**
 * 从 CC 文本提取可选方案。命中「选择语气」+ 2~6 条编号/字母项才返回,否则 [](保守:宁可不弹)。
 * 发送时用选项正文(LLM 理解自然语言,比裸 '1'/'2' 稳)。
 */
export function extractOptions(text: string): ChatOption[] {
  if (!text || !CHOICE_HINT.test(text)) return [];
  const items: ChatOption[] = [];
  for (const line of text.split('\n')) {
    const m = OPTION_LINE.exec(line);
    if (!m) continue;
    items.push({ prefix: m[1]!, text: m[2]! });
  }
  return items.length >= 2 && items.length <= 6 ? items : [];
}
