/**
 * CC 对话插件 main.tsx —— 按 entry 字符串 export 组件。
 *
 * entry='CcConversation' → export function CcConversation(props: SessionProps)
 * 直接渲染同目录的 CcConversation 实现（消息列表/thinking/工具卡/输入框/审批）。
 */
import type { SessionProps } from '@core/contract';
import { CcConversation as CcConversationImpl } from './CcConversation';

/**
 * CC 对话组件（entry='CcConversation'）。
 *
 * 平台按 manifest.contributes.sessions[].entry='CcConversation' 从本模块取此 export，
 * 动态挂载到会话 tab（loader.ts 唯一加载入口）。
 */
export function CcConversation(props: SessionProps): JSX.Element {
  return <CcConversationImpl {...props} />;
}
