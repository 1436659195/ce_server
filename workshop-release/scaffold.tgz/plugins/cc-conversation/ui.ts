/**
 * CC 对话 —— UI 公共件(无 React:动效样式注入 / 剪贴板 / 触感 / 格式化)。
 *
 * 动效参数全部对标 Happy(Happy-app theme.css / 各组件实测值,2026-10-01 调研):
 *  - 状态点脉冲:opacity 1↔0.3,2s 周期 ease-in-out(StatusDot)。
 *  - shimmer 扫光:110° 渐变,2350ms linear,72% 处停顿(ShimmerText.web 原样)。
 *  - 审批按钮呼吸环:2px 边框,opacity 0.18↔0.52,1.44s(PermissionActionButton)。
 *  - 发送失败抖动:3px 振幅 4 往返 300ms(Shaker)。
 * reduced-motion 用户全部关掉(尊重系统设置)。
 */

const CSS = `
@keyframes ce-cc-pulse-dot { 0%, 100% { opacity: 1; } 50% { opacity: 0.3; } }
@keyframes ce-cc-shimmer { 0% { background-position: 100% 0; } 72%, 100% { background-position: 0% 0; } }
@keyframes ce-cc-breathe { 0%, 100% { opacity: 0.18; } 50% { opacity: 0.52; } }
@keyframes ce-cc-shake { 20%, 60% { transform: translateX(3px); } 40%, 80% { transform: translateX(-3px); } }
.ce-cc-pulse-dot { animation: ce-cc-pulse-dot 2s ease-in-out infinite; }
.ce-cc-shimmer {
  background-image: linear-gradient(110deg, currentColor 35%, var(--ce-cc-shimmer-hl, rgba(255,255,255,0.85)) 50%, currentColor 65%);
  background-size: 300% 100%;
  -webkit-background-clip: text;
  background-clip: text;
  -webkit-text-fill-color: transparent;
  animation: ce-cc-shimmer 2350ms linear infinite;
}
.ce-cc-breathe { animation: ce-cc-breathe 1.44s ease-in-out infinite; }
.ce-cc-shake { animation: ce-cc-shake 0.3s ease-in-out; }
@media (prefers-reduced-motion: reduce) {
  .ce-cc-pulse-dot, .ce-cc-shimmer, .ce-cc-breathe, .ce-cc-shake { animation: none; }
}
`;

let injected = false;

/** 把本插件的 keyframes/动效类注入 <head>(幂等;多开 CC tab 只注一次)。 */
export function ensureConversationStyles(): void {
  if (injected || typeof document === 'undefined') return;
  const el = document.createElement('style');
  el.textContent = CSS;
  document.head.appendChild(el);
  injected = true;
}

/** 剪贴板:clipboard API 优先,失败退 execCommand(WebView 老内核兜底)。返回是否成功。 */
export async function copyText(text: string): Promise<boolean> {
  try {
    await navigator.clipboard.writeText(text);
    return true;
  } catch {
    try {
      const ta = document.createElement('textarea');
      ta.value = text;
      ta.style.position = 'fixed';
      ta.style.opacity = '0';
      document.body.appendChild(ta);
      ta.select();
      const ok = document.execCommand('copy');
      ta.remove();
      return ok;
    } catch {
      return false;
    }
  }
}

/** 触感(Android WebView 的 navigator.vibrate;iOS 静默降级)。pattern 见 HapticWebVibrate 映射。 */
export function haptic(pattern: number | number[]): void {
  try {
    if (typeof navigator !== 'undefined' && typeof navigator.vibrate === 'function') navigator.vibrate(pattern);
  } catch {
    /* 无振动能力 → 静默 */
  }
}

/** 轻点击类操作(发送/复制/审批点击)。 */
export function hapticLight(): void {
  haptic(10);
}
/** 错误/阻止(停止失败、发送失败)。 */
export function hapticError(): void {
  haptic([30, 60, 30]);
}

/** 耗时格式:<60s「42s」,否则「1:07」(m:ss)。 */
export function formatElapsed(ms: number): string {
  const total = Math.max(0, Math.round(ms / 1000));
  if (total < 60) return `${total}s`;
  return `${Math.floor(total / 60)}:${String(total % 60).padStart(2, '0')}`;
}

/** token 数缩写:1200 → 「1.2K」;56 → 「56」。 */
export function formatTokens(n: number): string {
  if (n >= 1000) {
    const k = n / 1000;
    return `${k >= 100 ? Math.round(k) : k.toFixed(1).replace(/\.0$/, '')}K`;
  }
  return String(n);
}
