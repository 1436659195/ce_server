/**
 * 文件域类型:Jupyter Contents API 数据模型 + 共享 shaping helper。
 * 移植自旧 src/types/terminal.ts 并审计。
 *
 * **共享 helper 的位置选择**:`mapFileRead` / `sortContentEntries` / `MAX_FILE_BYTES`
 * 同时被 **FilesStore**(UI 走,`src/core/files/files.ts`)与 **RelayProvider**(插件走契约,
 * `src/core/connection/relayProvider.ts`)消费——两边对同一 Jupyter 模型必须产出一致的
 * tooLarge / binary 判断与目录排序,靠「碰巧都记得」会漂移。本文件是 leaf 类型模块、两边
 * 都已 import 它,作为单一来源最合适;放 `src/core/files/` 会让 connection 层反向依赖 files 域。
 */

/** Jupyter Contents API:目录条目 */
export interface ContentEntry {
  name: string;
  path: string;
  type: 'directory' | 'file' | 'notebook';
  size?: number;
}

/** Jupyter Contents API:内容模型 */
export interface ContentsModel {
  name: string;
  path: string;
  type: 'directory' | 'file' | 'notebook';
  format?: 'text' | 'base64' | 'json' | null;
  mimetype?: string | null;
  size?: number;
  /** 目录:子条目数组;文件:文本/base64 字符串 */
  content: ContentEntry[] | string | null;
}

/** 文件查看结果(readFile 产出) */
export interface FileReadResult {
  text: string;
  tooLarge: boolean; // size > MAX_FILE_BYTES
  binary: boolean; // format==='base64' 或非文本 mimetype
  size: number;
}

// ─── 共享 shaping helper(FilesStore 与 RelayProvider 单一来源)──────────────────

/** 文件过大阈值(2026-09-15 用户定案 1MB→5MB):> 5MB 标 tooLarge,Viewer 不渲染;
 *  ce-server 桥 MAX_READFILE_BYTES 已同步 5MB(服务端护栏不先截,两边一致)。 */
export const MAX_FILE_BYTES = 5 * 1024 * 1024;

/**
 * mapFileRead 入参形状(结构化:只取关心的 format/mimetype/size/content)。
 * content 用 unknown —— Jupyter 目录模型(数组)与文件模型(字符串)都可能在场,
 * mapFileRead 内部用 typeof 收窄;同时让 FilesStore 的 ContentsModel 与 RelayProvider
 * 的窄类型 JupyterFile 都能直传,不要求字段完全一致。
 */
export interface FileReadInput {
  format?: string | null;
  mimetype?: string | null;
  size?: number;
  content?: unknown;
}

/** 非文本但实际是文本的 application/* mimetype（Jupyter 对 .json/.xml 等返回这些，不是 text/*）。 */
const TEXT_APPLICATION_MIMETYPES = new Set([
  'application/json',
  'application/xml',
  'application/javascript',
  'application/x-yaml',
  'application/yaml',
  'application/x-sh',
  'application/toml',
]);

/** 是否文本 mimetype（text/* 或公认的文本 application/*）。 */
function isTextMimetype(m: string | null | undefined): boolean {
  return typeof m === 'string' && (m.startsWith('text/') || TEXT_APPLICATION_MIMETYPES.has(m));
}

/**
 * Jupyter Contents file 模型 → FileReadResult。
 * - **binary 以 format 为准**（Jupyter 权威）：base64 → 二进制；text/json → 文本（不管 mimetype，
 *   因 Jupyter 对 .json 返回 mimetype=application/json，但它是文本——旧版仅看 mimetype 误判为 binary）。
 *   format 缺失才退回 mimetype 判断（text/* 或文本 application/*）。
 * - size > MAX_FILE_BYTES → tooLarge（Viewer 显警告）。
 * - size 缺失时用 content 字符串长度兜底（文本场景下近似字节数）。
 *
 * FilesStore(UI)与 RelayProvider(契约)共享此实现 —— 同一文件两边给出一致的 tooLarge/binary。
 */
export function mapFileRead(f: FileReadInput): FileReadResult {
  const size =
    typeof f.size === 'number' ? f.size : typeof f.content === 'string' ? f.content.length : 0;
  const binary =
    f.format === 'base64' ||
    (f.format !== 'text' && f.format !== 'json' && !isTextMimetype(f.mimetype));
  // format:'json' 时 Jupyter 对 .ipynb/.json 返回**解析后的对象**(不是字符串)——
  // 序列化归一成文本(2026-09-25 真机踩坑:旧实现落空串,notebook 查看器报"不是合法 JSON")。
  const text = !binary
    ? typeof f.content === 'string'
      ? f.content
      : f.format === 'json' && f.content !== null && f.content !== undefined && typeof f.content === 'object'
        ? JSON.stringify(f.content)
        : ''
    : '';
  return { text, tooLarge: size > MAX_FILE_BYTES, binary, size };
}

/**
 * 目录条目排序:directory 在前、组内按 name 字母序(localeCompare)。
 * spread 后 sort(不改原数组,返回新数组);泛型保留调用方条目类型。
 *
 * FilesStore.listDir 与 RelayProvider listDir 共享此实现 —— 同一目录两边给出一致顺序。
 */
export function sortContentEntries<T extends ContentEntry>(list: T[]): T[] {
  return [...list].sort((a, b) => {
    if (a.type === 'directory' && b.type !== 'directory') return -1;
    if (a.type !== 'directory' && b.type === 'directory') return 1;
    return a.name.localeCompare(b.name);
  });
}
