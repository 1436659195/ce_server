/**
 * 字节 → 人类可读(B / KB / MB)。文件 size 显示用;目录无 size 不调。
 *
 * 从 FileExplorer 抽出(text-view 插件经 @core/shared 也要用)—— 单一来源,避免两份副本漂移。
 * 借鉴旧 useFiles 的 formatSize,逐行审计;纯格式化、无副作用。
 */
export function formatSize(bytes: number): string {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
}
