import { Component, type ReactNode } from 'react';

/**
 * 通用 ErrorBoundary —— 把渲染/副作用崩溃从「白屏」变成「可见错误卡 + 重试」。
 *
 * 用途:① 顶层包 App(任何渲染崩 → 显错误 + 重新加载,不再白屏到没法诊断);
 *      ② per-session 包(单个终端/cc 会话崩 → 局部错误卡 + 重试该 session,不连累其他)。
 *
 * 这是「取证 instrumentation」:catch 时 console.error 全量(给 logcat / 远程 inspect),
 * 屏幕显 message + stack 头几行(用户能直接念给我 / 截图)。治「白屏 + 重启点不进去」类盲排。
 *
 * 与 PluginErrorBoundary 的区别:那个绑插件运行时(熔断计数);本组件通用、无运行时耦合,
 * session 组件(CcConversation 等,在 App.tsx 直接渲染、原本无边界)用它兜。
 */
interface Props {
  /** 区分名(出错时显示是哪块,便于定位)。 */
  name?: string;
  /** 自定义 fallback;缺省显错误卡 + 重试/重加载。 */
  fallback?: (error: Error, retry: () => void) => ReactNode;
  children: ReactNode;
}
interface State {
  error: Error | null;
}

export class AppErrorBoundary extends Component<Props, State> {
  override state: State = { error: null };

  static getDerivedStateFromError(error: Error): Pick<State, 'error'> {
    return { error };
  }

  override componentDidCatch(error: Error, info: { componentStack?: string }): void {
    // 全量打到 console(logcat / Chrome remote inspect 能看到完整 stack)。
    console.error('[AppErrorBoundary]', this.props.name ?? '(unnamed)', error, info.componentStack ?? '');
  }

  retry = (): void => {
    this.setState({ error: null });
  };

  override render(): ReactNode {
    if (this.state.error) {
      if (this.props.fallback) return this.props.fallback(this.state.error, this.retry);
      return <ErrorCard error={this.state.error} name={this.props.name} onRetry={this.retry} />;
    }
    return this.props.children;
  }
}

/** 默认错误卡:红底,显 name + message + stack 头部,重试(重挂子树)+ 重新加载 + 清会话状态兜底。 */
function ErrorCard({ error, name, onRetry }: { error: Error; name?: string; onRetry: () => void }): ReactNode {
  const stack = (error.stack ?? '').split('\n').slice(0, 12).join('\n');
  /** 兜底逃生:若是「重启即崩」的死循环(疑似持久化的会话状态坏了),清掉终端会话/类型持久
   *  (保留配对档案 / 插件 / 主题)再重载,让用户先脱困。最后手段,不清配对所以仍能重连。 */
  const clearSessionsAndReload = (): void => {
    try {
      const keep = (k: string) =>
        k.startsWith('jupyter_terminal_sessions') || k.startsWith('ce_terminal_types');
      for (const k of Object.keys(localStorage)) if (keep(k)) localStorage.removeItem(k);
    } catch {
      /* localStorage 不可用 */
    }
    window.location.reload();
  };
  return (
    <div
      className="flex h-full w-full flex-col gap-2 overflow-auto bg-base p-4 text-fg"
      role="alert"
      style={{ background: '#2a1414', color: '#ffb4b4' }}
    >
      <div className="text-[length:var(--fs-base)] font-semibold">
        渲染崩溃{name ? ` · ${name}` : ''}
      </div>
      <div className="text-[length:var(--fs-sm)]" style={{ color: '#ff8080' }}>
        {error.message || '(无 message)'}
      </div>
      {stack && (
        <pre className="whitespace-pre-wrap break-all rounded bg-black/40 p-2 text-[length:var(--fs-xs)]" style={{ color: '#e0a0a0' }}>
          {stack}
        </pre>
      )}
      <div className="flex flex-wrap gap-2">
        <button
          type="button"
          onClick={onRetry}
          className="rounded px-3 py-1.5 text-[length:var(--fs-sm)]"
          style={{ background: '#5a2a2a', color: '#ffe0e0' }}
        >
          重试
        </button>
        <button
          type="button"
          onClick={() => window.location.reload()}
          className="rounded px-3 py-1.5 text-[length:var(--fs-sm)]"
          style={{ background: '#3a3a3a', color: '#fff' }}
        >
          重新加载 app
        </button>
        <button
          type="button"
          onClick={clearSessionsAndReload}
          className="rounded px-3 py-1.5 text-[length:var(--fs-sm)]"
          style={{ background: '#5a4a1a', color: '#ffe9c0' }}
        >
          清会话状态再重载(兜底)
        </button>
      </div>
      <div className="mt-1 text-[length:var(--fs-xs)]" style={{ color: '#c0a0a0' }}>
        把上面的 message + stack 截图发我,我定位根因。卡在重启死循环就点「清会话状态」(保留配对,只清终端会话)。
      </div>
    </div>
  );
}
