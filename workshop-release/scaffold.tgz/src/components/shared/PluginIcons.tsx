/**
 * 插件图标库 —— 内置 SVG 图标 + registry + PluginIcon 渲染器 + 字母头像兜底。
 *
 * - PuzzleIcon：拼图，fill=currentColor（**随主题**，用于 ActivityBar「插件」入口）。
 * - ClaudeIcon / MdIcon / JsonIcon / ApkIcon：**固定彩色**（不随主题，用于插件列表卡片）。
 * - 通用图标（A2，2026-08-27 用户反馈「插件必须有图标」）：22 个 stroke 风格
 *   currentColor 图标，覆盖工坊生成件的常见原型（提醒/监控/日历/终端/数据库…）。
 *   生成侧（SKILL）从名字清单里挑，不再联网搜 SVG（版权/断网/夹带脚本三个硬伤）。
 *
 * 插件 manifest 的 icon 字段填 registry 名（如 'bell'/'gauge'），PluginIcon({ name })
 * 按 name 渲染；**未知名且有 fallback → 字母头像**（插件名首字 + 按名固定的底色，
 * 通讯录式），任何来源的插件都不会再出现空白图标；两者皆无 → null（不显）。
 *
 * 所有图标 viewBox=0 0 1024 1024，size 控制宽高（默认 18）。
 */
import type { ComponentType, ReactElement, ReactNode } from 'react';
import { PLUGIN_ICON_NAMES, type PluginIconName } from '@/core/plugin/iconNames';

// 图标名真源在 core/plugin/iconNames.ts(零依赖,manifest 类型同源);这里 re-export
// 保持旧 import 路径可用。REGISTRY 按联合收型:缺一个图标 / 多一个名字都编译红。
export { PLUGIN_ICON_NAMES };
export type { PluginIconName };

export interface IconProps {
  size?: number;
  className?: string;
}

/** 拼图（插件入口；currentColor 随主题）。 */
export function PuzzleIcon({ size = 18, className }: IconProps) {
  return (
    <svg viewBox="0 0 1024 1024" width={size} height={size} className={className} fill="currentColor" aria-hidden>
      <path d="M405.333333 480H192A74.666667 74.666667 0 0 1 117.333333 405.333333V192A74.666667 74.666667 0 0 1 192 117.333333h213.333333A74.666667 74.666667 0 0 1 480 192v213.333333a74.666667 74.666667 0 0 1-74.666667 74.666667zM192 181.333333a10.666667 10.666667 0 0 0-10.666667 10.666667v213.333333a10.666667 10.666667 0 0 0 10.666667 10.666667h213.333333a10.666667 10.666667 0 0 0 10.666667-10.666667V192a10.666667 10.666667 0 0 0-10.666667-10.666667zM405.333333 906.666667H192A74.666667 74.666667 0 0 1 117.333333 832V618.666667A74.666667 74.666667 0 0 1 192 544h213.333333a74.666667 74.666667 0 0 1 74.666667 74.666667v213.333333a74.666667 74.666667 0 0 1-74.666667 74.666667z m-213.333333-298.666667a10.666667 10.666667 0 0 0-10.666667 10.666667v213.333333a10.666667 10.666667 0 0 0 10.666667 10.666667h213.333333a10.666667 10.666667 0 0 0 10.666667-10.666667V618.666667a10.666667 10.666667 0 0 0-10.666667-10.666667zM842.666667 906.666667h-213.333334A74.666667 74.666667 0 0 1 554.666667 832V618.666667a74.666667 74.666667 0 0 1 74.666666-74.666667h213.333334A74.666667 74.666667 0 0 1 917.333333 618.666667v213.333333a74.666667 74.666667 0 0 1-74.666666 74.666667z m-213.333334-298.666667a10.666667 10.666667 0 0 0-10.666666 10.666667v213.333333a10.666667 10.666667 0 0 0 10.666666 10.666667h213.333334a10.666667 10.666667 0 0 0 10.666666-10.666667V618.666667a10.666667 10.666667 0 0 0-10.666666-10.666667zM736 480A181.333333 181.333333 0 1 1 917.333333 298.666667a181.546667 181.546667 0 0 1-181.333333 181.333333z m0-298.666667A117.333333 117.333333 0 1 0 853.333333 298.666667a117.546667 117.546667 0 0 0-117.333333-117.333334z" />
    </svg>
  );
}

/** Claude（claude 橙 #D97757，固定彩色）。 */
export function ClaudeIcon({ size = 18, className }: IconProps) {
  return (
    <svg viewBox="0 0 1024 1024" width={size} height={size} className={className} aria-hidden>
      <path
        fill="#D97757"
        d="M252.8 652.8l167.89504-94.29504 2.76992-8.10496-2.76992-4.48h-8.11008l-28.16-1.70496-96-2.56-83.2-3.41504-80.64-4.26496-20.26496-4.27008-18.98496-24.96 1.92-12.58496 17.06496-11.52 24.32 2.13504L182.61504 486.4 263.68 491.94496l58.66496 3.41504 87.04 9.17504h13.87008l1.92-5.55008-4.69504-3.40992-3.62496-3.41504-83.84-56.74496-90.67008-60.16-47.56992-34.56L168.96 323.2l-13.01504-16.42496-5.54496-35.84 23.25504-25.81504 31.36 2.13504 7.88992 2.12992 31.79008 24.32 67.84 52.48 88.52992 65.28 13.01504 10.88 5.12-3.62496 0.64-2.56-5.76-9.81504-48.21504-87.04-51.40992-88.52992L291.62496 174.08l-5.96992-21.97504a107.85792 107.85792 0 0 1-3.63008-26.02496l26.67008-36.05504 14.72-4.68992 35.40992 4.68992L373.76 103.04l21.97504 50.34496 35.62496 79.36L486.61504 340.48l16.20992 32 8.75008 29.65504 3.2 9.16992h5.54496v-5.12l4.48-60.8 8.32-74.44992 8.10496-96 2.77504-27.09504 13.44-32.42496 26.66496-17.49504 20.69504 10.02496 17.06496 24.32-2.34496 15.79008-10.24 65.92-19.84 103.24992-13.01504 69.12h7.47008l8.74496-8.74496 34.98496-46.50496 58.67008-73.39008 26.02496-29.22496 30.29504-32.21504 19.40992-15.36H798.72l27.09504 40.11008-12.16 41.38496-37.76 48-31.36 40.53504-45.01504 60.58496-28.16 48.42496 2.56 3.84 6.61504-0.64 101.54496-21.54496 54.82496-10.02496 65.49504-11.31008 29.65504 13.87008 3.2 14.08-11.73504 28.8-69.97504 17.28-82.12992 16.42496-122.24 29.01504-1.49504 1.06496 1.70496 2.13504 55.04 5.12 23.47008 1.28h57.6l107.30496 7.88992 28.16 18.56 16.85504 22.61504-2.77504 17.28-43.30496 21.97504-58.24-13.87008-136.11008-32.42496-46.72-11.73504h-6.4v3.84l38.83008 37.97504 71.24992 64.42496 89.17504 82.99008 4.48 20.48-11.52 16.20992L824.32 803.84l-78.50496-58.88-30.29504-26.66496-68.48-57.6h-4.48v5.96992l15.78496 23.04 83.41504 125.23008 4.26496 38.4-5.96992 12.58496-21.55008 7.46496-23.68-4.26496-48.84992-68.48-50.35008-77.22496-40.52992-69.12-4.91008 2.76992-23.88992 258.13504-11.31008 13.22496-26.02496 10.03008-21.54496-16.43008-11.52-26.66496 11.52-52.48L481.28 774.4l11.30496-54.4 10.24-67.62496 5.97504-22.4-0.42496-1.49504-4.91008 0.64-50.98496 69.97504L374.82496 803.84l-61.44 65.70496-14.72 5.76-25.38496-13.22496 2.34496-23.46496 14.29504-20.91008 84.90496-107.94496 51.2-66.98496L459.09504 604.16v-5.54496h-2.13504l-225.49504 146.56-40.10496 5.12L174.08 734.08l2.13504-26.66496L184.32 698.66496l67.84-46.72h-0.21504l0.85504 0.85504z"
      />
    </svg>
  );
}

/** Markdown（灰 #BFBFBF，固定彩色）。 */
export function MdIcon({ size = 18, className }: IconProps) {
  return (
    <svg viewBox="0 0 1024 1024" width={size} height={size} className={className} aria-hidden>
      <path
        fill="#BFBFBF"
        d="M895.318 192H128.682C93.008 192 64 220.968 64 256.616v510.698C64 802.986 93.008 832 128.682 832h766.636C930.992 832 960 802.986 960 767.312V256.616C960 220.968 930.992 192 895.318 192zM568.046 704H455.95V512l-84.08 107.756L287.826 512v192H175.738V320h112.088l84.044 135.96L455.95 320h112.096v384z m167.314 0L596.09 512h84V320h112.086v192h84.054L735.324 704h0.036z"
      />
    </svg>
  );
}

/** JSON（蓝 #5B8DEF，固定彩色；原 SVG fill 为空，补品牌蓝）。 */
export function JsonIcon({ size = 18, className }: IconProps) {
  return (
    <svg viewBox="0 0 1024 1024" width={size} height={size} className={className} aria-hidden>
      <path
        fill="#5B8DEF"
        d="M213.333333 128h85.333334v85.333333H213.333333v213.333334a85.333333 85.333333 0 0 1-85.333333 85.333333 85.333333 85.333333 0 0 1 85.333333 85.333333v213.333334h85.333334v85.333333H213.333333c-45.653333-11.52-85.333333-38.4-85.333333-85.333333v-170.666667a85.333333 85.333333 0 0 0-85.333333-85.333333H0v-85.333334h42.666667a85.333333 85.333333 0 0 0 85.333333-85.333333V213.333333a85.333333 85.333333 0 0 1 85.333333-85.333333m597.333334 0a85.333333 85.333333 0 0 1 85.333333 85.333333v170.666667a85.333333 85.333333 0 0 0 85.333333 85.333333h42.666667v85.333334h-42.666667a85.333333 85.333333 0 0 0-85.333333 85.333333v170.666667a85.333333 85.333333 0 0 1-85.333333 85.333333h-85.333334v-85.333333h85.333334v-213.333334a85.333333 85.333333 0 0 1 85.333333-85.333333 85.333333 85.333333 0 0 1-85.333333-85.333333V213.333333h-85.333334V128h85.333334m-298.666667 512a42.666667 42.666667 0 0 1 42.666667 42.666667 42.666667 42.666667 0 0 1-42.666667 42.666666 42.666667 42.666667 0 0 1-42.666667-42.666666 42.666667 42.666667 0 0 1 42.666667-42.666667m-170.666667 0a42.666667 42.666667 0 0 1 42.666667 42.666667 42.666667 42.666667 0 0 1-42.666667 42.666666 42.666667 42.666667 0 0 1-42.666666-42.666666 42.666667 42.666667 0 0 1 42.666666-42.666667m341.333334 0a42.666667 42.666667 0 0 1 42.666666 42.666667 42.666667 42.666667 0 0 1-42.666666 42.666666 42.666667 42.666667 0 0 1-42.666667-42.666666 42.666667 42.666667 0 0 1 42.666667-42.666667z"
      />
    </svg>
  );
}

/** APK 安装（Android 绿 #3DDC84，固定彩色；下载箭头 + 承接托盘，表「拉起安装」）。 */
export function ApkIcon({ size = 18, className }: IconProps) {
  return (
    <svg viewBox="0 0 1024 1024" width={size} height={size} className={className} aria-hidden>
      <path
        fill="#3DDC84"
        d="M440 180 h144 v320 h-144 z M336 472 L688 472 L512 692 z M272 704 h480 a40 40 0 0 1 40 40 v64 a40 40 0 0 1 -40 40 h-480 a40 40 0 0 1 -40 -40 v-64 a40 40 0 0 1 40 -40 z"
      />
    </svg>
  );
}

/** 扫传(四角取景框 + 扫描线;currentColor 随主题)。 */
export function ScanIcon({ size = 18, className }: IconProps) {
  return (
    <svg viewBox="0 0 1024 1024" width={size} height={size} className={className} fill="currentColor" aria-hidden>
      <path d="M128 128h256v72H200v184h-72V128zM896 128H640v72h184v184h72V128zM128 896h256v-72H200V640h-72v256zM896 896H640v-72h184V640h72v256zM288 476h448v72H288z" />
    </svg>
  );
}

// ─── A2 通用图标(2026-08-27):stroke 风格、currentColor 随主题 ────────────────
// 统一 strokeWidth=72 / 圆角线帽;工坊生成件按 SKILL 清单挑名。

/** 通用 stroke 图标的公共 svg 壳。 */
function StrokeIcon({ size = 18, className, children }: IconProps & { children: ReactNode }) {
  return (
    <svg
      viewBox="0 0 1024 1024"
      width={size}
      height={size}
      className={className}
      fill="none"
      stroke="currentColor"
      strokeWidth={72}
      strokeLinecap="round"
      strokeLinejoin="round"
      aria-hidden
    >
      {children}
    </svg>
  );
}

/** 铃铛(提醒/通知类)。 */
export function BellIcon(p: IconProps) {
  return (
    <StrokeIcon {...p}>
      <path d="M512 192c-176 0-288 112-288 288v160l-64 96h704l-64-96V480c0-176-112-288-288-288z" />
      <path d="M448 832a64 64 0 0 0 128 0" />
    </StrokeIcon>
  );
}

/** 仪表盘(监控面板)。 */
export function GaugeIcon(p: IconProps) {
  return (
    <StrokeIcon {...p}>
      <path d="M192 640a320 320 0 0 1 640 0" />
      <path d="M512 640 688 448" />
      <circle cx="512" cy="640" r="32" fill="currentColor" stroke="none" />
    </StrokeIcon>
  );
}

/** 脉搏波形(系统/资源监控;sys-monitor 在用)。 */
export function ActivityIcon(p: IconProps) {
  return (
    <StrokeIcon {...p}>
      <polyline points="128,608 320,608 416,352 608,736 704,544 896,544" />
    </StrokeIcon>
  );
}

/** 芯片(CPU/硬件)。 */
export function CpuIcon(p: IconProps) {
  return (
    <StrokeIcon {...p}>
      <rect x="288" y="288" width="448" height="448" rx="48" />
      <rect x="432" y="432" width="160" height="160" rx="24" />
      <path d="M384 288V192M512 288V192M640 288V192M384 832v-96M512 832v-96M640 832v-96M288 384h-96M288 512h-96M288 640h-96M832 384h-96M832 512h-96M832 640h-96" />
    </StrokeIcon>
  );
}

/** 日历(定时/日程)。 */
export function CalendarIcon(p: IconProps) {
  return (
    <StrokeIcon {...p}>
      <rect x="192" y="256" width="640" height="576" rx="48" />
      <path d="M192 448h640M352 160v160M672 160v160" />
    </StrokeIcon>
  );
}

/** 时钟(时间类)。 */
export function ClockIcon(p: IconProps) {
  return (
    <StrokeIcon {...p}>
      <circle cx="512" cy="512" r="320" />
      <path d="M512 320v192l160 96" />
    </StrokeIcon>
  );
}

/** 终端(>_)。 */
export function TerminalIcon(p: IconProps) {
  return (
    <StrokeIcon {...p}>
      <rect x="128" y="192" width="768" height="640" rx="64" />
      <polyline points="288,480 400,592 288,704" />
      <path d="M480 704h224" />
    </StrokeIcon>
  );
}

/** 文件(折角页)。 */
export function FileIcon(p: IconProps) {
  return (
    <StrokeIcon {...p}>
      <path d="M288 96h320l192 192v544a48 48 0 0 1-48 48H288a48 48 0 0 1-48-48V144a48 48 0 0 1 48-48z" />
      <path d="M608 96v192h192" />
    </StrokeIcon>
  );
}

/** 文件夹。 */
export function FolderIcon(p: IconProps) {
  return (
    <StrokeIcon {...p}>
      <path d="M128 304a48 48 0 0 1 48-48h224l96 96h352a48 48 0 0 1 48 48v352a48 48 0 0 1-48 48H176a48 48 0 0 1-48-48z" />
    </StrokeIcon>
  );
}

/** 数据库(圆柱)。 */
export function DatabaseIcon(p: IconProps) {
  return (
    <StrokeIcon {...p}>
      <ellipse cx="512" cy="256" rx="288" ry="96" />
      <path d="M224 256v512M800 256v512M224 512a288 96 0 0 0 576 0M224 768a288 96 0 0 0 576 0" />
    </StrokeIcon>
  );
}

/** 网络(WiFi 弧)。 */
export function WifiIcon(p: IconProps) {
  return (
    <StrokeIcon {...p}>
      <path d="M192 448a448 448 0 0 1 640 0" />
      <path d="M320 608a288 288 0 0 1 384 0" />
      <circle cx="512" cy="768" r="48" fill="currentColor" stroke="none" />
    </StrokeIcon>
  );
}

/** 对话气泡(聊天/消息类)。 */
export function MessageIcon(p: IconProps) {
  return (
    <StrokeIcon {...p}>
      <path d="M240 160h544a80 80 0 0 1 80 80v352a80 80 0 0 1-80 80H512L320 848V672h-80a80 80 0 0 1-80-80V240a80 80 0 0 1 80-80z" />
    </StrokeIcon>
  );
}

/** 盾牌(安全/防护类)。 */
export function ShieldIcon(p: IconProps) {
  return (
    <StrokeIcon {...p}>
      <path d="M512 96l320 128v256c0 192-128 320-320 384-192-64-320-192-320-384V224z" />
      <polyline points="368,512 464,608 656,416" />
    </StrokeIcon>
  );
}

/** 放大镜(搜索类)。 */
export function SearchIcon(p: IconProps) {
  return (
    <StrokeIcon {...p}>
      <circle cx="448" cy="448" r="256" />
      <path d="M640 640 864 864" />
    </StrokeIcon>
  );
}

/** 下载(箭头 + 托盘)。 */
export function DownloadIcon(p: IconProps) {
  return (
    <StrokeIcon {...p}>
      <path d="M512 128v512" />
      <polyline points="352,480 512,640 672,480" />
      <path d="M256 832h512" />
    </StrokeIcon>
  );
}

/** 图片(山 + 日)。 */
export function ImageIcon(p: IconProps) {
  return (
    <StrokeIcon {...p}>
      <rect x="160" y="224" width="704" height="576" rx="48" />
      <circle cx="368" cy="432" r="48" fill="currentColor" stroke="none" />
      <polyline points="224,688 432,480 592,640 688,544 832,688" />
    </StrokeIcon>
  );
}

/** 音符(音乐类)。 */
export function MusicIcon(p: IconProps) {
  return (
    <StrokeIcon {...p}>
      <circle cx="384" cy="736" r="96" fill="currentColor" stroke="none" />
      <path d="M480 736V256" />
      <path d="M480 256c128 0 224 64 224 160" />
    </StrokeIcon>
  );
}

/** 闪电(快速/自动化)。 */
export function ZapIcon(p: IconProps) {
  return (
    <svg viewBox="0 0 1024 1024" width={p.size ?? 18} height={p.size ?? 18} className={p.className} fill="currentColor" aria-hidden>
      <path d="M576 64 256 576h224L448 960l320-512H544z" />
    </svg>
  );
}

/** 柱状图(统计/报表)。 */
export function ChartIcon(p: IconProps) {
  return (
    <StrokeIcon {...p}>
      <path d="M256 768V512M512 768V320M768 768V416M192 832h640" />
    </StrokeIcon>
  );
}

/** 地球(全球/站点类)。 */
export function GlobeIcon(p: IconProps) {
  return (
    <StrokeIcon {...p}>
      <circle cx="512" cy="512" r="352" />
      <path d="M160 512h704" />
      <ellipse cx="512" cy="512" rx="160" ry="352" />
    </StrokeIcon>
  );
}

/** 机器人(AI 类)。 */
export function BotIcon(p: IconProps) {
  return (
    <StrokeIcon {...p}>
      <rect x="288" y="320" width="448" height="384" rx="96" />
      <path d="M512 320V192" />
      <circle cx="512" cy="160" r="32" fill="currentColor" stroke="none" />
      <circle cx="432" cy="512" r="32" fill="currentColor" stroke="none" />
      <circle cx="592" cy="512" r="32" fill="currentColor" stroke="none" />
    </StrokeIcon>
  );
}

/** 相机(拍摄/截屏类)。 */
export function CameraIcon(p: IconProps) {
  return (
    <StrokeIcon {...p}>
      <path d="M224 288h96l64-96h256l64 96h96a48 48 0 0 1 48 48v416a48 48 0 0 1-48 48H224a48 48 0 0 1-48-48V336a48 48 0 0 1 48-48z" />
      <circle cx="512" cy="544" r="128" />
    </StrokeIcon>
  );
}

/** 图标 registry：name → 组件。插件 manifest icon 字段填这里的 key(按 PluginIconName 联合收型,防漂移)。 */
const REGISTRY: Record<PluginIconName, ComponentType<IconProps>> = {
  puzzle: PuzzleIcon,
  claude: ClaudeIcon,
  md: MdIcon,
  json: JsonIcon,
  apk: ApkIcon,
  scan: ScanIcon,
  // A2 通用图标(生成侧从这份清单挑;skill-sync 对账防漂移)
  bell: BellIcon,
  gauge: GaugeIcon,
  activity: ActivityIcon,
  cpu: CpuIcon,
  calendar: CalendarIcon,
  clock: ClockIcon,
  terminal: TerminalIcon,
  file: FileIcon,
  folder: FolderIcon,
  database: DatabaseIcon,
  wifi: WifiIcon,
  message: MessageIcon,
  shield: ShieldIcon,
  search: SearchIcon,
  download: DownloadIcon,
  image: ImageIcon,
  music: MusicIcon,
  zap: ZapIcon,
  chart: ChartIcon,
  globe: GlobeIcon,
  bot: BotIcon,
  camera: CameraIcon,
};

// ─── 字母头像兜底(通讯录式:名首字 + 按名固定底色)───────────────────────────

/** 头像底色板(白字可读的中饱和色;固定不随主题 —— 与固定彩色图标同哲学)。 */
const AVATAR_COLORS = [
  '#7C6FD0', '#4E9DBF', '#4FA876', '#C29B4B', '#C46B6B',
  '#A86CBB', '#5B9EA8', '#C07A4B', '#6B87C4', '#8A8FA8',
];

/** 按种子串稳定取色(同插件永远同色;展示层用,不追求加密强度)。 */
export function avatarColorFor(seed: string): string {
  let h = 0;
  for (let i = 0; i < seed.length; i++) h = (h * 31 + seed.charCodeAt(i)) >>> 0;
  return AVATAR_COLORS[h % AVATAR_COLORS.length];
}

/** 字母头像:名首字(中英文皆可)+ 固定底色圆角块。 */
function LetterAvatar({ text, size }: { text: string; size: number }) {
  const ch = [...text.trim()][0]?.toUpperCase() ?? '?';
  return (
    <span
      role="img"
      aria-label={text}
      style={{ width: size, height: size, backgroundColor: avatarColorFor(text), fontSize: Math.round(size * 0.56) }}
      className="inline-flex select-none items-center justify-center rounded-[var(--radius-sm)] font-medium leading-none text-white"
    >
      {ch}
    </span>
  );
}

/**
 * svg 源净化(2026-09-26,iconSvg 加菜的渲染半边):manifest.iconSvg 是插件自带的原样
 * svg 字符串,渲染前剥掉可执行面 —— 事件属性(on 前缀属性、href 里的 javascript:)、
 * <script>/<foreignObject>(可嵌 HTML)。innerHTML 注入的 <script> 本不执行,但事件
 * 属性会;一并剥 = 双保险。非 svg 内容(不以 <svg 开头)整体拒渲染。
 */
export function sanitizeSvgSource(src: string): string | null {
  const trimmed = src.trim();
  if (!trimmed.startsWith('<svg') || !trimmed.endsWith('</svg>')) return null;
  return trimmed
    .replace(/\son[a-z]+\s*=\s*("[^"]*"|'[^']*'|[^\s>]+)/gi, '')
    .replace(/<script[\s\S]*?<\/script>/gi, '')
    .replace(/<foreignObject[\s\S]*?<\/foreignObject>/gi, '')
    .replace(/(javascript|data):/gi, '');
}

/**
 * 渲染插件图标。优先级:svg 源(iconSvg,工坊/官方自带图形)> registry 名 > 字母头像 > null。
 *
 * @example
 * <PluginIcon name="claude" size={20} />
 * <PluginIcon name="" fallback={m.name ?? m.id} size={18} svg={m.iconSvg} />
 */
export function PluginIcon({
  name,
  size = 18,
  className,
  fallback,
  svg,
}: {
  name: string;
  size?: number;
  className?: string;
  /** 兜底文案(插件名/id):图标名不认识时渲染首字头像。 */
  fallback?: string;
  /** 原样 svg 源码(manifest.iconSvg;优先于 registry 名;净化后注入)。 */
  svg?: string;
}): ReactElement | null {
  if (svg) {
    const clean = sanitizeSvgSource(svg);
    if (clean) {
      return (
        <span
          role="img"
          aria-label={fallback ?? name}
          style={{ width: size, height: size }}
          className={'inline-flex shrink-0 items-center justify-center [&_svg]:h-full [&_svg]:w-full ' + (className ?? '')}
          // 净化后的纯图形 svg(事件属性/script/foreignObject 已剥);currentColor 随主题
          dangerouslySetInnerHTML={{ __html: clean }}
        />
      );
    }
    // svg 源非法 → 落到 name/头像 兜底链
  }
  // manifest 来自运行时 JSON(icon 字段实际是 string;类型面约束的是仓内声明),未知名 → 头像兜底
  const C = REGISTRY[name as PluginIconName];
  if (C) return <C size={size} className={className} />;
  if (fallback) return <LetterAvatar text={fallback} size={size} />;
  return null;
}
