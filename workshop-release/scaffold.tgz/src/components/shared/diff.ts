/** 行级 diff(LCS 动规,无依赖)。供 DiffView 用,也供测试。 */
export type DiffLineType = 'add' | 'del' | 'ctx';
export interface DiffLine {
  type: DiffLineType;
  text: string;
}

/** 计算 oldText → newText 的行 diff(最少编辑:LCS 公共行保留,余者标增/删)。 */
export function lineDiff(oldText: string, newText: string): DiffLine[] {
  const a = oldText.length === 0 ? [] : oldText.split('\n');
  const b = newText.length === 0 ? [] : newText.split('\n');
  const m = a.length;
  const n = b.length;
  // dp[i][j] = a[i:] 与 b[j:] 的 LCS 长度
  const dp: number[][] = Array.from({ length: m + 1 }, () => new Array<number>(n + 1).fill(0));
  for (let i = m - 1; i >= 0; i--) {
    for (let j = n - 1; j >= 0; j--) {
      dp[i][j] = a[i] === b[j] ? dp[i + 1][j + 1] + 1 : Math.max(dp[i + 1][j], dp[i][j + 1]);
    }
  }
  const out: DiffLine[] = [];
  let i = 0;
  let j = 0;
  while (i < m && j < n) {
    if (a[i] === b[j]) {
      out.push({ type: 'ctx', text: a[i] });
      i++;
      j++;
    } else if (dp[i + 1][j] >= dp[i][j + 1]) {
      out.push({ type: 'del', text: a[i] });
      i++;
    } else {
      out.push({ type: 'add', text: b[j] });
      j++;
    }
  }
  while (i < m) {
    out.push({ type: 'del', text: a[i] });
    i++;
  }
  while (j < n) {
    out.push({ type: 'add', text: b[j] });
    j++;
  }
  return out;
}
