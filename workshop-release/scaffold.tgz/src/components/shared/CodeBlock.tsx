export interface CodeBlockProps {
  code: string;
  lang?: string;
  className?: string;
}

/** 代码块(等宽 + 可选语言标)。M19 起步版;语法高亮后续(接 highlight.js / shiki)。 */
export function CodeBlock({ code, lang, className = '' }: CodeBlockProps) {
  return (
    <div className={`overflow-auto rounded-[var(--radius-md)] bg-base ${className}`.trim()}>
      {lang && (
        <div className="border-b border-border px-3 py-1 font-mono text-[length:var(--fs-2xs)] text-fg-muted">
          {lang}
        </div>
      )}
      <pre className="p-3 font-mono text-[length:var(--fs-sm)] leading-relaxed text-fg">{code}</pre>
    </div>
  );
}
