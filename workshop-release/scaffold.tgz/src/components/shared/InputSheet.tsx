import { useEffect, useState } from 'react';
import { Modal } from './Modal';
import { Button } from './Button';
import { keepKeyboardIfOpen } from '@/core/feedback/useKeyboardInset';

export interface InputSheetProps {
  open: boolean;
  title?: string;
  placeholder?: string;
  initialValue?: string;
  confirmText?: string;
  /** 默认 true:确认后自动关 Sheet。传 false 时由调用方控制关时机
   *  (用于异步确认:成功才关、失败留 Sheet 可重试;配合 confirming 显「…中」)。 */
  closeOnConfirm?: boolean;
  /** true 时禁用确认按钮(异步处理中防双击);配合 confirmText 显「…中」文案。 */
  confirming?: boolean;
  onConfirm: (value: string) => void;
  onClose: () => void;
}

/** 单值输入面板(新建文件夹/文件、重命名用)。输入框 + 回车提交;居中 Modal。 */
export function InputSheet({
  open,
  title,
  placeholder,
  initialValue = '',
  confirmText = '确认',
  closeOnConfirm = true,
  confirming = false,
  onConfirm,
  onClose,
}: InputSheetProps) {
  const [val, setVal] = useState(initialValue);
  useEffect(() => {
    if (open) setVal(initialValue);
  }, [open, initialValue]);

  const submit = (): void => {
    if (!val.trim()) return;
    onConfirm(val);
    if (closeOnConfirm) onClose();
  };

  // 居中弹窗(Modal 内容区自带 p-4,内层不再补)。
  return (
    <Modal open={open} onClose={onClose}>
      {/* keepKeyboardIfOpen:键盘开时不因点面板收键盘(可继续输) */}
      <div onMouseDown={keepKeyboardIfOpen}>
        {title && <div className="mb-2 font-medium text-fg">{title}</div>}
        <input
          autoFocus
          value={val}
          placeholder={placeholder}
          onChange={(e) => setVal(e.target.value)}
          onKeyDown={(e) => {
            if (e.key === 'Enter') submit();
          }}
          className="mb-4 w-full rounded-[var(--radius-sm)] border border-border bg-input px-3 py-2 text-fg outline-none focus:border-accent"
        />
        <div className="flex gap-2">
          <Button variant="ghost" size="md" className="flex-1" onClick={onClose}>
            取消
          </Button>
          <Button variant="accent" size="md" className="flex-1" onClick={submit} disabled={!val.trim() || confirming}>
            {confirmText}
          </Button>
        </div>
      </div>
    </Modal>
  );
}
