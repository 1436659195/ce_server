import { useEffect, type ReactNode } from 'react';
import { useKeyboardHeight } from '@/core/feedback/useKeyboardInset';

export interface SheetProps {
  open: boolean;
  onClose: () => void;
  children: ReactNode;
  dismissible?: boolean;
  /** 抬一层到 --z-modal-top:弹在 z-modal 浮层(如文件工作区)之上时的次级 Sheet。 */
  top?: boolean;
}

/** 底部上拉面板(CreateSheet/TerminalPicker 等用;移植自旧 bottom-sheet overlay 模式)。
 *  层级用 --z-modal(高于 tab 栏 z-dropdown):底 Sheet 是覆盖全屏的模态浮层,应压暗并挡住 tab 栏
 *  (否则 tab 栏玻璃头从遮罩上方冒出、+ 仍可点 —— 真机反馈)。
 *  top=true 时用 --z-modal-top:Sheet 本身就渲染在某个 z-modal 浮层内部(同值靠 DOM 顺序太脆,
 *  插件再自弹同层浮层会乱),抬一层保证次级浮层永远在上。
 *  键盘避让:外层 fixed inset-0 锚定的是布局视口,键盘弹起时 items-end 的卡片会落到键盘**后面**
 *  (只能看见上边缘)。给外层加 paddingBottom=键盘高度,把卡片顶到键盘上方。 */
export function Sheet({ open, onClose, children, dismissible = true, top = false }: SheetProps) {
  const keyboardHeight = useKeyboardHeight();
  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape' && dismissible) onClose();
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [open, onClose, dismissible]);

  if (!open) return null;

  return (
    <div
      className={
        'fixed inset-0 flex items-end justify-center bg-black/50 anim-fade-in ' +
        (top ? 'z-[var(--z-modal-top)]' : 'z-[var(--z-modal)]')
      }
      style={{ paddingBottom: keyboardHeight }}
      onClick={() => dismissible && onClose()}
    >
      <div
        className="bg-panel border border-border rounded-t-[var(--radius-xl)] shadow-[var(--shadow-lg)] max-h-[85vh] w-full max-w-lg overflow-auto pb-[env(safe-area-inset-bottom)] anim-sheet-in"
        onClick={(e) => e.stopPropagation()}
      >
        {children}
      </div>
    </div>
  );
}
