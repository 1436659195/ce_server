/**
 * Markdown 渲染器(通用共享组件)—— react-markdown + remark-gfm 换芯版。
 *
 * 演进:最初为 md-view 自写 ~150 行轻量渲染器(不引 ~60KB 依赖的 YAGNI 取舍),后提升到 shared。
 * 随 cc-conversation 拿它渲染 LLM 回复(旗舰场景,渲染质量 = 产品质感)、真实 README 各种形态涌入,
 * 自写已长到 230 行仍带结构性缺陷(嵌套列表拆散 / 松散有序列表编号重置 / 任务列表不支持),
 * 继续修等于逐步自研 CommonMark —— 换芯 react-markdown 一次关掉全部语法缺口(上游 micromark 维护)。
 *
 * 安全姿态(与换芯前一致):
 *  - 默认不直通原始 HTML(未挂 rehype-raw,标签一律按文本渲染)—— 渲染的是远端机器上的不可信文件;
 *  - react-markdown 默认 urlTransform 只放行安全协议,我们再叠一层 safeHref 白名单兜底;
 *  - 图片不加载(见 img 映射),阻不可信外链请求。
 *
 * 对外 API 不变:renderMarkdown(text) / <Markdown>{text}</Markdown>;消费方(md-view /
 * cc-conversation)零改动。原 tokenizeInline / renderInline 导出已删(全库无消费方)。
 */
import { isValidElement, type CSSProperties, type ReactNode } from 'react';
import ReactMarkdown, { type Components } from 'react-markdown';
import remarkGfm from 'remark-gfm';
import { Image as ImageIcon } from 'lucide-react';
import { CodeBlock } from '@/components/shared/CodeBlock';

/** 安全 URL:只放行 http/https/相对路径/mailto(阻 javascript:/data: 等 XSS 入口)。 */
function safeHref(url: string): string | null {
  const trimmed = url.trim();
  if (/^(https?:\/\/|\/|\.\/|\.\.\/|#|mailto:)/i.test(trimmed)) return trimmed;
  return null; // 协议不在白名单 → 不渲染为链接
}

/** hast 节点的松散形状(只取 properties.style,不为类型引入 hast 依赖)。 */
type HastLike = { properties?: Record<string, unknown> } | undefined;

/**
 * 从 hast 节点取列对齐:remark-gfm 对表格 th/td 产出 align 属性(left/center/right,
 * 默认左对齐不产出)→ 转成 React style(align 是废弃 HTML 属性,映射成 textAlign 再用)。
 */
function textAlignOf(node: HastLike): CSSProperties | undefined {
  const align = node?.properties?.align;
  return align === 'left' || align === 'center' || align === 'right' ? { textAlign: align } : undefined;
}

/** 递归取 React 子树的纯文本(用于从 pre>code 元素里抠代码内容)。 */
function nodeText(n: ReactNode): string {
  if (n == null || typeof n === 'boolean') return '';
  if (typeof n === 'string' || typeof n === 'number') return String(n);
  if (Array.isArray(n)) return n.map(nodeText).join('');
  if (isValidElement(n)) return nodeText((n.props as { children?: ReactNode }).children);
  return '';
}

/** 从 pre 的子 <code className="language-xxx"> 元素抠出 { code, lang }。 */
function extractCode(children: ReactNode): { code: string; lang?: string } {
  const el = Array.isArray(children) ? children[0] : children;
  if (!isValidElement(el)) return { code: nodeText(children) };
  const props = el.props as { className?: string; children?: ReactNode };
  const lang = /language-([\w-]+)/.exec(props.className ?? '')?.[1];
  return { code: nodeText(props.children), lang };
}

/**
 * 元素 → 组件映射:主题 token + CodeBlock 集成 + 安全兜底。
 * 样式沿用换芯前的视觉(字号/间距/颜色 token 不变)。
 */
const MD_COMPONENTS: Components = {
  // 围栏代码块:pre 的子 code 元素整个换成 CodeBlock(内部 <pre> 由 CodeBlock 自渲染)
  pre: ({ children }) => {
    const { code, lang } = extractCode(children);
    return <CodeBlock code={code} lang={lang} />;
  },
  // 行内代码(块级 code 已被上面的 pre 整体替换,不会走到这)
  code: ({ children }) => (
    <code className="rounded-[var(--radius-sm)] bg-base px-1 py-0.5 font-mono text-[length:var(--fs-xs)]">
      {children}
    </code>
  ),
  // 链接:白名单外的协议渲染为纯文本(与换芯前行为一致)
  a: ({ href, children }) => {
    const safe = href ? safeHref(href) : null;
    if (safe === null) return <>{children}</>;
    return (
      <a href={safe} target="_blank" rel="noreferrer noopener" className="text-accent underline underline-offset-2">
        {children}
      </a>
    );
  },
  // 图片:不加载(远端文件的相对 src 取不到;绝对外链会向不可信源发请求)→ 占位符显示 alt
  img: ({ alt, src }) => (
    <span className="inline-flex max-w-full items-center gap-1 rounded-[var(--radius-sm)] border border-border bg-base px-1.5 py-0.5 font-mono text-[length:var(--fs-xs)] text-fg-muted">
      <ImageIcon size={12} className="shrink-0" />
      <span className="truncate">{alt || String(src ?? '')}</span>
    </span>
  ),
  // 表格:外层横向滚动(宽表在手机上不撑破布局),列对齐从 hast style 解析
  table: ({ children }) => (
    <div className="my-2 overflow-x-auto">
      <table className="w-full border-collapse whitespace-nowrap">{children}</table>
    </div>
  ),
  th: ({ node, children }) => (
    <th style={textAlignOf(node)} className="px-2 py-1 font-semibold text-fg">
      {children}
    </th>
  ),
  td: ({ node, children }) => (
    <td style={textAlignOf(node)} className="px-2 py-1 align-top text-fg">
      {children}
    </td>
  ),
  tr: ({ children }) => <tr className="border-b border-border/60">{children}</tr>,
  // 标题(h1-h3 递减字号,h4 起回退小字号,与换芯前一致)
  h1: ({ children }) => <h1 className="mt-2 mb-1 font-semibold text-[length:var(--fs-2xl)] text-fg">{children}</h1>,
  h2: ({ children }) => <h2 className="mt-2 mb-1 font-semibold text-[length:var(--fs-xl)] text-fg">{children}</h2>,
  h3: ({ children }) => <h3 className="mt-2 mb-1 font-semibold text-[length:var(--fs-lg)] text-fg">{children}</h3>,
  h4: ({ children }) => <h4 className="mt-2 mb-1 font-semibold text-[length:var(--fs-base)] text-fg">{children}</h4>,
  h5: ({ children }) => <h5 className="mt-2 mb-1 font-semibold text-[length:var(--fs-sm)] text-fg">{children}</h5>,
  h6: ({ children }) => <h6 className="mt-2 mb-1 font-semibold text-[length:var(--fs-xs)] text-fg-muted">{children}</h6>,
  p: ({ children }) => <p className="my-1 leading-relaxed text-fg">{children}</p>,
  ul: ({ children }) => <ul className="my-1 ml-5 list-disc text-fg">{children}</ul>,
  // start 透传:非 1 起始的有序列表(如 5. ...)编号才正确
  ol: ({ children, start }) => (
    <ol start={start} className="my-1 ml-5 list-decimal text-fg">
      {children}
    </ol>
  ),
  // 任务列表项:去掉圆点,checkbox 用原生 disabled input(纯展示)
  li: ({ className, children }) => {
    const isTask = typeof className === 'string' && className.includes('task-list-item');
    return <li className={isTask ? 'my-0.5 list-none' : className}>{children}</li>;
  },
  input: ({ checked }) => (
    <input type="checkbox" readOnly checked={checked ?? false} className="mr-1 align-middle" />
  ),
  blockquote: ({ children }) => (
    <blockquote className="my-2 border-l-2 border-border pl-3 text-fg-muted">{children}</blockquote>
  ),
  hr: () => <hr className="my-3 border-border" />,
  strong: ({ children }) => <strong className="font-semibold text-fg">{children}</strong>,
  del: ({ children }) => <del className="text-fg-muted">{children}</del>,
};

/** 把 markdown 文本渲染成 React 节点数组(对外 API 与换芯前一致)。 */
export function renderMarkdown(text: string): ReactNode[] {
  return [
    <ReactMarkdown key="md" remarkPlugins={[remarkGfm]} components={MD_COMPONENTS}>
      {text}
    </ReactMarkdown>,
  ];
}

/** Markdown 渲染组件(块级容器)。用法:<Markdown>{mdString}</Markdown>。 */
export function Markdown({ children }: { children: string }): ReactNode {
  return <div className="markdown">{renderMarkdown(children)}</div>;
}
