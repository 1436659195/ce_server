import { lineDiff, type DiffLineType } from './diff';

export interface DiffViewProps {
  oldText: string;
  newText: string;
}

const CLASS: Record<DiffLineType, string> = {
  add: 'text-success',
  del: 'text-danger',
  ctx: 'text-fg-muted',
};
const SIGN: Record<DiffLineType, string> = { add: '+', del: '-', ctx: ' ' };

/** 行级 diff 视图(CC 审查文件改动 / git 用)。add 绿 del 红 ctx 灰。 */
export function DiffView({ oldText, newText }: DiffViewProps) {
  const lines = lineDiff(oldText, newText);
  return (
    <pre className="overflow-auto rounded-[var(--radius-md)] bg-base p-3 font-mono text-[length:var(--fs-sm)] leading-relaxed">
      {lines.map((l, i) => (
        <div key={i} className={CLASS[l.type]}>
          <span className="select-none opacity-60">{SIGN[l.type]}</span>
          {l.text}
        </div>
      ))}
    </pre>
  );
}
