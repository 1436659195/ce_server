import type { HTMLAttributes } from 'react';

export interface TextProps extends HTMLAttributes<HTMLSpanElement> {
  muted?: boolean;
  secondary?: boolean;
}

export function Text({ children, muted, secondary, className = '', ...rest }: TextProps) {
  const tone = muted ? 'text-fg-muted' : secondary ? 'text-fg-secondary' : 'text-fg';
  return (
    <span className={`${tone} ${className}`.trim()} {...rest}>
      {children}
    </span>
  );
}
