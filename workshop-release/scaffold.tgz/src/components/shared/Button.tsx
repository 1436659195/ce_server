import { forwardRef, type ButtonHTMLAttributes } from 'react';

export type ButtonVariant = 'default' | 'accent' | 'ghost' | 'danger';
export type ButtonSize = 'sm' | 'md';

const BASE =
  'inline-flex items-center justify-center gap-1.5 font-medium rounded-[var(--radius-md)] tap-scale select-none touch-manipulation disabled:opacity-50 disabled:pointer-events-none';

const VARIANTS: Record<ButtonVariant, string> = {
  default: 'bg-elevated text-fg hover:bg-input border border-border',
  accent: 'bg-accent text-on-accent hover:bg-accent-press',
  ghost: 'text-fg-secondary hover:text-fg hover:bg-elevated',
  danger: 'bg-danger text-white hover:opacity-90',
};

const SIZES: Record<ButtonSize, string> = {
  sm: 'h-9 px-3 text-[length:var(--fs-sm)]',
  // md 走 44px(iOS HIG 最小触控目标),Apple 风 generous padding。
  md: 'h-11 px-4 text-[length:var(--fs-base)]',
};

export interface ButtonProps extends ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: ButtonVariant;
  size?: ButtonSize;
}

export const Button = forwardRef<HTMLButtonElement, ButtonProps>(function Button(
  { variant = 'default', size = 'md', className = '', ...rest },
  ref,
) {
  return (
    <button
      ref={ref}
      className={`${BASE} ${VARIANTS[variant]} ${SIZES[size]} ${className}`.trim()}
      {...rest}
    />
  );
});
