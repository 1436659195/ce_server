import { useEffect, type ReactNode } from 'react';
import { createPortal } from 'react-dom';
import { ChevronLeft } from 'lucide-react';

export interface ModalProps {
  open: boolean;
  onClose: () => void;
  children: ReactNode;
  title?: string;
  /** 遮罩点击是否关闭(默认 true) */
  dismissible?: boolean;
  /** 返回上一弹窗(单弹窗导航,2026-09-28):传了在标题左侧显返回钮;缺省不显。 */
  onBack?: () => void;
}

/** 居中模态遮罩(Esc 关闭;遮罩点击关闭)。移植自旧 ModalShell 模式。 */
export function Modal({ open, onClose, children, title, dismissible = true, onBack }: ModalProps) {
  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape' && dismissible) onClose();
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [open, onClose, dismissible]);

  if (!open) return null;

  // portal 到 body:Modal 的 `fixed inset-0` 会被带 backdrop-filter / transform 的祖先变成
  // 相对该祖先(KeyBarEditor 从 SpecialKeyBar 玻璃条里弹,玻璃 backdrop-filter 是 containing block
  // → fixed 被困在底栏小条,只露上半 + 穿模)。portal 出 body → fixed 相对视口、居中满屏不裁。
  return createPortal(
    <div
      className="fixed inset-0 z-[var(--z-modal)] flex items-center justify-center bg-black/50 p-4 anim-fade-in"
      onClick={() => dismissible && onClose()}
    >
      <div
        className="bg-panel border border-border rounded-[var(--radius-xl)] shadow-[var(--shadow-lg)] max-h-[90vh] w-full max-w-lg overflow-auto anim-spring-in"
        onClick={(e) => e.stopPropagation()}
      >
        {title && (
          <div className="flex items-center gap-1 border-b border-border px-4 py-3 text-fg font-medium">
            {onBack && (
              <button
                type="button"
                aria-label="返回"
                onClick={onBack}
                className="-ml-2 mr-1 flex h-7 w-7 shrink-0 items-center justify-center rounded-[var(--radius-sm)] text-fg-secondary tap-scale hover:bg-input"
              >
                <ChevronLeft size={18} />
              </button>
            )}
            <span className="min-w-0 flex-1 truncate">{title}</span>
          </div>
        )}
        <div className="p-4">{children}</div>
      </div>
    </div>,
    document.body,
  );
}
