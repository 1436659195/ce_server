// Lucide 图标统一封装(strokeWidth/尺寸一致)。用法:<Icon icon={Terminal} />
import type { LucideIcon } from 'lucide-react';

export type { LucideIcon };

export interface IconProps {
  icon: LucideIcon;
  size?: number;
  className?: string;
  strokeWidth?: number;
}

export function Icon({ icon: I, size = 18, className, strokeWidth = 2 }: IconProps) {
  return <I size={size} className={className} strokeWidth={strokeWidth} aria-hidden />;
}
