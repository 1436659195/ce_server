/**
 * ProgressBar —— 线性进度条(共享组件,插件可用)。
 *
 * 形状约定:**轨道与实体填充都是胶囊形**(rounded-full)。此前 apk-installer 内联版轨道是
 * 圆角、填充是矩形 → 进度未满时右缘生硬割裂(用户反馈);统一收进共享组件修掉,两端一致。
 * value ∈ [0,1];宽度百分比取整后渲染,transition 平滑推进。
 */
import type { ReactNode } from 'react';

export function ProgressBar({ value, className }: { value: number; className?: string }): ReactNode {
  const pct = Math.min(100, Math.max(0, Math.round(value * 100)));
  return (
    <div
      role="progressbar"
      aria-valuenow={pct}
      aria-valuemin={0}
      aria-valuemax={100}
      className={'h-2 w-full overflow-hidden rounded-full bg-input ' + (className ?? '')}
    >
      {/* 填充同样胶囊形:右缘随进度始终圆润(极小宽度时呈圆点,iOS 同款观感) */}
      <div className="h-full rounded-full bg-accent transition-[width]" style={{ width: `${pct}%` }} />
    </div>
  );
}
