/** JSON 渲染(平价体感:开箱不显糙)。M19 起步版:格式化 + 等宽;树/折叠后续再加。 */
export interface JSONViewerProps {
  data: unknown;
  className?: string;
}

export function JSONViewer({ data, className = '' }: JSONViewerProps) {
  let text: string;
  try {
    text = JSON.stringify(data, null, 2);
  } catch {
    text = String(data);
  }
  return (
    <pre
      className={`overflow-auto rounded-[var(--radius-md)] bg-base p-3 font-mono text-[length:var(--fs-sm)] leading-relaxed text-fg ${className}`.trim()}
    >
      {text}
    </pre>
  );
}
