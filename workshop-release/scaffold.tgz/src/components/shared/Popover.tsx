import { useEffect, useLayoutEffect, useRef, useState, type ReactNode, type RefObject } from 'react';
import { createPortal } from 'react-dom';

/** 锚点:长按手指坐标 {x,y}(菜单左上角对齐此处)或元素 ref(菜单贴其正下方)。 */
export type PopoverAnchor = { x: number; y: number } | RefObject<HTMLElement | null>;

export interface PopoverProps {
  open: boolean;
  onClose: () => void;
  /** 锚点:坐标或元素 ref。 */
  anchor: PopoverAnchor;
  children?: ReactNode;
  /** 卡片宽度(px);不传 = auto(由内容撑,最低 min-w)。 */
  width?: number;
  /** 可选标题行(如文件名;truncate + title 兜底)。 */
  title?: string;
  /** 遮罩点击 / Esc 是否关闭;默认 true。 */
  dismissible?: boolean;
  /** 卡片展开方向:bottom=锚点下方(默认,锚点=卡片顶)、top=锚点上方(锚点=卡片底,底部按钮用)。 */
  placement?: 'top' | 'bottom';
}

/**
 * 锚点下拉菜单 —— 模仿旧 app FileContextMenu.vue:
 *  - 全屏**透明**遮罩(不压暗,仅承接点外关闭)+ Esc 关;
 *  - 卡片 position:fixed 定位在锚点处,clamp 防溢出视口(抄旧 clamped);
 *  - max-h + overflow-auto:长列表可滚;
 *  - z-modal(200):盖住 tab 栏(z-dropdown=100)/文件面板(z-panel=45);
 *    与中央 Modal 同层,但二者不并存(菜单点动作后切走,不与后续确认框同屏)。
 *
 * 用于:长按文件菜单(锚=手指坐标)、终端「+」菜单(锚=按钮 ref,贴其下方)。
 */
export function Popover({ open, onClose, anchor, children, width, title, dismissible = true, placement = 'bottom' }: PopoverProps) {
  const cardRef = useRef<HTMLDivElement | null>(null);
  const [pos, setPos] = useState<{ left: number; top: number } | null>(null);

  // 量锚点 + clamp 算卡片 left/top。open 时算;卡片首帧可能还没尺寸 → rAF 二次校正。
  useLayoutEffect(() => {
    if (!open) {
      setPos(null);
      return;
    }
    const measure = (): void => {
      const el = cardRef.current;
      const cw = el?.offsetWidth || width || 168;
      const ch = el?.offsetHeight || 320;
      let x: number;
      let y: number;
      if ('x' in anchor) {
        x = anchor.x;
        y = anchor.y;
      } else {
        const a = anchor.current;
        if (!a) return;
        const r = a.getBoundingClientRect();
        x = r.left; // 贴按钮左
        y = r.bottom + 4; // 贴按钮下方 4px
      }
      const vw = typeof window !== 'undefined' ? window.innerWidth : 1024;
      const vh = typeof window !== 'undefined' ? window.innerHeight : 768;
      // placement=top:卡片底部对齐锚点(向上展开)→ 顶部 = 锚点 y - 卡片高。
      const topRaw = placement === 'top' ? y - ch : y;
      setPos({
        left: Math.max(8, Math.min(x, vw - cw - 8)),
        top: Math.max(8, Math.min(topRaw, vh - ch - 8)),
      });
    };
    measure();
    if (typeof requestAnimationFrame !== 'undefined') {
      const raf = requestAnimationFrame(measure); // 卡片有真实尺寸后再校正
      return () => cancelAnimationFrame(raf);
    }
    return undefined;
  }, [open, anchor, width, placement]);

  // Esc 关(dismissible 才挂)。
  useEffect(() => {
    if (!open || !dismissible) return;
    const onKey = (e: KeyboardEvent): void => {
      if (e.key === 'Escape') onClose();
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [open, onClose, dismissible]);

  if (!open) return null;

  return createPortal(
    <div
      className="fixed inset-0 z-[var(--z-modal)]"
      onClick={() => dismissible && onClose()}
      role="presentation"
    >
      <div
        ref={cardRef}
        role="menu"
        onClick={(e) => e.stopPropagation()}
        style={{
          left: pos ? `${pos.left}px` : '-9999px',
          top: pos ? `${pos.top}px` : '-9999px',
          width: width ? `${width}px` : undefined,
        }}
        className="anim-spring-in fixed flex max-h-[80vh] min-w-[10rem] flex-col overflow-auto rounded-[var(--radius-md)] border border-border bg-elevated p-1 shadow-[var(--shadow-lg)]"
      >
        {title && (
          <div className="truncate border-b border-border px-3 py-1.5 text-[length:var(--fs-sm)] text-fg-muted" title={title}>
            {title}
          </div>
        )}
        {children}
      </div>
    </div>,
    document.body,
  );
}
