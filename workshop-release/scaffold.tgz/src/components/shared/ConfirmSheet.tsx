import { Modal } from './Modal';
import { Button } from './Button';

export interface ConfirmSheetProps {
  open: boolean;
  title?: string;
  message: string;
  confirmText?: string;
  cancelText?: string;
  /** danger → 红色确认按钮(删除等) */
  danger?: boolean;
  /** 默认 true:确认后自动关 Sheet。传 false 时由调用方控制关时机
   *  (用于异步确认:成功才关、失败留 Sheet 可重试;配合 confirming 显「…中」)。 */
  closeOnConfirm?: boolean;
  /** true 时禁用确认按钮(异步处理中防双击);配合 confirmText 显「…中」文案。 */
  confirming?: boolean;
  onConfirm: () => void;
  onClose: () => void;
}

/** 确认面板(删除/大上传等用)。底 sheet + 取消/确认两按钮。 */
export function ConfirmSheet({
  open,
  title,
  message,
  confirmText = '确认',
  cancelText = '取消',
  danger = false,
  closeOnConfirm = true,
  confirming = false,
  onConfirm,
  onClose,
}: ConfirmSheetProps) {
  return (
    <Modal open={open} onClose={onClose}>
      <div>
        {title && <div className="mb-2 font-medium text-fg">{title}</div>}
        <p className="mb-4 whitespace-pre-wrap text-[length:var(--fs-sm)] text-fg-muted">{message}</p>
        <div className="flex gap-2">
          <Button variant="ghost" size="md" className="flex-1" onClick={onClose}>
            {cancelText}
          </Button>
          <Button
            variant={danger ? 'danger' : 'accent'}
            size="md"
            className="flex-1"
            disabled={confirming}
            onClick={() => {
              onConfirm();
              if (closeOnConfirm) onClose();
            }}
          >
            {confirmText}
          </Button>
        </div>
      </div>
    </Modal>
  );
}
