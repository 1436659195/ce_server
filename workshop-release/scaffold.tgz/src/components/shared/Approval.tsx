import type { ReactNode } from 'react';
import { Button } from './Button';

export interface ApprovalProps {
  /** 工具名(如 Write/Edit/Bash) */
  tool: string;
  /** 工具入参渲染(调用方决定怎么展示,如 <CodeBlock> 或 <JSONViewer>) */
  input: ReactNode;
  onAllow: () => void;
  onDeny: () => void;
  /** 信任窗口(秒):允许 N 秒内同工具自动放行;0/undefined=单次 */
  trustWindowSec?: number;
  onTrustWindow?: (sec: number) => void;
}

/**
 * 审批共享范式(baseline §7.5 #4):所有 agent 审查插件(CC/codex)审批体验一致。
 * 工具入参 + 允许/拒绝 + 可选信任窗口。
 */
export function Approval({ tool, input, onAllow, onDeny, trustWindowSec, onTrustWindow }: ApprovalProps) {
  return (
    <div className="w-[min(92vw,28rem)] rounded-[var(--radius-lg)] border border-border bg-panel p-3 shadow-[var(--shadow-lg)]">
      <div className="mb-2 flex items-center gap-2">
        <span className="rounded-[var(--radius-sm)] bg-accent-soft px-2 py-0.5 text-[length:var(--fs-xs)] text-accent">
          {tool}
        </span>
        <span className="text-fg-muted text-[length:var(--fs-sm)]">请求批准</span>
      </div>
      <div className="max-h-[40vh] overflow-auto">{input}</div>
      <div className="mt-3 flex items-center gap-2">
        <Button variant="accent" size="sm" onClick={onAllow}>
          允许
        </Button>
        <Button variant="danger" size="sm" onClick={onDeny}>
          拒绝
        </Button>
        {onTrustWindow && (
          <label className="ml-auto flex items-center gap-1 text-[length:var(--fs-xs)] text-fg-muted">
            信任
            <select
              className="rounded-[var(--radius-sm)] border border-border bg-input px-1 py-0.5 text-fg"
              value={trustWindowSec ?? 0}
              onChange={(e) => onTrustWindow(Number(e.target.value))}
            >
              <option value={0}>单次</option>
              <option value={300}>5 分钟</option>
              <option value={3600}>1 小时</option>
            </select>
          </label>
        )}
      </div>
    </div>
  );
}
