import type { HTMLAttributes } from 'react';

export function Card({ children, className = '', ...rest }: HTMLAttributes<HTMLDivElement>) {
  return (
    <div
      className={`bg-panel border border-border rounded-[var(--radius-lg)] p-3 shadow-[var(--shadow-sm)] anim-fade-in ${className}`.trim()}
      {...rest}
    >
      {children}
    </div>
  );
}
