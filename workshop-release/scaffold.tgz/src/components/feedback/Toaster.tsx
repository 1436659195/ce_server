import { useToasts, dismissToast, type ToastKind } from '@/core/feedback/useToast';

const BORDER_BY_KIND: Record<ToastKind, string> = {
  info: 'border-border',
  success: 'border-success',
  error: 'border-danger',
};

/** Toast 渲染层:固定底部居中栈。点击即摘。kind → 边框色(success/error 提示)。 */
export function Toaster() {
  const toasts = useToasts();
  if (toasts.length === 0) return null;
  return (
    <div className="pointer-events-none fixed inset-x-0 bottom-[calc(var(--safe-bottom,0px)+0.5rem)] z-[var(--z-toast)] flex flex-col items-center gap-2 px-4">
      {toasts.map((t) => (
        <button
          key={t.id}
          onClick={() => dismissToast(t.id)}
          className={`pointer-events-auto max-w-[92vw] rounded-[var(--radius-md)] border bg-panel px-3 py-2 text-left text-[length:var(--fs-sm)] text-fg shadow-[var(--shadow-md)] ${BORDER_BY_KIND[t.kind]}`}
        >
          {t.message}
        </button>
      ))}
    </div>
  );
}
