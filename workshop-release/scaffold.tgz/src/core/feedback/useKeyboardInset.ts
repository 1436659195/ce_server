/**
 * 键盘高度感知 —— 沉浸全屏下 Android adjustResize 被压制,软键盘弹起 WebView 不收缩、
 * 直接盖底栏。靠 @capacitor/keyboard 的 keyboardHeight(按 IME insets 给值,全屏下不失效)+
 * visualViewport 兜底拿到高度,底栏/面板据此自己顶到键盘上方。
 *
 * keepKeyboardIfOpen:键盘可见性感知的 mousedown guard —— 键盘开→preventDefault(点 UI 不收键盘、
 * 可继续输入);键盘收→放行(让 textarea 自然失焦,不卡焦点重弹 IME)。挂到 FilePanel/KeyBar 等
 * 不该收键盘的 UI 根节点的 @mousedown。
 *
 * 桌面/dev 无软键盘 → height 恒 0 → keepKeyboardIfOpen 全程放行(测不出 guard,需真机)。
 */
import { useSyncExternalStore } from 'react';
import type { MouseEvent } from 'react';

let keyboardHeight = 0;
const listeners = new Set<() => void>();

// 回前台键盘抑制窗口(Date.now() 戳):> 0 时 keyboardWillShow 被拦下并主动 hide。
// 回前台时 WebView 会恢复终端 textarea 焦点 → IME 自动弹起;在此窗口内拦截 + 收起,避免「唤出即弹键盘」。
let suppressUntil = 0;

function emit(): void {
  listeners.forEach((l) => l());
}

function setHeight(h: number): void {
  // ≤4px 当无键盘(抖动/亚像素噪声);过滤下沉到这 → 插件事件、viewport 兜底、测试入口统一生效。
  const next = h > 4 ? Math.max(0, Math.round(h)) : 0;
  if (next !== keyboardHeight) {
    keyboardHeight = next;
    emit();
  }
}

export function getKeyboardHeight(): number {
  return keyboardHeight;
}
/** 主动归零(回前台用:切走时 keyboardWillHide 常漏触发 → 回前台强制归零,免 paddingBottom 残留露负一屏)。 */
export function resetKeyboardHeight(): void {
  setHeight(0);
}
export function isKeyboardVisible(): boolean {
  return keyboardHeight > 0;
}

function subscribe(cb: () => void): () => void {
  listeners.add(cb);
  return () => {
    listeners.delete(cb);
  };
}

let inited = false;
/** 初始化(挂一次):插件事件(精确)+ visualViewport 兜底。仅 window 环境跑。 */
export function initKeyboardInset(): void {
  if (inited || typeof window === 'undefined') return;
  inited = true;
  // 动态 import 避免非原生环境/ssr 报错;失败则只用 visualViewport 兜底。
  import('@capacitor/keyboard')
    .then(({ Keyboard }) => {
      Keyboard.addListener('keyboardWillShow', (info) => {
        // 回前台抑制窗口内:终端 textarea 焦点恢复触发的 IME 弹起 → 直接收起,不记账、不撑布局。
        if (Date.now() < suppressUntil) {
          Keyboard.hide().catch(() => undefined);
          return;
        }
        setHeight(info.keyboardHeight ?? 0);
      }).catch(() => undefined);
      Keyboard.addListener('keyboardWillHide', () => setHeight(0)).catch(() => undefined);
    })
    .catch(() => undefined);
  // visualViewport 兜底:插件不可用 / web 测试环境。
  const vv = window.visualViewport;
  if (vv) {
    const recompute = (): void => {
      const h = window.innerHeight - vv.height - vv.offsetTop;
      setHeight(h); // ≤4px 过滤在 setHeight 内统一
    };
    vv.addEventListener('resize', recompute);
    vv.addEventListener('scroll', recompute);
  }
}

/** 键盘可见性感知 guard:键盘开→挡默认聚焦(不收键盘);键盘收→放行。挂到不该收键盘的 UI 根 @mousedown。 */
export function keepKeyboardIfOpen(e: MouseEvent | Event): void {
  if (keyboardHeight > 0) e.preventDefault();
}

/**
 * 回前台键盘抑制:设一个 ms 级窗口,窗口内 keyboardWillShow 被拦下并主动 hide。
 * 用于 appStateChange isActive —— 回前台时 WebView 恢复终端 textarea 焦点会让 IME 自动弹起,
 * 此窗口拦截掉那次自动弹起(用户需主动点终端才重新弹键盘)。默认 500ms 覆盖焦点恢复抖动。
 */
export function suppressKeyboardBriefly(ms = 500): void {
  suppressUntil = Date.now() + ms;
}

/**
 * 主动收起键盘:blur 当前聚焦元素(xterm textarea 为主)+ 调原生 Keyboard.hide()。
 * 与 suppressKeyboardBriefly 配合用于回前台抑制;单独调也可强制收键盘。
 * 动态 import Keyboard 避免非原生环境报错;blur 作 web/失败兜底。
 */
export function hideKeyboard(): void {
  if (typeof document !== 'undefined') {
    (document.activeElement as HTMLElement | null)?.blur?.();
  }
  if (typeof window !== 'undefined') {
    import('@capacitor/keyboard')
      .then(({ Keyboard }) => Keyboard.hide().catch(() => undefined))
      .catch(() => undefined);
  }
}

/** 测试用:直接设高度(绕过插件/viewport)。 */
export function _setKeyboardHeightForTest(h: number): void {
  setHeight(h);
}

export function useKeyboardHeight(): number {
  return useSyncExternalStore(subscribe, getKeyboardHeight, getKeyboardHeight);
}
