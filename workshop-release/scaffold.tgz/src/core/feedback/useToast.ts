/**
 * Toast 反馈 —— 模块级 store + useSyncExternalStore(同 useTheme/profiles 模式)。
 * 到处用:attachDenied、复制结果、下载进度、连接失败。短消息 + 自动消失。
 *
 * getSnapshot 返回模块级 `toasts`(只在变更时整体重赋值)→ 两次变更间引用稳定,
 * 不触发 useSyncExternalStore 无限重渲染(对照 useTerminals.getState 曾返回新字面量致白屏)。
 */
import { useSyncExternalStore } from 'react';

export type ToastKind = 'info' | 'success' | 'error';

export interface Toast {
  id: string;
  message: string;
  kind: ToastKind;
}

let _seq = 0;
let toasts: Toast[] = [];
const listeners = new Set<() => void>();

function emit(): void {
  listeners.forEach((l) => l());
}

function subscribe(cb: () => void): () => void {
  listeners.add(cb);
  return () => {
    listeners.delete(cb);
  };
}

/** 推一条 toast;默认 2500ms 自动消失。返回 id(可提前 dismissToast)。 */
export function showToast(message: string, kind: ToastKind = 'info', durationMs = 2500): string {
  const id = `t_${++_seq}`;
  toasts = [...toasts, { id, message, kind }];
  emit();
  if (durationMs > 0) {
    setTimeout(() => dismissToast(id), durationMs);
  }
  return id;
}

/** 手动摘掉一条(下载进度等长显 toast 用)。 */
export function dismissToast(id: string): void {
  if (!toasts.some((t) => t.id === id)) return;
  toasts = toasts.filter((t) => t.id !== id);
  emit();
}

/** 测试用:清空(生产不调)。 */
export function _resetToasts(): void {
  toasts = [];
  emit();
}

export function useToasts(): Toast[] {
  return useSyncExternalStore(subscribe, () => toasts, () => toasts);
}
