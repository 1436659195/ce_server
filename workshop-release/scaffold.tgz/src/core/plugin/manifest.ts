/**
 * 插件清单(manifest)类型定义 —— **纯数据**，不夹带组件/代码对象。
 *
 * 核心原则：
 * - manifest 是可序列化的 JSON 数据（v2 远程加载需要）。
 * - 禁止夹带代码对象（component、sessionComponent、icon: Component）。
 * - 用 entry 字符串指向 main.tsx 同名 export。
 * - icon 是 registry 图标名字符串(联合类型,见 iconNames.ts),不是组件。
 *
 * 见 plugin-platform-design.md §2.2、plugin-dev-guide.md §12 红线。
 */

import type { Scope } from '../contract/scope';
import type { NotifyTrigger, PluginLifecycle, CapabilityOp } from '../contract/types';
import type { PluginIconName } from './iconNames';

// 契约出口:@core/contract re-export 本模块类型,iconNames 的联合经此透出
export type { PluginIconName };

// ─── 贡献点（contributes）─────────────────────────────────────────────────
// 插件通过 contributes 声明"我要贡献什么 UI"，平台按屏幕形态降级渲染。

/** 终端式会话（占一个 tab 的独立窗口） */
export interface SessionContribution {
  /** entry 名 → main.tsx 里同名 export */
  entry: string;
  /** 会话类型（区分不同会话源） */
  sessionType: string;
  /** 显示标签 */
  label: string;
  /** 图标名(registry 名,见 iconNames;拼错编译期红) */
  icon: PluginIconName;
  /** 该会话是否显示底部终端按键栏（默认 false，终端式插件是结构化输入） */
  keyBar?: boolean;
  /**
   * 单例会话(默认 false = 可多开,如 CC 对话)。true = 全局(本 server)只允许一份:
   * 「+」菜单点它时若已存在同类会话 → 不新建、直接切到已有 tab。适合工具型会话(如扫传接收,
   * 双开会话各开一路相机,帧被分抢、互相拖死)。菜单层拦截,store/契约不感知。
   */
  singleton?: boolean;
  /**
   * 会话固定启动目录(jupyter root_dir 相对,同 createTerminal cwd 口径;缺省 = 文件栏当前目录)。
   * 给「会话天生绑某个项目」的插件用 —— 如插件工坊必须跑在 ce-platform 仓(项目级 .claude/skills
   * 才会自动加载),用户当前浏览到哪不应影响它。纯数据加菜(semver minor,默认行为不变)。
   */
  cwd?: string;
  /**
   * IDE 会话标记(2026-09-24 分类定案):true = 任务列表归「IDE」组(负一屏独立分区),
   * false/缺省 = 「插件会话」组。IDE 会话=可执行/调试的文档工作区(jupyter notebook 代表)。
   */
  ide?: boolean;
  /**
   * 文件→会话桥(2026-09-25):文件树点开这些扩展名(无点小写,如 ['ipynb'])=
   * 建/切本类型会话并经 SessionProps.openPath 带入文件路径(而非开文件 tab)。
   * IDE 件的入口语义(jupyter-ide 接管 .ipynb);点开同一文件 = 切已有会话不叠 tab。
   */
  openExtensions?: string[];
  /**
   * 编码智能体会话声明(2026-09-28 工坊改造):true = 本会话是"在目录里干活的对话式
   * coding agent"(如 CC 对话)。工坊的开发入口(新建/优化后)按此声明列出可选智能体,
   * 用户挑一个在该插件目录开会话;平台不硬编码谁是 agent(声明即遵循)。
   */
  agent?: boolean;
  /**
   * 文件夹绑定会话(2026-09-27 用户定规):true = 本会话"在某个文件夹里干活"(如 CC 对话
   * 以该文件夹为项目、工坊绑工坊根)→ **同时**进文件树「创建」菜单(cwd = 当前文件夹,
   * 有固定 cwd 则用它;工坊的初始化拦截同款)。缺省 = 仅「+」菜单(任务页入口)。
   * 规律:两入口两语义 ——「+」建任务页,文件树底部建"绑这个文件夹的东西";每个插件遵循。
   * 声明了 openExtensions 的会话不适用(其创建 = 文件树新建文件,fileCreates 模板)。
   */
  folderBound?: boolean;
}

/** 槽位面板（侧栏/浮窗/底栏/全屏/omnibox/内联浮层） */
export interface SlotContribution {
  /** 槽位名：sidebar / floating / bottombar / fullscreen / omnibox / inline */
  slot: string;
  /** entry 名 → main.tsx 里同名 export */
  entry: string;
  /** 显示标签（菜单里用） */
  label?: string;
  /** 优先级（同槽位多插件排序） */
  priority?: number;
}

/** 命令/菜单项（平台原生渲染） */
export interface CommandContribution {
  /** entry 名 → main.tsx 里 register() 回调名（见 plugin-dev-guide.md §7.3） */
  entry: string;
  /** 命令 ID */
  id: string;
  /** 显示标签 */
  label: string;
  /** 图标名(registry 名;拼错编译期红) */
  icon?: PluginIconName;
  /** 键快捷键（可选） */
  keybinding?: string;
}

/** 设置项（平台原生渲染，JSON Schema） */
export interface SettingContribution {
  /** 设置项 ID */
  id: string;
  /** 显示标签 */
  label: string;
  /** schema（JSON Schema 或自定义） */
  schema: unknown;
  /** 默认值 */
  defaultValue?: unknown;
}

/**
 * 文件长按菜单贡献项（长按匹配文件 → 菜单多一个按钮 → 点击全屏渲染）。
 *
 * 平台在文件长按菜单（FileContextMenu）里，按文件扩展名匹配本贡献项，渲染一个插件按钮；
 * 点击 → 加载 entry 指向的全屏渲染组件（FileActionHost），传入目标文件 path。
 * core 不内置任何文件类型知识（不知 .json 是什么），「该渲染什么」全在插件。
 */
export interface FileActionContribution {
  /** 动作 ID（插件内唯一，如 'render'） */
  id: string;
  /** 显示标签（如「渲染」） */
  label: string;
  /** 图标名(registry 名,如 'search';拼错编译期红) */
  icon?: PluginIconName;
  /** entry 名 → main.tsx 里同名 export（点击后加载的全屏渲染组件） */
  entry: string;
  /** 匹配的扩展名（无点、小写，如 ['json','jsonc']）；目录不触发 */
  extensions: string[];
}

/**
 * 文件创建贡献点(fileCreates,2026-09-27 加菜):文件树「创建」菜单里出现
 * 「新建 XXX」项(如 jupyter-ide 的「Jupyter 笔记本」)。entry 指向 main.tsx 里
 * 同名导出的**模板工厂** \(新文件完整内容);core 只写文件+打开,
 * 「新文件该长什么样」全在插件(模板知识不进 core,同 fileViewers 哲学)。
 */
export interface FileCreateContribution {
  /** 动作 ID(插件内唯一) */
  id: string;
  /** entry 名 → main.tsx 同名 export:() => string(文件内容模板) */
  entry: string;
  /** 菜单项显示标签(如「Jupyter 笔记本」) */
  label: string;
  /** 新文件的扩展名(无点小写;拼名自动加点) */
  extension: string;
  /** 图标名(registry 名;拼错编译期红) */
  icon?: PluginIconName;
}

/** 通配扩展名：匹配一切扩展名（含无扩展名文件）。仅 fileViewers 兜底用（如 text-view）。 */
export const ANY_EXTENSION = '*';

/**
 * 文件查看器贡献项（fileViewers，查看型）。
 *
 * 与 fileActions（动作型：长按菜单手动触发，如 apk-installer「安装」）的边界：
 * - fileViewers = 「打开这个文件看」：平台在文件被点开时按扩展名【自动路由】到文件 tab
 *   （FileWorkspace）；entry 组件应为纯内容组件（无 chrome、无副作用）。
 * - fileActions = 「对这个文件做一件事」：仅出现在长按菜单，用户显式点击才触发。
 *   动作型贡献（安装/转换/…）绝不应声明 fileViewers——否则点开 .apk 会自动执行安装，语义错误。
 *
 * 多插件匹配同一文件时的裁决规则（core 不知扩展名语义，仅按数据规则查表）：
 * ① 精确扩展名匹配 优先于 ANY_EXTENSION 通配（兜底永远最后）；
 * ② 同档（都精确/都通配）比 priority，数值大者胜（缺省 0）；
 * ③ 仍平手 → 按传入 manifest 数组的声明顺序，先声明者胜（稳定、可预期）。
 */
export interface FileViewerContribution {
  /** 查看器 ID（插件内唯一，如 'view'） */
  id: string;
  /** entry 名 → main.tsx 里同名 export（纯内容组件，收 FileViewerProps） */
  entry: string;
  /** 匹配的扩展名（无点、小写，如 ['json','jsonc']）；含 ANY_EXTENSION = 兜底一切文件 */
  extensions: string[];
  /** 优先级（同档多插件时数值大者胜；缺省 0）。text-view 等兜底插件无需设——通配本就排在精确之后 */
  priority?: number;
}

// ─── 结构化被控机依赖(2026-09-24 分类+门禁定案)────────────────────────────
/**
 * 环境检测声明:ce 侧 preflight op 逐项验证,全过才放行安装(服务器级插件门禁)。
 * 声明式为主(binary/pip/path/port 覆盖 90% 场景,可审计、无任意代码执行);
 * script 档是逃生舱(工件自带检测脚本,受 exec 白名单闸门,工坊生成时需给理由)。
 */
export type Requirement =
  /** 被控机上要有某命令(which 验证),如 claude/python3 */
  | { check: 'binary'; name: string }
  /** Python 包已安装(pip show 验证;可带最低版本) */
  | { check: 'pip'; pkg: string; minVersion?: string }
  /** 文件/目录存在(glob) */
  | { check: 'path'; glob: string }
  /** 端口可达(如 jupyter 8888) */
  | { check: 'port'; host: string; port: number }
  /** 逃生舱:工件自带的检测命令(首 token 须在 permissions.execCommands 白名单;exit 0=过) */
  | { check: 'script'; command: string };

// ─── 插件清单（manifest）──────────────────────────────────────────────────
export interface PluginManifest {
  /** 插件唯一 ID（小写 kebab-case） */
  id: string;

  /** 版本（semver） */
  version: string;

  /** 显示名称 */
  name?: string;

  /** 描述 */
  description?: string;

  /** 作者（商店卡片用，可选） */
  author?: string;

  /** 开发日期（如 '2026-07'，详情弹窗显示） */
  date?: string;

  /** 使用说明（详情弹窗显示，怎么用这个插件） */
  usage?: string;

  // ─── 环境声明(工坊产物标配,2026-08-28)────────────────────────────────
  // 声明"在哪儿能跑、缺什么会怎样":运行时提示与「插件修复」都吃这三块。
  // 纯数据、全部可选;诚实披露是工坊 SKILL 的硬要求(开发环境/依赖/已知坑全透明)。
  /** 开发环境(如 'Windows 11 · Python 3.12';跨平台限制写进 knownIssues) */
  environment?: string;
  /**
   * 被控机依赖清单。兼容新旧两档(2026-09-24 加宽):
   * - 旧:字符串数组(如 ['python3','python3-pip:pandas'])——只展示,不参与 preflight 检测;
   * - 新:结构化 Requirement(如 {check:'binary',name:'claude'})——ce 侧 preflight 逐项检测。
   * 非空(无论新旧档)即派生 installLevel='server'(主机要额外装东西)。
   */
  requirements?: (string | Requirement)[];
  /** 已知坑与兼容边界(如 '依赖 win32 API,Linux 不可用'——有此条时对应功能必须显式降级提示) */
  knownIssues?: string[];

  // ─── 安装层级与平台(2026-09-24 分类+门禁定案)──────────────────────────
  /**
   * 安装层级(可选;缺省派生见 taxonomy.deriveInstallLevel):
   * - 'global':装一次,所有服务器通用(文件查看/扫传等,主机无需额外装东西)。
   * - 'server':服务器级,每台被控机显式安装(走商店+环境检测门禁),在装它的服务器上下文里才可用。
   * 显式声明覆盖派生(扫传=会话形态但无 host 依赖,显式 global)。
   */
  installLevel?: 'global' | 'server';
  /** 支持的被控机平台(缺省=全平台;工坊服务器级产物必填)。 */
  platform?: ('linux' | 'darwin' | 'win32')[];
  /** svg 图标源码字符串(工坊产物用;内置件继续用 lucide 图标名 icon)。纯数据。 */
  iconSvg?: string;

  /**
   * 图标名(registry 名,全集见 iconNames.ts;拼错编译期红 —— 2026-09-30 工坊反馈:
   * 裸 string 时代 book-open/package/file-text/file-code 四例静默走字母头像兜底)。
   * 商店件可用 iconSvg 自带图标(优先渲染);本字段是内置件主图标 + 工坊件兜底。
   */
  icon?: PluginIconName;

  /**
   * 声明用哪几组能力（op）。
   * - 'subscribe': 订阅流（terminalOutput/agentEvents/fileEvents）
   * - 'read': 一次性读取（listDir/readFile）
   * - 'write': 动作（stdin/resolveApproval/文件操作/终端操作）
   * - 'notify': 后台通知触发器
   */
  capabilities: CapabilityOp[];

  /**
   * 权限声明。
   * - network: 是否允许联网（默认 false，v1 仅官方插件可得）
   * - readPaths: glob 白名单（空 = 无读权限）
   * - writePaths: glob 白名单（空 = 无写权限）
   * - execCommands: exec 能力程序名白名单(空 = 无 exec 权限;首 token 精确匹配,如 ['claude','git'])
   * - native: 原生能力白名单('Plugin.method' 精确匹配,如 ['Filesystem.writeFile','ApkInstaller.open'])
   *   —— 外部件跑 iframe,原生桥只在宿主;调用经桥转发,按此清单闸门(2026-08-30 加菜,
   *   背景:工件打包的 @capacitor 是无原生注入的假桥,apk-installer 下载恒 0 的真机实证)。
   *
   * 敏感路径（.env/.ssh/密钥）ALWAYS-DENY 兜底，即使声明 '/**' 也读不了。
   * exec:ce 侧 execFile 无 shell(args 无法链式起别的程序),程序名白名单是唯一闸门。
   */
  permissions: {
    network?: boolean;
    readPaths?: string[];
    writePaths?: string[];
    execCommands?: string[];
    native?: string[];
  };

  /**
   * 作用域绑定。
   * - 'global': 全局，不绑特定服务器
   * - 'server': 绑一台服务器
   * - 'terminal': 绑一个终端
   */
  scope: Scope['kind'];

  /**
   * UI 贡献点（新规范：纯数据，entry 字符串指向组件）。
   * - sessions: 终端式会话（CC 对话、codex 对话）
   * - slots: 槽位面板（文件树、json/md 视图）
   * - commands: 命令/菜单项（刷新、新建文件）
   * - settings: 设置项（触发器开关、阈值）
   * - fileActions: 文件长按动作（动作型，手动触发）
   * - fileViewers: 文件查看器（查看型，点开文件按扩展名自动路由）
   */
  contributes?: {
    sessions?: SessionContribution[];
    slots?: SlotContribution[];
    commands?: CommandContribution[];
    settings?: SettingContribution[];
    fileActions?: FileActionContribution[];
    fileViewers?: FileViewerContribution[];
    fileCreates?: FileCreateContribution[];
  };

  /**
   * 后台通知触发器（平台评估，非代码）。
   * app 后台/熄屏时命中规则 → 弹系统通知。
   */
  triggers?: NotifyTrigger[];

  /**
   * 生命周期钩子（可选，字符串数组）。
   *
   * 声明后，平台在对应时机调用 main.tsx 里同名 export 函数。
   * - 'mount' / 'unmount': 进入/离开 scope
   * - 'visible' / 'hidden': tab 可见/切走（web visibility）
   * - 'foreground' / 'background': app 前台/后台（原生）
   *
   * @example
   * // manifest.ts
   * lifecycle: ['mount', 'unmount', 'visible']
   *
   * // main.tsx
   * export function mount(ctx: PluginContext) { console.log('mounted', ctx.scope); }
   * export function unmount(ctx: PluginContext) { console.log('unmounted'); }
   * export function visible(ctx: PluginContext) { console.log('visible'); }
   */
  lifecycle?: PluginLifecycle[];
}

// ─── 插件组件 props ───────────────────────────────────────────────────────
/** 插件组件收到的上下文（PluginProps / SessionProps 共用） */
export interface PluginContext {
  /** 当前作用域 */
  scope: Scope;

  /** 已授权的能力客户端（只放行 manifest 声明的能力） */
  rpc: import('../contract/rpc').RpcClient;

  /** 插件私有 KV 存储（localStorage 隔离） */
  storage: import('./storage').PluginStorage;

  /**
   * 健康上报(2026-09-30 契约化,工坊反馈§五:此前是 __CE_PLUGIN_STATUS__ 民间约定)。
   * 插件有降级/异常时调 report(['…']),宿主「插件修复」入口据此显隐;恢复即报空数组。
   * 可选:iframe 件由 bootstrap 提供(写本 realm __CE_PLUGIN_STATUS__,宿主同源读);
   * in-process 件宿主暂未注入(undefined),调用侧 ctx.health?.report(...) 容错。
   */
  health?: PluginHealth;
}

/** 健康上报通道(见 PluginContext.health)。 */
export interface PluginHealth {
  /** 上报当前健康问题清单(空数组 = 健康;非空 = 宿主显「插件修复」入口)。全量覆盖语义。 */
  report(issues: string[]): void;
}

/** 基础插件组件 props（slots/commands 用） */
export interface PluginProps {
  ctx: PluginContext;
}

/**
 * 终端式会话组件 props（sessions 用）。
 *
 * 平台在 `+` 菜单里建一个 type=plugin.contributes.sessions[].sessionType 的 session 后，
 * 按 session.type 查 manifest.contributes.sessions[].entry → 渲染对应组件（占一个 tab，fullscreen）。
 * ctx.scope 为 terminal 级(serverId + terminalId)，让插件订阅该 session 的 agentEvents / 写 stdin。
 */
export interface SessionProps extends PluginProps {
  /** 会话 ID */
  sessionId: string;

  /** 服务器 ID */
  serverId: string;

  /** 终端 ID（如果绑终端） */
  terminalId?: string;

  /** 会话工作目录(ce 侧补;CC agent 的 cwd / 终端 root_dir 相对)。空态等展示用。 */
  cwd?: string;

  /**
   * 建会话时带入的文件全路径(文件→会话桥,2026-09-25):文件树点开被 openExtensions
   * 接管的文件时由平台写入,插件应直开它(优先于自身 restore)。缺省 = 插件自选入口。
   */
  openPath?: string;

  // 以下三个函数 props **外部件(.ceplugin)可用**:iframe 会话桥由 bootstrap 按 SessionProps
  // 同形状重建(BRIDGE_VERSION 握手;老宿主给可读报错不白屏,见 iframe/bootstrap.tsx「P1 会话桥」)。
  // 历史注:v0.2.1 时代桥未建,调了当场 TypeError——今天类型面与运行时一致,无需绕开。
  /** 订阅该会话输出的函数（ce 提供的流;桥实现走 subOut 通道） */
  subscribeOutput?: (callback: (chunk: string) => void) => () => void;

  /** 持久化当前会话状态（同步 localStorage）。key 自动按 pluginId:serverId:terminalId 隔离，
   *  无需插件拼 key。用于「杀 app 重开历史还在」（微信级）。所有终端式插件通用。 */
  persist<T>(state: T): void;

  /** 取上次持久化的会话状态（同步，mount 时调一次喂 useReducer lazy init）。无记录 → null。 */
  restore<T>(): T | null;

  /**
   * 会话持久化 key（宿主 SessionHost 计算，形如 `ce_sess:<pluginId>:<serverId>:<terminalId>`）。
   * 插件**勿读勿存**——persist/restore 已封装好它；它单独出现是为了 iframe 会话桥：
   * 函数 props 过不了桥，宿主把这个 key 下发给 bootstrap，由它在 iframe 内重建同形状的
   * persist/restore（存取走宿主，两条 runner 的持久化落点一字不差）。可序列化，无害。
   */
  sessionKey?: string;
}

/**
 * 文件动作组件 props（fileActions 贡献点的 entry 组件收）。
 *
 * 平台在文件长按菜单点击插件按钮后，用 FileActionHost 全屏渲染 entry 组件，传入：
 * - ctx：server-scope 授权上下文（readFile 走它）
 * - path：长按的目标文件绝对路径
 * 顶栏（返回 + 文件名）由 FileActionHost 统一渲染，组件只管内容区。
 */
export interface FileActionProps extends PluginProps {
  /** 长按的目标文件绝对路径 */
  path: string;
}

/**
 * 文件查看器组件 props（fileViewers 贡献点的 entry 组件收）。
 *
 * 结构与 FileActionProps 等同（{ctx, path}）但独立命名——两个贡献点演化互不绑定
 * （如日后 fileViewers 需传 size/mimetype，不会波及 fileActions 契约）。
 * ctx 为 server-scope 授权上下文（readFile 走 ctx.rpc）。
 * 组件应是纯内容组件：自带 loading/error/内容三态，无外层定位/顶栏/返回钮
 * （宿主 PluginEntryFrame / 文件 tab 层负责 chrome）。
 */
export interface FileViewerProps extends PluginProps {
  /** 目标文件绝对路径（raw，不 encode） */
  path: string;
}

// ─── 类型辅助（导出给其他模块用）──────────────────────────────────────────────
export type { CapabilityOp, NotifyTrigger, PluginLifecycle };

// ─── 兼容导出(迁移完成后仅剩在用的)───────────────────────────────────────
/** 旧规范：PluginPermissions，现已内嵌到 PluginManifest.permissions（permissions.ts 在用） */
export type PluginPermissions = PluginManifest['permissions'];
