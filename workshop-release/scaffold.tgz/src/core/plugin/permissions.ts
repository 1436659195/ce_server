/**
 * 权限模型(review P2#5 统一):默认全部拒绝。
 *   ① manifest 声明 capabilities(只这些 op 可调)
 *   ② 路径白名单 readPaths/writePaths(glob,默认空=无路径权限)
 *   ③ ALWAYS-DENY 敏感清单(.env/.ssh/.aws/密钥):白名单也覆盖不了(defense-in-depth,
 *      防「伪装成渲染器的插件偷读 .env 外泄」)
 *   ④ network 默认拒(此处只做 cap 级判定;network gating 在 sandbox 边界)
 */
import { scopeContains } from '@/core/contract';
import type { Capability, CapabilityOp, Scope } from '@/core/contract';
import type { PluginManifest } from './manifest';

/** 旧规范：PluginPermissions，现已内嵌到 PluginManifest.permissions */
export type PluginPermissions = PluginManifest['permissions'];

export type AuthorizeDecision = { allowed: true } | { allowed: false; reason: string };

/** 敏感路径正则(凭据/密钥,永拒) */
const SENSITIVE_PATTERNS: RegExp[] = [
  /(^|\/)\.env(\..*)?$/i, // .env / .env.local ...
  /(^|\/)\.ssh\//i,
  /(^|\/)\.aws\//i,
  /(^|\/)\.gnupg\//i,
  /id_rsa/i,
  /\.pem$/i,
  /\.key$/i,
  /(^|\/)\.npmrc$/i,
  /(^|\/)\.git-credentials$/i,
];

export function isSensitivePath(path: string): boolean {
  return SENSITIVE_PATTERNS.some((re) => re.test(path));
}

/** glob → RegExp(** 跨路径、* 段内、? 单字符;其余转义) */
export function globToRegex(glob: string): RegExp {
  let re = '';
  for (let i = 0; i < glob.length; i++) {
    const c = glob[i];
    if (c === '*' && glob[i + 1] === '*') {
      re += '.*';
      i++;
    } else if (c === '*') {
      re += '[^/]*';
    } else if (c === '?') {
      re += '[^/]';
    } else if ('.+^$(){}|[]\\'.includes(c)) {
      re += '\\' + c;
    } else {
      re += c;
    }
  }
  return new RegExp('^' + re + '$');
}

export function globMatch(glob: string, path: string): boolean {
  return globToRegex(glob).test(path);
}

/** 从 cap 抽出带路径的检查项(read/write 文件类;read 非 path 型(如 agentSupportedModels)不涉及路径) */
function capPaths(cap: Capability): { path: string; mode: 'read' | 'write' }[] {
  if (cap.op === 'read') {
    if (cap.kind === 'listDir' || cap.kind === 'readFile' || cap.kind === 'readFileRange') {
      return [{ path: cap.path, mode: 'read' }];
    }
    return [];
  }
  if (cap.op === 'write') {
    if (cap.kind === 'createDir' || cap.kind === 'writeFile' || cap.kind === 'deleteFile') {
      return [{ path: cap.payload.path, mode: 'write' }];
    }
    if (cap.kind === 'rename') {
      return [
        { path: cap.payload.from, mode: 'write' },
        { path: cap.payload.to, mode: 'write' },
      ];
    }
  }
  return [];
}

/** 判定插件能否调该 cap(纯函数,易测) */
export function authorize(
  cap: Capability,
  permissions: PluginPermissions,
  declaredOps: readonly CapabilityOp[],
  mountScope: Scope,
): AuthorizeDecision {
  if (!scopeContains(mountScope, cap.scope)) {
    return { allowed: false, reason: 'cap scope 超出插件挂载 scope' };
  }
  if (!declaredOps.includes(cap.op)) {
    return { allowed: false, reason: `op ${cap.op} 未在 manifest 声明` };
  }
  // exec 门禁:程序名(命令首 token)必须在 manifest.execCommands 白名单。
  // ce 侧 execFile 无 shell → args 无法链式起别的程序,程序名白名单是唯一闸门(够安全)。
  if (cap.op === 'exec') {
    const allow = permissions.execCommands ?? [];
    if (allow.length === 0) {
      return { allowed: false, reason: 'exec 未授权(无 execCommands 白名单)' };
    }
    const first = cap.command.trim().split(/\s+/)[0] ?? '';
    const program = first.replace(/^["']|["']$/g, ''); // 去首尾引号
    if (!program) return { allowed: false, reason: 'exec: 空命令' };
    if (!allow.includes(program)) {
      return { allowed: false, reason: `exec 命令 "${program}" 不在 execCommands 白名单` };
    }
  }
  for (const { path, mode } of capPaths(cap)) {
    // 路径 normalize:Jupyter Contents 路径是 root_dir 相对(常无前导 /,如 "work/a.json"),
    // 补前导 / 让 glob('/**' 等绝对式)能匹配。reason 仍显原 path(用户看到的)。
    const normPath = path.startsWith('/') ? path : `/${path}`;
    if (isSensitivePath(normPath)) {
      return { allowed: false, reason: `敏感路径永拒: ${path}` };
    }
    const allowGlobs = mode === 'read' ? permissions.readPaths : permissions.writePaths;
    if (!allowGlobs || allowGlobs.length === 0) {
      return { allowed: false, reason: `${mode} 路径未授权` };
    }
    if (!allowGlobs.some((g) => globMatch(g, normPath))) {
      return { allowed: false, reason: `${mode} 路径不在白名单: ${path}` };
    }
  }
  return { allowed: true };
}
