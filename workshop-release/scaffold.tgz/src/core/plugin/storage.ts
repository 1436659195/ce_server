/**
 * 插件级 storage:隔离命名空间(避免各插件各写各的 localStorage、命名冲撞——
 * 终端 scrollback 吃过这亏)。重启留存。key-value,JSON 序列化。
 * 命名空间:localStorage[`plugin:${pluginId}:`] 下存一个 JSON 对象。
 */
export interface PluginStorage {
  get<T = unknown>(key: string): Promise<T | null>;
  set(key: string, value: unknown): Promise<void>;
  delete(key: string): Promise<void>;
  keys(): Promise<string[]>;
}

export function createPluginStorage(pluginId: string): PluginStorage {
  const storageKey = `plugin:${pluginId}:`;

  const readAll = (): Record<string, unknown> => {
    try {
      const raw = localStorage.getItem(storageKey);
      return raw ? (JSON.parse(raw) as Record<string, unknown>) : {};
    } catch {
      return {};
    }
  };
  const writeAll = (data: Record<string, unknown>): void => {
    try {
      localStorage.setItem(storageKey, JSON.stringify(data));
    } catch {
      // 忽略存储异常(隐私模式/配额)
    }
  };

  return {
    async get<T>(key: string): Promise<T | null> {
      const all = readAll();
      return (all[key] ?? null) as T | null;
    },
    async set(key: string, value: unknown): Promise<void> {
      const all = readAll();
      all[key] = value;
      writeAll(all);
    },
    async delete(key: string): Promise<void> {
      const all = readAll();
      delete all[key];
      writeAll(all);
    },
    async keys(): Promise<string[]> {
      return Object.keys(readAll());
    },
  };
}
