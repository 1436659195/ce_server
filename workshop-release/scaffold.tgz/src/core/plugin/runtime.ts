/**
 * 插件运行时:注册/挂载/卸载 + 授权 RpcClient 注入 + 崩溃熔断。
 * 挂载时为每个插件造一个 AuthorizedRpcClient(按 manifest 过滤)+ 隔离 storage。
 * 插件渲染抛错 → ErrorBoundary 调 reportError → 累计达阈值熔断(自动禁用 + 通知 UI)。
 */
import type {
  Capability,
  CapabilityResult,
  RpcClient,
  RpcStreamChunk,
  Scope,
} from '@/core/contract';
import { RpcBus, RpcErrorThrowable, scopeKindAllows } from '@/core/contract';
import type { PluginAssets, PluginManifest } from './manifest';
export type { PluginAssets };
import { authorize } from './permissions';
import { createPluginStorage, type PluginStorage } from './storage';
import { getExternalPlugin } from './externalPlugins';

export interface PluginContext {
  scope: Scope;
  rpc: RpcClient;
  storage: PluginStorage;
  assets?: PluginAssets;
}

/** base64 → 字节(附件内容解码)。 */
function decodeAsset(b64: string): Uint8Array {
  const bin = atob(b64);
  const out = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) out[i] = bin.charCodeAt(i);
  return out;
}

/** 插件附件访问(格式 2 资产包;内置件/无附件件 → 全 null)。blob URL 实例内缓存。 */
function createPluginAssets(pluginId: string): PluginAssets {
  const urlCache = new Map<string, string>();
  const find = (path: string): { content: string } | null =>
    getExternalPlugin(pluginId)?.assets?.find((a) => a.path === path) ?? null;
  return {
    url(path: string): string | null {
      const hit = urlCache.get(path);
      if (hit !== undefined) return hit;
      const a = find(path);
      if (!a) return null;
      const bytes = decodeAsset(a.content);
      const url = URL.createObjectURL(new Blob([bytes.buffer as ArrayBuffer]));
      urlCache.set(path, url);
      return url;
    },
    text(path: string): string | null {
      const a = find(path);
      return a ? new TextDecoder().decode(decodeAsset(a.content)) : null;
    },
    bytes(path: string): Uint8Array | null {
      const a = find(path);
      return a ? decodeAsset(a.content) : null;
    },
  };
}

const BREAKER_THRESHOLD = 5;

/** 经授权的 RpcClient:调前按 manifest 过滤(能力/路径/敏感)。 */
class AuthorizedRpcClient implements RpcClient {
  constructor(
    private readonly bus: RpcBus,
    private readonly manifest: PluginManifest,
    private readonly mountScope: Scope,
  ) {}

  private check(cap: Capability): void {
    const decision = authorize(
      cap,
      this.manifest.permissions,
      this.manifest.capabilities,
      this.mountScope,
    );
    if (!decision.allowed) {
      throw new RpcErrorThrowable('FORBIDDEN', decision.reason);
    }
  }

  invoke<C extends Capability>(cap: C): Promise<CapabilityResult<C>> {
    return this.run(() => this.bus.invoke(cap), cap);
  }

  subscribe<C extends Capability>(
    cap: C,
    sink: (chunk: RpcStreamChunk) => void,
  ): Promise<{ streamId: string; cancel: () => void }> {
    return this.run(() => this.bus.subscribe(cap, sink), cap);
  }

  /** check 抛错时转成 rejected promise(满足 RpcClient 契约:始终返回 Promise) */
  private async run<T>(fn: () => Promise<T>, cap: Capability): Promise<T> {
    this.check(cap);
    return fn();
  }
}

interface MountedPlugin {
  failures: number;
}

export class PluginRuntime {
  private readonly mounted = new Map<string, MountedPlugin>();
  private readonly disabled = new Set<string>();
  private readonly listeners = new Set<() => void>();

  constructor(private readonly bus: RpcBus) {}

  isDisabled(pluginId: string): boolean {
    return this.disabled.has(pluginId);
  }

  /** 订阅状态变化(熔断时 UI 重渲染) */
  subscribe(cb: () => void): () => void {
    this.listeners.add(cb);
    return () => {
      this.listeners.delete(cb);
    };
  }
  private emit(): void {
    this.listeners.forEach((l) => l());
  }

  /** 挂载插件,返回其上下文(注入授权 rpc + 隔离 storage) */
  mount(manifest: PluginManifest, scope: Scope): PluginContext {
    if (this.disabled.has(manifest.id)) {
      throw new Error(`插件 ${manifest.id} 已熔断禁用`);
    }
    if (!scopeKindAllows(manifest.scope, scope.kind)) {
      throw new Error(
        `mount scope(${scope.kind}) 比 manifest.scope(${manifest.scope}) 更宽,不允许`,
      );
    }
    this.mounted.set(manifest.id, { failures: 0 });
    return {
      scope,
      rpc: new AuthorizedRpcClient(this.bus, manifest, scope),
      storage: createPluginStorage(manifest.id),
      assets: createPluginAssets(manifest.id),
    };
  }

  unmount(pluginId: string): void {
    this.mounted.delete(pluginId);
  }

  /**
   * 为终端式插件的 session 组件 造一个 per-session ctx(不入 mounted 跟踪表 —— 跟踪表是
   * PluginHost 用的 server-scope 挂载状态;session 组件 的生命周期由 React mount/unmount 自然管)。
   *
   * scope=terminal 时:manifest.scope='server' 仍允许挂(server 包含 terminal);manifest.scope='global'
   * 也允许;只有 manifest.scope='terminal' 限制只能 terminal(本接口传 terminal 也满足)。其他越级
   * (declared='terminal' 但 mount='server')在 PluginHost 走 server 挂载时就拒了。
   *
   * 返回的 ctx.rpc 同样是 AuthorizedRpcClient(按 manifest.capabilities/permissions 授权),与 server
   * scope 挂载得到的 ctx 同款,仅 scope 不同(terminalId 进了 cap.scope,RelayProvider 据此路由 stdin)。
   */
  sessionCtx(manifest: PluginManifest, scope: Scope): PluginContext {
    if (!scopeKindAllows(manifest.scope, scope.kind)) {
      throw new Error(
        `sessionCtx scope(${scope.kind}) 比 manifest.scope(${manifest.scope}) 更宽,不允许`,
      );
    }
    return {
      scope,
      rpc: new AuthorizedRpcClient(this.bus, manifest, scope),
      storage: createPluginStorage(manifest.id),
      assets: createPluginAssets(manifest.id),
    };
  }

  /** 插件报错(ErrorBoundary 调);返回是否触发熔断 */
  reportError(pluginId: string): boolean {
    const p = this.mounted.get(pluginId);
    if (!p) return false;
    p.failures += 1;
    if (p.failures >= BREAKER_THRESHOLD && !this.disabled.has(pluginId)) {
      this.disabled.add(pluginId);
      this.emit();
      return true;
    }
    return false;
  }
}
