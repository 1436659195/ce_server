/**
 * 工件 bundle 专用的 @capacitor/core 桩(build-plugin.mjs alias 指入;勿在 app 源码 import)。
 *
 * 为什么:外部插件跑在 iframe,工件若打包真 @capacitor/core,iframe 里是一份没有原生
 * 注入的假桥(所有调用挂死,真机实证:apk-installer 下载进度恒 0)。桩把原生调用转发给
 * 宿主(window.__CE_CAP__,由 iframe bootstrap 注入 → postMessage 桥 → 宿主真桥执行),
 * 并按 manifest.permissions.native 白名单在宿主侧闸门放行。
 *
 * 边界:仅覆盖外部插件真实用到的面(registerPlugin 同步代理 / Capacitor.isNativePlatform)。
 * addListener 类事件 API 暂不支持(外部插件暂无此需求,需要时经桥协议加菜)。
 */
type CapFn = (plugin: string, method: string, args: unknown) => Promise<unknown>;

interface CapGlobal {
  __CE_CAP__?: CapFn;
}

export interface PluginListenerHandle {
  remove(): Promise<void>;
}

/** 与真 registerPlugin 同形:同步返回代理,方法调用转发宿主桥。 */
export function registerPlugin<T>(name: string): T {
  return new Proxy(
    {},
    {
      get:
        (_t, method: string) =>
        (args?: unknown): Promise<unknown> => {
          const cap = (globalThis as unknown as CapGlobal).__CE_CAP__;
          if (typeof cap !== 'function') {
            return Promise.reject(new Error('原生桥不可用(非 app 宿主环境)'));
          }
          return cap(name, method, args ?? {});
        },
    },
  ) as unknown as T;
}

export const Capacitor = {
  /** 宿主桥在 = app 原生环境(web/测试无 __CE_CAP__ → false,与真实现语义一致)。 */
  isNativePlatform: (): boolean =>
    typeof (globalThis as unknown as CapGlobal).__CE_CAP__ === 'function',
  getPlatform: (): string =>
    typeof (globalThis as unknown as CapGlobal).__CE_CAP__ === 'function' ? 'android' : 'web',
};

export interface PluginInvokeOptions {
  component?: string;
}
