/**
 * 工件 bundle 专用的 @capacitor/share 桩(build-plugin.mjs alias 指入;勿在 app 源码 import)。
 */
import { registerPlugin } from '@capacitor/core';

export interface SharePlugin {
  share(opts: { title?: string; text?: string; url?: string; dialogTitle?: string }): Promise<void>;
}

export const Share = registerPlugin<SharePlugin>('Share');
