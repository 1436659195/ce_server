/**
 * 工件 bundle 专用的 @capacitor/filesystem 桩(build-plugin.mjs alias 指入;勿在 app 源码 import)。
 * 经桩版 @capacitor/core 把调用转发宿主真 Filesystem;枚举值与原生侧约定字符串一致(透传)。
 */
import { registerPlugin } from '@capacitor/core';

export interface WriteFileResult {
  uri?: string;
}

export interface FilesystemPlugin {
  writeFile(opts: {
    path: string;
    data: string;
    directory?: Directory;
    recursive?: boolean;
    encoding?: string;
  }): Promise<WriteFileResult>;
  appendFile(opts: {
    path: string;
    data: string;
    directory?: Directory;
    encoding?: string;
  }): Promise<void>;
  readFile(opts: { path: string; directory?: Directory }): Promise<{ data: string }>;
  deleteFile(opts: { path: string; directory?: Directory }): Promise<void>;
}

export enum Directory {
  Documents = 'DOCUMENTS',
  Data = 'DATA',
  Cache = 'CACHE',
  External = 'EXTERNAL',
  ExternalStorage = 'EXTERNAL_STORAGE',
}

export enum Encoding {
  UTF8 = 'utf8',
  ASCII = 'ascii',
}

export const Filesystem = registerPlugin<FilesystemPlugin>('Filesystem');
