/**
 * iframe 插件运行时 —— 会被内联进每个插件 bundle（宿主打包脚本注入，插件源码零感知）。
 *
 * 加载后自举：建 ctx（rpc/storage 走 postMessage）→ 等宿主(父窗口)发 init（entry+props+scope）
 * → 渲染 entry 组件。
 *
 * 契约不变（关键）：ctx.rpc.invoke 的形状与 in-process 完全一致，只是"runner"从直调换成
 * postMessage。这就是 v1→v2 的"位置透明"（contract/rpc.ts 头注）：同一份契约、换个 runner。
 *
 * 桥协议（与宿主 IframeEntry.tsx 成对，所有消息带 __ce:true 标记）：
 *   插件→宿主  ready / invoke{id,cap} / storage{id,op,key,value} / pluginError{message}
 *             / sub{id,cap} / unsub{id}（流订阅,P1 第六坑开通）
 *             / cap{id,plugin,method,args}（原生能力转发,桩 @capacitor/* 经 __CE_CAP__ 递来,
 *               宿主按 manifest.permissions.native 闸门后走真桥）
 *             / sess{id,op:'load'|'save',key,value} / subOut{id} / unsubOut{id}
 *               （P1 会话桥:会话持久化直落宿主 localStorage、会话输出订阅）
 *   宿主→插件  init{entry,props,scope,bridge,kind?,sessionKey?} / res{id,ok,data|error}
 *             / storageRes{id,ok,data} / chunk{id,chan?,chunk}
 *               （chunk 缺省 = 能力流原样转发;chan:'out' = 会话输出文本块）
 *
 * P1 会话桥（2026-09）：session 型外部件与 in-process 跑同一份代码的关键。宿主的函数 props
 * （persist/restore/subscribeOutput）过不了 JSON 桥 → init 标 kind:'session' 并下发宿主算好的
 * sessionKey，本侧「预取持久化 → 重建同形状 shim → 再渲染」：
 *   - restore 同步签名保住（useReducer lazy init 要同步值）：预取发生在渲染前，restore 读缓存；
 *   - persist 同步签名 + 异步写背后（fire-and-forget;postMessage FIFO 保序）;
 *   - subscribeOutput 走 subOut 通道,取消走 unsubOut,与 SessionProps 形状一致;
 *   - 两条 runner 的持久化落点一字不差(同一个 ce_sess: 键,内置↔外部换装历史不丢)。
 * init.bridge = BRIDGE_VERSION 协议版本:新 bundle 落老宿主(回滚场景)时给可读报错不白屏。
 *
 * 消息鉴权用 e.source 窗口校验（谁在说话），不用 token：
 *   - 宿主 CSP 无 unsafe-inline，token 注不进 srcdoc；且 srcdoc 同源下 iframe 本就能读到 token，
 *     token 防不了 iframe、只防杂散窗口 —— e.source === parent 精确覆盖这个威胁。
 *   - 本侧只收 parent 的消息；宿主侧只收自己 contentWindow 的消息（见 IframeEntry.tsx）。
 *
 * 边界（诚实标注）：
 *   - 流订阅已通（sub/unsub/chunk,P1 第六坑由 tick 心跳需要倒逼开通）：订阅建立失败
 *     （FORBIDDEN/BAD_REQUEST 等）以错误 chunk 形状投给 sink,而不是 reject —— 插件与
 *     in-process 路径拿到同样形状,代码一份跑两端。
 *   - iframe 经 sandbox=allow-scripts 跑在 opaque origin：插件代码不能碰 localStorage（直接访问会抛
 *     SecurityError），KV 一律走 ctx.storage（桥到宿主 PluginStorage）。
 * 零 core 运行时依赖：只依赖 react / react-dom，bundle 自包含。
 */
import { Component, Fragment, createElement, useEffect } from 'react';
import { createRoot } from 'react-dom/client';
import type { ComponentType, ReactNode } from 'react';
import { Toaster } from '@/components/feedback/Toaster';

/**
 * 桥协议版本（宿主 ready→init 时下发）。语义 = 「宿主至少说到哪一版」：
 * v1 引入会话桥（init.kind/sessionKey + sess/subOut/unsubOut + chunk.chan）。
 * 新 bundle 对老宿主的探测在 mountEntry 里做 —— 可读报错，不 undefined 崩白屏。
 */
export const BRIDGE_VERSION = 1;

/** 空依赖 effect(挂载跑一次、卸载跑清理;LifecycleRunner 专用,绕过 exhaustive-deps 噪音)。 */
function useEffectOnce(effect: () => void | (() => void)): void {
  useEffect(effect, []);
}

/** 宿主 → 插件 的 init 载荷（entry 名 + 组件 props + scope + 协议版本 + 会话挂载信息）。 */
interface InitPayload {
  entry: string;
  props: Record<string, unknown>;
  scope: unknown;
  /** 宿主桥协议版本（BRIDGE_VERSION；老宿主不带 → 会话挂载可读报错）。 */
  bridge?: number;
  /** 'session' = 会话挂载（sessionKey 在场），bootstrap 重建函数 props shim。 */
  kind?: 'session';
  /** 会话持久化 key（宿主 SessionHost 计算；与 in-process 落点一字不差）。 */
  sessionKey?: string | null;
}

interface HostMessage {
  __ce?: boolean;
  t?: string;
  id?: number;
  ok?: boolean;
  data?: unknown;
  /** chunk 消息携带的流数据块(RpcStreamChunk 形状,原样透传给 sink);chan:'out' 时是文本串 */
  chunk?: unknown;
  /** chunk 分流:缺省 = 能力流;'out' = 会话输出(subOut 订的) */
  chan?: 'cap' | 'out';
  error?: { message?: string };
}

// ── postMessage 桥：pending 表 + 15s 超时（对齐宿主 RpcBus 契约超时）──────────
let seq = 0;
const pending = new Map<number, { resolve: (v: unknown) => void; reject: (e: Error) => void; timer: number }>();
/** 流订阅 sink 表(sub 的 id → sink;chunk 消息按 id demux) */
const streamSinks = new Map<number, (chunk: unknown) => void>();

function send(msg: Record<string, unknown>): void {
  // 在 iframe 里 → 发给父窗口；不在 frame 里（测试/兜底）→ 发给自己
  const win = window.parent && window.parent !== window ? window.parent : window;
  win.postMessage({ __ce: true, ...msg }, '*');
}

function call(msg: Record<string, unknown>, timeoutMs = 15_000): Promise<unknown> {
  return new Promise((resolve, reject) => {
    const id = ++seq;
    const timer = window.setTimeout(() => {
      pending.delete(id);
      reject(new Error(`TIMEOUT: 宿主 ${timeoutMs / 1000}s 无响应`));
    }, timeoutMs);
    pending.set(id, { resolve, reject, timer });
    send({ ...msg, id });
  });
}

/** 会话输出 sink 表(subOut 的 id → sink;chunk{chan:'out'} 按 id demux) */
const outSinks = new Map<number, (text: string) => void>();

/** 插件侧 rpc（bundle 内部用；导出是为测试可直接驱动，插件代码经 ctx.rpc 拿到同一对象）。 */
export const bridgeRpc = {
  /** 一次性调用（readFile / exec / …）。形状与契约 invoke 一致，wire 上是 postMessage。 */
  invoke: (cap: unknown): Promise<unknown> => call({ t: 'invoke', cap }),
  /**
   * 流订阅(P1 第六坑开通)。返回形状与 in-process RpcClient 一致(Promise<{streamId,cancel}>,
   * 立即落实)—— 插件代码一份跑两端。订阅建立失败(FORBIDDEN/BAD_REQUEST…)以**错误 chunk**
   * 投给 sink(而非 reject),与 in-process 的 sink 错误形状对齐。
   */
  subscribe: (cap: unknown, sink: (chunk: unknown) => void): Promise<{ streamId: string; cancel: () => void }> => {
    const id = ++seq;
    streamSinks.set(id, sink);
    send({ t: 'sub', id, cap });
    return Promise.resolve({
      streamId: `bridge-sub-${id}`,
      cancel: () => {
        if (streamSinks.delete(id)) send({ t: 'unsub', id });
      },
    });
  },
};

/** 插件 KV 经桥落宿主 localStorage（PluginStorage 同款语义，按 plugin id 隔离）。 */
export const bridgeStorage = {
  get: (k: string): Promise<unknown> => call({ t: 'storage', op: 'get', key: k }),
  set: (k: string, v: unknown): Promise<void> => call({ t: 'storage', op: 'set', key: k, value: v }).then(() => undefined),
  delete: (k: string): Promise<void> => call({ t: 'storage', op: 'delete', key: k }).then(() => undefined),
  keys: (): Promise<string[]> => call({ t: 'storage', op: 'keys' }).then((v) => (Array.isArray(v) ? (v as string[]) : [])),
};

/**
 * 原生能力桥（cap-stubs 桩 @capacitor/* 经 globalThis.__CE_CAP__ 取用；宿主 IframeEntry
 * t:'cap' 处理，按 manifest.permissions.native 白名单闸门后走宿主真桥）。
 * 三件套的第三块：v26 造了桩与宿主闸，但本注入漏了 —— 桩找不到 __CE_CAP__，外部件
 * 原生调用全程不可用（真机复报：apk-installer 下载进度恒 0；2026-09-19 补齐）。
 * 长超时 120s：Filesystem 段写（~512KB base64）低端机偏慢，15s 契约超时对文件 IO 太紧。
 */
export const capBridge = (plugin: string, method: string, args: unknown): Promise<unknown> =>
  call({ t: 'cap', plugin, method, args }, 120_000);

/**
 * 会话持久化桥（P1 会话桥半边）：宿主 IframeEntry t:'sess' 处理，直落宿主 localStorage。
 * 键由宿主算好随 init 下发（SessionHost 的 sessionKey），与 in-process 落点一字不差；
 * 宿主校验 `ce_sess:<本插件id>:` 前缀，iframe 越权碰别的会话直接 FORBIDDEN。
 * 供测试直驱；生产路径经 mountEntry 造的 persist/restore shim 间接使用。
 */
export const bridgeSessionStore = {
  load: (key: string): Promise<string | null> => call({ t: 'sess', op: 'load', key }) as Promise<string | null>,
  save: (key: string, value: string): Promise<void> =>
    call({ t: 'sess', op: 'save', key, value }).then(() => undefined),
};

/**
 * 会话输出订阅 shim（SessionProps.subscribeOutput 的桥实现）：subOut 外发、
 * chunk{chan:'out'} 按 id demux 回 sink、cancel 发 unsubOut。同步返回取消函数，
 * 与 in-process 的 subscribeOutput 形状一致 —— 插件代码一份跑两端。
 */
export function bridgeSubscribeOutput(cb: (text: string) => void): () => void {
  const id = ++seq;
  outSinks.set(id, cb);
  send({ t: 'subOut', id });
  return () => {
    if (outSinks.delete(id)) send({ t: 'unsubOut', id });
  };
}

/**
 * 插件 bundle 自举入口：由打包脚本生成的 entry 调用（`ceIframeBoot(pluginMainExports)`）。
 * 挂好 postMessage 监听 → 告诉宿主"我好了" → 收到 init 后渲染。
 */
export function ceIframeBoot(plugin: Record<string, unknown>): void {
  // 原生能力桥注入（cap-stubs 桩经 globalThis 取用）。boot 时挂：组件渲染发生在 init
  // 消息之后，时序必晚于这里；不挂模块顶层，避免 import 即污染测试全局。
  (globalThis as unknown as { __CE_CAP__?: typeof capBridge }).__CE_CAP__ = capBridge;
  const onMessage = (e: MessageEvent): void => {
    // 只认父窗口（不在 frame 里时 parent===window，测试环境）
    if (window.parent !== window && e.source !== window.parent) return;
    const m = e.data as HostMessage | null;
    if (!m || m.__ce !== true) return; // 非 CE 桥消息
    if (m.t === 'res' || m.t === 'storageRes') {
      if (typeof m.id !== 'number') return;
      const p = pending.get(m.id);
      if (!p) return;
      pending.delete(m.id);
      window.clearTimeout(p.timer);
      if (m.ok) p.resolve(m.data);
      else p.reject(new Error(m.error?.message ?? 'RPC 失败'));
    } else if (m.t === 'chunk') {
      // 数据块按 id demux;chan 分流:缺省 = 能力流(sub 订的),'out' = 会话输出(subOut 订的)
      if (typeof m.id !== 'number') return;
      if (m.chan === 'out') outSinks.get(m.id)?.(typeof m.chunk === 'string' ? m.chunk : '');
      else streamSinks.get(m.id)?.(m.chunk);
    } else if (m.t === 'init') {
      // 会话挂载要先走 storage 桥预取(restore 是同步签名)→ 异步化;失败在 mountEntry 内收口
      void mountEntry(plugin, m as unknown as InitPayload);
    }
  };
  window.addEventListener('message', onMessage);
  bootListener = onMessage;
  // 运行期错误转发宿主（宿主 console + 熔断统计；加载期错误浏览器自会报）
  window.addEventListener('error', (ev) => {
    send({ t: 'pluginError', message: ev.message });
  });
  // 就绪信号（宿主收到后回发 init）
  send({ t: 'ready' });
}

/** 当前 boot 的消息监听(生产一 realm 一 boot;测试跨用例堆叠时用它复位)。 */
let bootListener: ((e: MessageEvent) => void) | null = null;

/** 测试用:摘监听 + 清桥上挂着的 sink/pending(用例间隔离;生产 realm 销毁自然清)。 */
export function _resetBootForTest(): void {
  if (bootListener) window.removeEventListener('message', bootListener);
  bootListener = null;
  pending.clear();
  streamSinks.clear();
  outSinks.clear();
}

/** #root 容器（srcdoc 里已有;测试/兜底手工补）。 */
function ensureRoot(): HTMLElement {
  let el = document.getElementById('root');
  if (!el) {
    el = document.createElement('div');
    el.id = 'root';
    document.body.appendChild(el);
  }
  return el;
}

/**
 * 健康上报(ctx.health,2026-09-30 契约化):写本 realm 的 __CE_PLUGIN_STATUS__,
 * 宿主「插件修复」入口同源读取 —— 落点与旧民间约定(v0.3.2)一字不差,老插件零迁移;
 * 不走 postMessage 桥(宿主无需参与),新 bundle 落老宿主照样可用。
 */
function pluginHealth(): { report: (issues: string[]) => void } {
  return {
    report: (issues: string[]): void => {
      (window as unknown as { __CE_PLUGIN_STATUS__?: { issues: string[] } }).__CE_PLUGIN_STATUS__ = {
        issues: [...issues],
      };
    },
  };
}

/** 错误 → 可读文本（与宿主 IframeEntry 同款语义;RpcError 文本透传）。 */
function errText(e: unknown): string {
  return e instanceof Error ? e.message : String(e);
}

/**
 * 渲染错误边界：插件组件崩 → 可读文案 + pluginError 上报宿主 console。
 * 没有它，iframe 里渲染崩溃 = React 卸载 #root = 纯白屏（用户侧零信息）——
 * claude code 外部件白屏事故（restore 未过桥被调）的直接教训。
 */
class EntryBoundary extends Component<{ children: ReactNode }, { error: Error | null }> {
  override state = { error: null as Error | null };

  static getDerivedStateFromError(error: Error): { error: Error } {
    return { error };
  }

  override componentDidCatch(error: Error): void {
    send({ t: 'pluginError', message: `entry 渲染崩溃: ${error.message}` });
  }

  override render(): ReactNode {
    if (this.state.error) {
      return createElement(
        'div',
        {
          className: 'flex h-full items-center justify-center px-6 text-center text-[length:var(--fs-sm)] text-danger',
        },
        `插件界面崩溃（已拦截，不影响宿主）：${this.state.error.message}`,
      );
    }
    return this.props.children;
  }
}

/** 装载失败/不兼容 → 可读文案占满 iframe（治「白屏 = 零信息」）。 */
function renderError(message: string): void {
  createRoot(ensureRoot()).render(
    createElement(
      'div',
      {
        className: 'flex h-full items-center justify-center px-6 text-center text-[length:var(--fs-sm)] text-danger',
      },
      message,
    ),
  );
}

/**
 * init 的装载入口（异步：会话挂载要先经 storage 桥预取持久化）。
 * 会话桥（P1）：按 SessionProps 同形状重建 persist/restore/subscribeOutput ——
 * 位置透明与 ctx.rpc 同一哲学，插件代码一份跑两端；契约签名一个不改。
 */
async function mountEntry(plugin: Record<string, unknown>, init: InitPayload): Promise<void> {
  try {
    const props = { ...init.props };

    if (init.kind === 'session') {
      // 新 bundle 落老宿主(回滚场景):老宿主不认识 kind/bridge → 无法重建函数 props,
      // 继续跑必然是当年的白屏事故 → 显式可读报错。
      if (init.bridge !== BRIDGE_VERSION || typeof init.sessionKey !== 'string') {
        renderError('宿主过旧：不支持会话型外部插件（会话桥缺失），请升级 app 后重装本插件。');
        return;
      }
      const key = init.sessionKey;
      // 预取:restore 是同步签名(useReducer lazy init 要同步值),先取回缓存再渲染;
      // 取不到/解析不动按空会话继续(与 in-process「无记录 → null」语义一致)。
      let cached: unknown = null;
      try {
        const raw = await bridgeSessionStore.load(key);
        if (raw) {
          try {
            cached = JSON.parse(raw) as unknown;
          } catch {
            cached = null;
          }
        }
      } catch (err) {
        send({ t: 'pluginError', message: `会话状态预取失败（按空会话继续）: ${errText(err)}` });
      }
      props.persist = (state: unknown): void => {
        cached = state;
        // 异步写背后:postMessage FIFO 保序;失败上报不炸插件
        void bridgeSessionStore
          .save(key, JSON.stringify(state ?? null))
          .catch((err: unknown) => send({ t: 'pluginError', message: `会话状态保存失败: ${errText(err)}` }));
      };
      props.restore = (): unknown => cached;
      props.subscribeOutput = bridgeSubscribeOutput;
    }

    renderEntry(plugin, { ...init, props });
  } catch (err) {
    // 装载期错误（缺 entry 组件等）：以前直接 throw 进消息监听 = 无声白屏，现在可见。
    renderError(err instanceof Error ? `插件装载失败：${err.message}` : `插件装载失败：${String(err)}`);
  }
}

/** 收到 init → 用 createElement 渲染 entry 组件（不能当普通函数调，否则 hooks 在 React 外跑必崩）。 */
function renderEntry(plugin: Record<string, unknown>, init: InitPayload): void {
  // Q9 合成 entry:L2 后台件的生命周期 runner(宿主渲染隐藏 iframe 指到这)。
  if (init.entry === '__lifecycle__') {
    renderLifecycleRunner(plugin, init);
    return;
  }

  const Comp = plugin[init.entry] as ComponentType<Record<string, unknown>> | undefined;
  if (typeof Comp !== 'function') throw new Error(`插件缺少 entry 组件: ${init.entry}`);
  const ctx = { scope: init.scope, rpc: bridgeRpc, storage: bridgeStorage, health: pluginHealth() };
  createRoot(ensureRoot()).render(
    createElement(
      Fragment,
      null,
      createElement(EntryBoundary, null, createElement(Comp, { ...init.props, ctx })),
      // toast 宿主:外部件 showToast 推的是本 realm 的模块级 store,以前没人渲染 = 纯静默失效;
      // 渲进 iframe(toast 落在插件区域内,视觉正确)。
      createElement(Toaster),
    ),
  );
}

/**
 * Q9:渲染 L2 后台件的生命周期 runner(`__lifecycle__` 合成 entry 的落地)。
 *
 * 渲染 null 组件,effect 里调 bundle 的 mount(ctx) / cleanup 调 unmount() —— React 生命周期
 * 即插件生命周期。生产路径的真正"停止"是宿主卸 iframe(整个 JS realm 销毁,计时器必死,
 * 结构性防泄漏,cleanup 不依赖运行);返回卸载句柄是给测试验证 cleanup 语义 + 将来宿主
 * 想优雅停(先回调再销毁)留的口。
 */
export function renderLifecycleRunner(
  plugin: Record<string, unknown>,
  init: InitPayload,
): { unmount: () => void } {
  const ctx = { scope: init.scope, rpc: bridgeRpc, storage: bridgeStorage, health: pluginHealth() };
  const mount = plugin.mount as ((ctx: unknown) => void) | undefined;
  const unmount = plugin.unmount as (() => void) | undefined;
  const Runner = (): null => {
    useEffectOnce(() => {
      if (typeof mount === 'function') mount(ctx);
      return () => {
        if (typeof unmount === 'function') unmount();
      };
    });
    return null;
  };
  const root = createRoot(ensureRoot());
  root.render(createElement(Runner));
  return { unmount: () => root.unmount() };
}
