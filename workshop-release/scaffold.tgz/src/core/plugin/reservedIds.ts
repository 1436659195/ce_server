/**
 * APK 自带插件保留 id —— 真源模块(零依赖,iconNames.ts 同款先例)。
 *
 * 2026-10-11 用户定案:工坊与 APK 自带件隔离 —— 自带件只许启用/禁用,工坊产物
 * 撞这些 id 一律拒装(validateExternalManifest 的 official 渠道除外:官方升级/开启
 * 装的就是它们本身)。工坊「新建插件」命名撞集同样拒绝。
 *
 * 10 个 = 系统五件 ∪ 可见内置两件 ∪ 商店两件(cc 对话 2026-10-11 迁工坊,工坊可改)。改这份清单 = 改「什么是 APK 自带件」,
 * 与 builtins.ts(BUILTIN_PLUGINS/SYSTEM_PLUGIN_IDS)和 storeCatalog 三处保持一致。
 */
export const RESERVED_PLUGIN_IDS: readonly string[] = [
  // 系统五件(面板隐藏 + 常开)
  'text-view',
  'json-view',
  'md-view',
  'plugin-installer',
  'workshop',
  // 可见内置两件(qr-receive 2026-10-11 迁工坊,不再是 APK 自带件)
  'py-editor',
  'html-view',
  // 商店件(apk-installer 全局默认装;jupyter-ide 全局默认装 —— 2026-10-11 用户定案)
  'apk-installer',
  'jupyter-ide',
];

export const RESERVED_PLUGIN_ID_SET: ReadonlySet<string> = new Set(RESERVED_PLUGIN_IDS);
