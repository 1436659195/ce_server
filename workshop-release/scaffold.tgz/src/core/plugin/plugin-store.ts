/**
 * 插件注册表持久层 —— 2026-10-11 起 localStorage → IndexedDB。
 *
 * 为什么迁:服务器级大插件(带 wasm 资产,单件 MB 级)会把 localStorage 的 5MB 配额撑爆;
 * IndexedDB 配额按可用磁盘比例(通常数百 MB 起),支撑「插件 = APP」的形态。
 *
 * 驱动双轨:
 *  - 真环境:IndexedDB(store external,keyPath id)。jsdom/测试环境无 IDB 或显式
 *    CE_FORCE_MEMORY_STORE=1 时走内存驱动 —— 逻辑测试用内存驱动覆盖,IDB 驱动真机验证
 *    (与 Capacitor 原生 API 同款测试策略)。
 */

const DB_NAME = 'ce_plugins';
const DB_VERSION = 1;
const STORE = 'external';

interface StoreDriver {
  load(): Promise<Record<string, unknown>>;
  persist(entries: Record<string, unknown>): Promise<void>;
}

/** 内存驱动(测试/兜底;进程内 Map,无跨会话持久)。 */
let memoryDriver: StoreDriver | null = null;
function getMemoryDriver(): StoreDriver {
  memoryDriver ??= (() => {
    const mem: Record<string, unknown> = {};
    return {
      load: async () => mem,
      persist: async (entries) => {
        for (const k of Object.keys(mem)) delete mem[k];
        Object.assign(mem, entries);
      },
    };
  })();
  return memoryDriver;
}

function idbDriver(): StoreDriver {
  return {
    load: () =>
      openPluginDb().then(
        (db) =>
          new Promise<Record<string, unknown>>((resolve, reject) => {
            const tx = db.transaction(STORE, 'readonly');
            const req = tx.objectStore(STORE).getAll();
            req.onsuccess = () => {
              const out: Record<string, unknown> = {};
              for (const v of req.result as Array<Record<string, unknown>>) {
                if (v && typeof v.id === 'string') out[v.id] = v;
              }
              resolve(out);
            };
            req.onerror = () => reject(req.error ?? new Error('IndexedDB 读取失败'));
          }),
      ),
    persist: (entries) =>
      openPluginDb().then(
        (db) =>
          new Promise<void>((resolve, reject) => {
            const tx = db.transaction(STORE, 'readwrite');
            tx.objectStore(STORE).clear();
            for (const v of Object.values(entries)) tx.objectStore(STORE).put(v);
            tx.oncomplete = () => resolve();
            tx.onerror = () => reject(tx.error ?? new Error('IndexedDB 写入失败'));
            tx.onabort = () => reject(tx.error ?? new Error('IndexedDB 写入被中止'));
          }),
      ),
  };
}

/** 选驱动:显式强制内存(IDB 不可用/测试)→ 内存;否则 IndexedDB。每次调用现判。 */
function driver(): StoreDriver {
  if (typeof indexedDB === 'undefined' || process.env.CE_FORCE_MEMORY_STORE === '1') {
    return getMemoryDriver();
  }
  return idbDriver();
}

/** 打开(不存在则建库建 store)。 */
export function openPluginDb(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    const req = indexedDB.open(DB_NAME, DB_VERSION);
    req.onupgradeneeded = () => {
      const db = req.result;
      if (!db.objectStoreNames.contains(STORE)) db.createObjectStore(STORE, { keyPath: 'id' });
    };
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error ?? new Error('IndexedDB 打开失败'));
  });
}

/** 读全量条目(keyPath 自带 id;读侧再按 manifest.id 校验一次)。 */
export function loadStoredEntries(): Promise<Record<string, unknown>> {
  return driver().load();
}

/** 全量覆盖写(清空后逐条 put;条目量小、写频低,全量最简单且不留已删残条)。 */
export function persistEntries(entries: Record<string, unknown>): Promise<void> {
  return driver().persist(entries);
}
