/**
 * 插件图标名真源(零依赖,2026-09-30 工坊反馈升级)。
 *
 * 为什么独立成模块:manifest 的 icon 字段此前是裸 `string`,拼错名编译不报、
 * 装上手机才发现渲染成字母头像(sys-monitor 一线报告 §六-2;仓内现形四例:
 * book-open/package/file-text/file-code 都在静默兜底)。升成字面量联合后,
 * 拼错 = 编译期红。真源必须零依赖:manifest.ts(core/plugin)与 PluginIcons.tsx
 * (components/shared)两侧都 import 它,谁也不牵谁的实现。
 *
 * 名单与 PluginIcons.tsx 的 REGISTRY 一一对应(REGISTRY 以本联合收型,
 * 缺一个图标 / 多一个名字都编译红,天然防漂移);SKILL 的 icons 段由
 * skill-sync 测试对账。新增图标:① 这里加名 → ② REGISTRY 加组件 →
 * ③ SKILL icons 段补一行(测试会提醒)。
 */

/** 声明序(按语义分组,与 PluginIcons.REGISTRY 同序;真源)。 */
const ORDERED = [
  'puzzle', // 通用插件(拿不准时)
  'claude', // CC 相关
  'md', // Markdown 相关
  'json', // JSON 相关
  'apk', // 安装包相关
  'scan', // 扫码/扫传
  // A2 通用图标(工坊生成件常见原型)
  'bell', // 提醒/通知
  'gauge', // 监控面板/仪表
  'activity', // 资源监控/脉搏
  'cpu', // CPU/硬件
  'calendar', // 日历/日程
  'clock', // 时间/倒计时
  'terminal', // 终端/命令行
  'file', // 文件/文档
  'folder', // 目录/文件管理
  'database', // 数据库/存储
  'wifi', // 网络/连通性
  'message', // 聊天/消息
  'shield', // 安全/防护
  'search', // 搜索/查找
  'download', // 下载/获取
  'image', // 图片/相册
  'music', // 音乐/音频
  'zap', // 快速/自动化
  'chart', // 图表/统计
  'globe', // 网站/全球
  'bot', // AI/机器人
  'camera', // 拍摄/截屏
] as const;

/** 图标名字面量联合(manifest 各 icon 字段的类型;拼错编译期红)。 */
export type PluginIconName = (typeof ORDERED)[number];

/** 名字全集(字母序;SKILL icons 段对账用,与旧 Object.keys().sort() 行为一致)。 */
export const PLUGIN_ICON_NAMES: readonly PluginIconName[] = [...ORDERED].sort();
