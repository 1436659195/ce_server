/**
 * 外部插件注册表(P0 传送带 · 注册表半边)。
 *
 * 与 useInstalledPlugins(内置插件的 id 列表)的分工:
 * - 内置:manifest 焊在包里,store 只存 id;DEFAULT 强制回补(卸载=禁用语义)。
 * - 外部:manifest + bundle 文本**整个住在本 store**(localStorage),卸载即真删。
 *   L1 纯触发器插件(D4)bundle 为 null —— manifest 的 triggers 是平台评估的
 *   纯数据,零代码零 bundle,不走传送带。
 *
 * Q1(内外同 id):**外部胜** —— mergeManifests 过滤被遮蔽的内置,卸载外部自动
 * 回退内置。这也是"插件替换更新"机制的雏形(P2 分享场景再收紧为显式覆盖)。
 *
 * 模块级 external store + useSyncExternalStore(对齐 useInstalledPlugins 模式)。
 */
import { useSyncExternalStore } from 'react';
import type { PluginManifest } from './manifest';
import type { CapabilityOp } from '../contract/types';
import { RESERVED_PLUGIN_ID_SET } from './reservedIds';
import { loadStoredEntries, persistEntries } from './plugin-store';

const STORAGE_KEY = 'ce_external_plugins';

/** 外部插件条目(整包持久化)。2026-10-11 起持久层 = IndexedDB(原 localStorage;带 wasm
 *  资产的大插件一件就是 MB 级,5MB 配额撑不住),内存 map 仍是同步读的真源,写后异步落库。 */
export interface ExternalPluginEntry {
  manifest: PluginManifest;
  /** 插件 bundle JS 文本;L1 纯触发器 = null。 */
  bundle: string | null;
  /** bundle 的 sha256(安装时校验过的基线,十六进制 64 位);L1 = null。 */
  sha256: string | null;
  /** 工件附件(format 2 资产包,2026-10-11 加;wasm/模型/图片等,base64)。format 1 工件无。 */
  assets?: { path: string; content: string }[];
  /**
   * 源码包(可选,2026-08-28):开发者随工件携带 → 视为**授权他人修复/改造**本插件;
   * 不带 = 纯使用,无「插件修复」入口。文件较小(十几 KB 级),修复时整包交工坊。
   */
  source?: { path: string; content: string }[];
  /**
   * 服务器级外部件的归属服务器集(2026-09-24 安装层级定案):缺省/空 = 全局件
   * (装一次全服务器可用);服务器级 = 仅在列表内 server 上下文可用。**并集语义**:
   * 多台服务器装同一插件(id 同)不互相覆盖 —— 再装一台 = 并入列表(卸载 = 整条删,
   * per-server 卸载走 installState/后续加)。可用性判定单点收敛在 App 的
   * installedPlugins memo(内置全局 ∪ 外部全局 ∪ 外部本机 ∪ installState 本机)。
   */
  serverIds?: string[];
  installedAt: number;
}

export type AddResult = { ok: true } | { ok: false; errors: string[] };

/** 契约现有 op 全集(与 contract/types.ts 的 Capability union 对齐;漂移由 CI 对账兜底)。 */
const VALID_OPS: readonly CapabilityOp[] = ['subscribe', 'read', 'write', 'notify', 'exec', 'request'];
const VALID_SCOPES: readonly PluginManifest['scope'][] = ['global', 'server', 'terminal'];
const VALID_TRIGGERS: readonly string[] = ['agentResult', 'approvalPending', 'idle', 'regex'];
const VALID_INSTALL_LEVELS: readonly string[] = ['global', 'server'];
const VALID_PLATFORMS: readonly string[] = ['linux', 'darwin', 'win32'];
const ID_RE = /^[a-z0-9]+(-[a-z0-9]+)*$/;
/** 单插件附件总量上限(base64 解码后字节)。IndexedDB 下不再挤 localStorage 配额,防失控即可。 */
export const MAX_ASSET_BYTES = 32 * 1024 * 1024;
const VERSION_RE = /^\d+\.\d+\.\d+/;

/** 单条 requirements 条目合法(旧字符串=展示档 或 结构化各档字段齐全)。 */
function isValidRequirementItem(x: unknown): boolean {
  if (typeof x === 'string') return true; // 旧档:只展示不检测
  if (!isPlainObject(x)) return false;
  switch (x.check) {
    case 'binary':
      return typeof x.name === 'string';
    case 'pip':
      return typeof x.pkg === 'string' && (x.minVersion === undefined || typeof x.minVersion === 'string');
    case 'path':
      return typeof x.glob === 'string';
    case 'port':
      return typeof x.host === 'string' && typeof x.port === 'number';
    case 'script':
      return typeof x.command === 'string';
    default:
      return false;
  }
}

// ─── 校验(A1.3:manifest 必须是纯数据、形状合法)────────────────────────────

/** 深扫值域:出现 function/symbol 即拒(manifest 禁夹带代码对象)。 */
function containsCodeObject(v: unknown, depth = 0): boolean {
  if (depth > 8) return false;
  if (typeof v === 'function' || typeof v === 'symbol') return true;
  if (Array.isArray(v)) return v.some((x) => containsCodeObject(x, depth + 1));
  if (v && typeof v === 'object') {
    return Object.values(v as Record<string, unknown>).some((x) => containsCodeObject(x, depth + 1));
  }
  return false;
}

function isPlainObject(v: unknown): v is Record<string, unknown> {
  return typeof v === 'object' && v !== null && !Array.isArray(v);
}

/**
 * 校验外部 manifest(纯函数)。
 * @param input 任意来源(安装工件的 JSON 解析结果)
 * @param hasBundle 是否随附 bundle(L1 无代码时 false)
 */
export function validateExternalManifest(
  input: unknown,
  hasBundle: boolean,
  official = false,
): { ok: true; manifest: PluginManifest } | { ok: false; errors: string[] } {
  const errors: string[] = [];
  if (!isPlainObject(input)) return { ok: false, errors: ['manifest 必须是对象'] };
  if (containsCodeObject(input)) errors.push('manifest 禁止夹带函数/代码对象(纯数据)');

  const m = input as unknown as PluginManifest;
  // permissions 缺省归一为空对象(= 无任何权限,最小特权)。类型上必填,但外部工件可能省略;
  // 不归一会让消费方(如面板详情读 permissions.readPaths)在 undefined 上崩。
  if (m.permissions === undefined) m.permissions = {};
  if (typeof m.id !== 'string' || !ID_RE.test(m.id)) errors.push(`id 非法(需 kebab-case): ${String(m.id)}`);
  // APK 自带插件保留 id(2026-10-11 扩集:系统五件 + 可见内置三件 + 商店三件):
  // 外部工件(工坊产物)撞上即拒 —— 自带件只许启用/禁用,不许被工坊产物覆盖(Q1 外部胜)。
  if (!official && typeof m.id === 'string' && RESERVED_PLUGIN_ID_SET.has(m.id)) {
    errors.push(`id 是 APK 自带插件保留名,不许覆盖: ${m.id}`);
  }
  if (typeof m.version !== 'string' || !VERSION_RE.test(m.version)) errors.push(`version 非法(需 x.y.z…): ${String(m.version)}`);
  if (!Array.isArray(m.capabilities) || m.capabilities.some((op) => !VALID_OPS.includes(op))) {
    errors.push(`capabilities 非法(只允许 ${VALID_OPS.join('/')})`);
  }
  if (!VALID_SCOPES.includes(m.scope)) errors.push(`scope 非法: ${String(m.scope)}`);

  const p = (m.permissions ?? {}) as Record<string, unknown>;
  if (p.network !== undefined && typeof p.network !== 'boolean') errors.push('permissions.network 必须是布尔');
  for (const key of ['readPaths', 'writePaths', 'execCommands', 'native'] as const) {
    const list = p[key];
    if (list !== undefined && (!Array.isArray(list) || list.some((x) => typeof x !== 'string'))) {
      errors.push(`permissions.${key} 必须是字符串数组`);
    }
  }

  // 安装层级/平台/依赖声明(2026-09-24 分类+门禁定案):形状校验,语义派生在 taxonomy。
  if (m.installLevel !== undefined && !VALID_INSTALL_LEVELS.includes(m.installLevel)) {
    errors.push(`installLevel 非法(只允许 ${VALID_INSTALL_LEVELS.join('/')}): ${String(m.installLevel)}`);
  }
  if (
    m.platform !== undefined &&
    (!Array.isArray(m.platform) || m.platform.length === 0 || m.platform.some((x) => !VALID_PLATFORMS.includes(x)))
  ) {
    errors.push(`platform 非法(非空数组,只允许 ${VALID_PLATFORMS.join('/')}): ${JSON.stringify(m.platform)}`);
  }
  if (m.iconSvg !== undefined && typeof m.iconSvg !== 'string') {
    errors.push('iconSvg 必须是字符串(svg 源码,纯数据)');
  }
  if (m.requirements !== undefined && (!Array.isArray(m.requirements) || !m.requirements.every(isValidRequirementItem))) {
    errors.push('requirements 非法(条目 = 字符串(展示档) 或 {check:binary|pip|path|port|script,…}(检测档))');
  }

  const contributes = m.contributes as Record<string, unknown> | undefined;
  if (contributes !== undefined) {
    if (!isPlainObject(contributes)) {
      errors.push('contributes 必须是对象');
    } else {
      for (const [key, val] of Object.entries(contributes)) {
        if (val === undefined) continue;
        if (!Array.isArray(val) || val.some((x) => !isPlainObject(x))) {
          errors.push(`contributes.${key} 必须是对象数组`);
          continue;
        }
        // entry 禁下划线开头:下划线前缀是平台保留名(如 Q9 的 __lifecycle__ 隐藏 runner),
        // 插件 entry 撞上会与虚拟模块的合成 entry 冲突。
        for (const item of val as { entry?: unknown }[]) {
          if (typeof item.entry === 'string' && item.entry.startsWith('_')) {
            errors.push(`contributes.${key} entry 禁止下划线开头(平台保留): ${item.entry}`);
          }
        }
      }
    }
  }
  if (m.triggers !== undefined) {
    if (!Array.isArray(m.triggers) || !m.triggers.every((t) => isPlainObject(t) && typeof t.id === 'string' && VALID_TRIGGERS.includes(String(t.when)))) {
      errors.push(`triggers 非法(when 只允许 ${VALID_TRIGGERS.join('/')})`);
    }
  }

  // L2/L3(有 UI 贡献点或生命周期钩子)必须有代码可跑
  const needsCode = Boolean(
    (contributes && Object.values(contributes).some((v) => Array.isArray(v) && v.length > 0)) ||
      (Array.isArray(m.lifecycle) && m.lifecycle.length > 0),
  );
  if (needsCode && !hasBundle) errors.push('该插件声明了 UI 贡献点/生命周期,必须携带 bundle');

  return errors.length ? { ok: false, errors } : { ok: true, manifest: m };
}

// ─── store(模块级 + useSyncExternalStore)───────────────────────────────────

/** 旧 localStorage 注册表 → 条目表(迁移源;损坏整体弃)。 */
function loadLegacyEntries(): Record<string, ExternalPluginEntry> {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return {};
    const parsed = JSON.parse(raw) as unknown;
    if (!isPlainObject(parsed)) return {};
    const out: Record<string, ExternalPluginEntry> = {};
    for (const [id, val] of Object.entries(parsed)) {
      if (!isPlainObject(val)) continue;
      const entry = val as unknown as ExternalPluginEntry;
      if (!entry?.manifest || entry.manifest.id !== id) continue; // 条目与 id 对不上 → 弃
      out[id] = entry;
    }
    return out;
  } catch {
    return {}; // 损坏数据整体弃(下次安装重写)
  }
}

let entries: Record<string, ExternalPluginEntry> = {};
const listeners = new Set<() => void>();
// manifest 快照缓存声明前置(boot 装载完会失效重建;原声明在文件尾部,boot 引用不到)
let manifestsCache: PluginManifest[] | null = null;

/** 持久化写队列(测试 flush 用:await 后 IDB 已落定)。 */
let persistQueue: Promise<void> = Promise.resolve();

function persist(): void {
  persistQueue = boot
    .then(() => persistEntries(entries))
    .catch(() => undefined);
}

/** 启动:①旧 localStorage 注册表迁移进 IndexedDB(有则迁完即删旧键);②从 IndexedDB
 *  载入条目。仅当期间无人写入(entries 仍空)才落内存,防晚到覆盖。 */
const boot: Promise<void> = (async () => {
  try {
    const legacy = loadLegacyEntries();
    if (Object.keys(legacy).length > 0) {
      await persistEntries(legacy);
      localStorage.removeItem(STORAGE_KEY);
    }
    const stored = await loadStoredEntries();
    const valid: Record<string, ExternalPluginEntry> = {};
    for (const [id, val] of Object.entries(stored)) {
      const e = val as unknown as ExternalPluginEntry;
      if (e?.manifest && e.manifest.id === id) valid[id] = e; // 条目与 id 对不上 → 弃
    }
    if (Object.keys(entries).length === 0 && Object.keys(valid).length > 0) {
      entries = valid;
      manifestsCache = null;
      emit();
    }
  } catch {
    /* IndexedDB 不可用(隐私模式/测试无实现)→ 仅内存,写路径静默 */
  }
})();

function emit(): void {
  listeners.forEach((l) => l());
}

/**
 * 安装外部插件:先校验 manifest(纯数据 + 形状),再落库(Q1:同 id 直接覆盖 = 替换更新)。
 * bundle 空串归一为 null(L1 工件 bundle='';注册表语义统一为 string|null,null=无代码)。
 * serverId 可选:服务器级件的归属(缺省 = 全局件),见 ExternalPluginEntry.serverId。
 */
export function addExternalPlugin(
  manifest: unknown,
  bundle: string | null,
  sha256: string | null,
  source?: { path: string; content: string }[],
  serverId?: string,
  assets?: { path: string; content: string }[],
  official?: boolean,
): AddResult {
  const bundleNorm = bundle === '' ? null : bundle;
  const v = validateExternalManifest(manifest, bundleNorm !== null, official);
  if (!v.ok) return v;
  // 附件总量上限(IndexedDB 配额宽裕,防失控即可):base64 长度 × 3/4 ≈ 解码字节
  if (assets && assets.length > 0) {
    const total = assets.reduce((n, a) => n + a.content.length, 0) * 0.75;
    if (total > MAX_ASSET_BYTES) {
      return { ok: false, errors: [`附件总量超限(${Math.round(total / 1048576)}MB,上限 ${MAX_ASSET_BYTES / 1048576}MB)`] };
    }
  }
  // 同 id 已有服务器级归属 + 本次又指定 serverId → 并集(多机装同一件不覆盖;
  // 替换更新语义不受影响:manifest/bundle 照常整体覆盖)
  const prev = entries[v.manifest.id];
  let serverIds: string[] | undefined;
  if (serverId) {
    const merged = new Set([...(prev?.serverIds ?? []), serverId]);
    serverIds = [...merged];
  } else if (prev?.serverIds?.length) {
    serverIds = prev.serverIds; // 无 serverId 的重装(替换更新)保留原归属
  }
  entries = {
    ...entries,
    [v.manifest.id]: {
      manifest: v.manifest,
      bundle: bundleNorm,
      sha256,
      ...(assets && assets.length > 0 ? { assets } : {}),
      ...(source && source.length > 0 ? { source } : {}),
      ...(serverIds && serverIds.length > 0 ? { serverIds } : {}),
      installedAt: Date.now(),
    },
  };
  manifestsCache = null;
  persist();
  emit();
  return { ok: true };
}

/** 卸载(真删;同 id 内置版自动"回现"由 mergeManifests 语义保证)。幂等。 */
export function uninstallExternalPlugin(id: string): void {
  if (!(id in entries)) return;
  const next = { ...entries };
  delete next[id];
  entries = next;
  manifestsCache = null;
  persist();
  emit();
}

export function getExternalPlugin(id: string): ExternalPluginEntry | null {
  return entries[id] ?? null;
}

/** 外部 manifest 快照(供非 React 侧:loader 分流 / App 启用集合并;两次增删之间引用稳定)。 */
export function externalManifests(): PluginManifest[] {
  if (!manifestsCache) manifestsCache = Object.values(entries).map((e) => e.manifest);
  return manifestsCache;
}

/**
 * 内外合并(Q1 外部胜):内置被同 id 外部遮蔽,外部在列表尾部(声明顺序稳定的裁决规则不受影响
 * —— 内置间的相对顺序不变)。
 */
export function mergeManifests(builtin: PluginManifest[], external: PluginManifest[]): PluginManifest[] {
  const extIds = new Set(external.map((m) => m.id));
  return [...builtin.filter((m) => !extIds.has(m.id)), ...external];
}

function getSnapshot(): PluginManifest[] {
  return externalManifests();
}

/** 测试用:订阅增删变化(生产面走 useExternalPlugins;测试断言订阅语义用)。 */
export function _subscribeExternalPluginsForTest(cb: () => void): () => void {
  return subscribe(cb);
}

function subscribe(cb: () => void): () => void {
  listeners.add(cb);
  return () => {
    listeners.delete(cb);
  };
}

/** React 订阅(App 聚合 manifests 用;外部插件增删后自动重渲染)。 */
export function useExternalPlugins(): PluginManifest[] {
  return useSyncExternalStore(subscribe, getSnapshot, getSnapshot);
}

/** 测试用:清空 + 清持久(内存即清;IDB 由 persist 空表覆盖)。 */
export function _resetExternalForTest(): void {
  entries = {};
  manifestsCache = null;
  persist();
  emit();
}

/** 测试用:等持久化写队列落定(此后裸读 IndexedDB 能看到最新状态)。 */
export function _flushPersistForTest(): Promise<void> {
  return persistQueue;
}
