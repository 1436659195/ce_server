/**
 * 能力 provider 实现端契约。位置透明:in-process 直实现;
 * 未来 sandbox runner 把 invoke/subscribe 换成 postMessage 透传,接口不变。
 */
import type { Capability, RpcReq, RpcStreamChunk } from './types';

export interface RpcErrorShape {
  code: string;
  message: string;
}

export type InvokeResult = { ok: true; data: unknown } | { ok: false; error: RpcErrorShape };

export type SubscribeResult =
  | { ok: true; streamId: string; cancel: () => void }
  | { ok: false; error: RpcErrorShape };

export interface CapabilityProvider {
  /** 是否处理该能力(bus 按 cap 分派时遍历 provider 问 match) */
  match(cap: Capability): boolean;
  /** 一次性请求(read/write/notify) */
  invoke(req: RpcReq): Promise<InvokeResult>;
  /** 流式订阅(subscribe) */
  subscribe(req: RpcReq, sink: (chunk: RpcStreamChunk) => void): Promise<SubscribeResult>;
}
