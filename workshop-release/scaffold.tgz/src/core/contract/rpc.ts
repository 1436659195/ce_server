/**
 * RpcBus:能力契约运行时。注册 provider、按 cap.op/stream/kind 路由、reqId 配对、
 * 15s 超时(防 provider 卡死挂起)、流式 cancel。
 * in-process 直调 = 同步 Promise;未来 sandbox 换 postMessage runner,本类接口不变。
 */
import type { Capability, CapabilityResult, RpcReq, RpcStreamChunk } from './types';
import type { CapabilityProvider } from './provider';

const DEFAULT_TIMEOUT_MS = 15_000;

/** 抛出的 RPC 错误(带 code,调用方按 code 判) */
export class RpcErrorThrowable extends Error {
  readonly code: string;
  constructor(code: string, message: string) {
    super(message);
    this.name = 'RpcError';
    this.code = code;
  }
}

/** 插件侧拿到的 RPC 客户端(经运行时授权包装:只放行 manifest 声明的能力 —— M04) */
export interface RpcClient {
  invoke<C extends Capability>(cap: C): Promise<CapabilityResult<C>>;
  subscribe<C extends Capability>(
    cap: C,
    sink: (chunk: RpcStreamChunk) => void,
  ): Promise<{ streamId: string; cancel: () => void }>;
}

let _seq = 0;
function genId(prefix: string): string {
  return `${prefix}_${++_seq}`;
}

function withTimeout<T>(p: Promise<T>, ms: number, label: string): Promise<T> {
  return new Promise<T>((resolve, reject) => {
    const timer = setTimeout(
      () => reject(new RpcErrorThrowable('TIMEOUT', `${label} 超时 ${ms}ms`)),
      ms,
    );
    p.then(
      (v) => {
        clearTimeout(timer);
        resolve(v);
      },
      (e) => {
        clearTimeout(timer);
        reject(e);
      },
    );
  });
}

export class RpcBus implements RpcClient {
  private providers: CapabilityProvider[] = [];
  private readonly timeoutMs: number;

  constructor(opts: { timeoutMs?: number } = {}) {
    this.timeoutMs = opts.timeoutMs ?? DEFAULT_TIMEOUT_MS;
  }

  /** 注册 provider,返回注销函数 */
  register(provider: CapabilityProvider): () => void {
    this.providers.push(provider);
    return () => {
      this.providers = this.providers.filter((p) => p !== provider);
    };
  }

  private findProvider(cap: Capability): CapabilityProvider | undefined {
    return this.providers.find((p) => p.match(cap));
  }

  async invoke<C extends Capability>(cap: C): Promise<CapabilityResult<C>> {
    if (cap.op === 'subscribe') {
      throw new RpcErrorThrowable('WRONG_DISPATCH', 'subscribe 能力请用 subscribe()');
    }
    const provider = this.findProvider(cap);
    if (!provider) {
      throw new RpcErrorThrowable('NO_PROVIDER', `无 provider 处理 op=${cap.op}`);
    }
    const req: RpcReq = { id: genId('req'), cap };
    const label = `op=${cap.op}${'kind' in cap ? ` kind=${cap.kind}` : ''}`;
    const result = await withTimeout(provider.invoke(req), this.timeoutMs, label);
    if (!result.ok) {
      throw new RpcErrorThrowable(result.error.code, result.error.message);
    }
    return result.data as CapabilityResult<C>;
  }

  async subscribe<C extends Capability>(
    cap: C,
    sink: (chunk: RpcStreamChunk) => void,
  ): Promise<{ streamId: string; cancel: () => void }> {
    if (cap.op !== 'subscribe') {
      throw new RpcErrorThrowable('WRONG_DISPATCH', '非 subscribe 能力请用 invoke()');
    }
    const provider = this.findProvider(cap);
    if (!provider) {
      throw new RpcErrorThrowable('NO_PROVIDER', `无 provider 处理 stream=${cap.stream}`);
    }
    const req: RpcReq = { id: genId('sub'), cap };
    const result = await provider.subscribe(req, sink);
    if (!result.ok) {
      throw new RpcErrorThrowable(result.error.code, result.error.message);
    }
    return { streamId: result.streamId, cancel: result.cancel };
  }
}
