/**
 * 能力契约(改不了的层)。transport 无关、位置透明:
 * v1 in-process 直调(同步 Promise);未来第三方插件进 sandbox(iframe + postMessage),
 * 同一份契约、换个 runner,架构一行不改(这就是 VS Code 从 in-process 演进到 webview 沙箱没推倒的原因)。
 *
 * 三组能力 + 生命周期(baseline §7.1)。输入 payload 按 kind 强类型(review fix,不做 unknown);
 * 响应数据按 cap 映射(CapabilityResult<C>),消费端类型安全。
 */
import type { ContentEntry, FileReadResult } from '@/types/file';
import type { Scope } from './scope';

export type PluginLifecycle = 'mount' | 'unmount' | 'visible' | 'hidden' | 'foreground' | 'background';

// ─── 订阅(read 流)──────────────────────────────────────────────────
export type SubscribeCap =
  | { op: 'subscribe'; stream: 'terminalOutput'; scope: Scope; terminalId: string }
  | { op: 'subscribe'; stream: 'agentEvents'; scope: Scope }
  | { op: 'subscribe'; stream: 'fileEvents'; scope: Scope }
  | {
      /**
       * 内核事件流(jupyter-ide 插件,2026-09-25 加菜):ce KernelManager 推来的
       * {kind:'kernelOutput'|'kernelStatus'|'kernelReply', kernelId, msgId, ...} ——
       * 按 kernelId demux(同 ce 多内核不串话)。additive minor。
       */
      op: 'subscribe';
      stream: 'kernelEvents';
      kernelId: string;
      scope: Scope;
    }
  | {
      /**
       * 定时心跳(P1 第六坑加菜,2026-08-27):熄屏时 WebView 的 JS 定时器会被冻结,
       * setTimeout/setInterval 轮询全停 —— 心跳源在原生层(前台服务进程),到点叫醒 JS。
       * 通用能力(非某插件专属):一切"每隔 N 秒醒一次看看"的插件共用。
       */
      op: 'subscribe';
      stream: 'tick';
      /** 心跳间隔,毫秒;宿主钳制到 [10_000, 3_600_000](10 秒 ~ 1 小时) */
      intervalMs: number;
      scope: Scope;
    };

// ─── 读取(一次性 request-response)──────────────────────────────────
export type ReadCap =
  | { op: 'read'; kind: 'listDir'; path: string; scope: Scope }
  | { op: 'read'; kind: 'readFile'; path: string; scope: Scope }
  | {
      op: 'read';
      kind: 'readFileRange';
      path: string;
      /** 起始字节偏移(含) */
      offset: number;
      /** 本次请求字节数(调用方按段切,建议 3 的倍数以对齐 base64) */
      length: number;
      scope: Scope;
    }
  | {
      /**
       * 列 agent 会话可用模型(2026-10-01 加菜;/model 动态列表,SDK supportedModels)。
       * terminalId = agent sid(cc-*);会话未起 / 老 ce → 报错,插件回落静态快捷档。
       */
      op: 'read';
      kind: 'agentSupportedModels';
      terminalId: string;
      scope: Scope;
    };

/** 会话可用模型一行(/model 列表项;agentSupportedModels 返回)。 */
export interface AgentModelInfo {
  /** 模型标识(setModel 用;别名或完整 id) */
  value: string;
  /** 展示名 */
  displayName: string;
  /** 能力描述 */
  description: string;
  /** 别名解析到的 canonical id(e.g. 'sonnet' → 'claude-sonnet-5') */
  resolvedModel?: string;
  /** 该模型是否支持 effort 档(2026-10-01 晚加) */
  supportsEffort?: boolean;
  /** 该模型支持的 effort 档位(思考菜单按它动态渲染;2026-10-01 晚加) */
  supportedEffortLevels?: string[];
}

/**
 * readFileRange 返回的一段:base64 字节 + 元数据。
 * 调用方循环 readFileRange 推进 offset、按 eof 停 —— 二进制安全、内存只持单段
 * (readFile 的 base64 全量 content 会撑爆 / 被太多Large 拦,大文件必须走分段)。
 * 与 ce-server bridge readFileRange 返回形状一致(单一来源)。
 */
export interface FileRangeChunk {
  /** 本段字节(base64) */
  data: string;
  /** 文件总字节数(首段即给出,无需探测) */
  totalSize: number;
  /** 本段实际字节数(末段是余数) */
  bytes: number;
  /** 是否已读到文件尾 */
  eof: boolean;
}

// ─── 写入(每 kind 一个强类型 payload;review fix)──────────────────
export type WriteCap =
  | { op: 'write'; kind: 'stdin'; scope: Scope; terminalId: string; payload: string }
  | {
      op: 'write';
      kind: 'resolveApproval';
      scope: Scope;
      payload: {
        reqId: string;
        decision: 'allow' | 'deny';
        trustWindowSec?: number;
        /**
         * AskUserQuestion 的答案(2026-10-01 加菜,Happy 同道):
         * 键 = 问题原文,值 = 选中项 label 逗号连接 —— ce 合并进工具入参(updatedInput)回灌,
         * 答案作为工具结果返回给模型(TUI 同构)。老 ce 忽略该字段(照常 allow,答案走 stdin 兜底)。
         */
        answers?: Record<string, string>;
      };
    }
  | { op: 'write'; kind: 'createDir'; scope: Scope; payload: { path: string } }
  | {
      op: 'write';
      kind: 'writeFile';
      scope: Scope;
      payload: { path: string; content: string; format?: 'text' | 'base64' };
    }
  | { op: 'write'; kind: 'rename'; scope: Scope; payload: { from: string; to: string } }
  | { op: 'write'; kind: 'deleteFile'; scope: Scope; payload: { path: string } }
  | { op: 'write'; kind: 'createTerminal'; scope: Scope; payload: { cwd?: string } }
  | { op: 'write'; kind: 'deleteTerminal'; scope: Scope; payload: { terminalId: string } }
  | {
      /**
       * 中断 agent 当前回合(agent-runner 驱动的会话,2026-10-01 加菜):
       * ce 端调 SDK query.interrupt(),工具/生成停在下个边界,回合以 failed 收尾。
       * terminalId = agent sid(cc-*);老 ce 不认识该 op → RPC 报错,插件自行降级(按钮显不可用)。
       * 对称先例:kernelInterrupt(kernelId)。additive minor。
       */
      op: 'write';
      kind: 'agentInterrupt';
      scope: Scope;
      payload: { terminalId: string };
    }
  | {
      /**
       * 切 agent 权限模式(2026-10-01 加菜,Happy 同道):default 手动审批 / acceptEdits 自动改文件 /
       * bypassPermissions 全自动免审批 / plan 只规划。ce 记模式(canUseTool 本地兜底)+
       * setPermissionMode 推给 SDK(CC 自身停止询问)。additive minor。
       */
      op: 'write';
      kind: 'agentSetMode';
      scope: Scope;
      payload: { terminalId: string; mode: 'default' | 'acceptEdits' | 'bypassPermissions' | 'plan' };
    }
  | {
      /**
       * 切 agent 思考强度(2026-10-01 晚升级:官方 effort 档,applyFlagSettings 热切;
       * 替换 v75 的 setMaxThinkingTokens 预算代餐):
       * off 关思考 / low·medium·high·xhigh 官方 effort 档 / max(部分模型) /
       * default 清除覆盖回模型默认。不支持的档由 CC 静默降级。additive minor。
       */
      op: 'write';
      kind: 'agentThinking';
      scope: Scope;
      payload: { terminalId: string; level: 'off' | 'default' | 'low' | 'medium' | 'high' | 'xhigh' | 'max' };
    }
  | {
      /**
       * 切 agent 模型(2026-10-01 加菜):SDK setModel 运行时热切(streaming 模式专属);
       * model 空 = 恢复底座默认。模型效果取决于底座/网关支持。additive minor。
       */
      op: 'write';
      kind: 'agentSetModel';
      scope: Scope;
      payload: { terminalId: string; model?: string };
    }
  // ─── kernel 四连(jupyter-ide 插件,2026-09-25 加菜):ce 侧 KernelManager。
  //     输出不走 invoke 返回 —— 订阅 kernelEvents 流异步收。additive minor。
  | { op: 'write'; kind: 'kernelStart'; scope: Scope; payload: { notebookPath?: string } }
  | { op: 'write'; kind: 'kernelExecute'; scope: Scope; payload: { kernelId: string; code: string } }
  | { op: 'write'; kind: 'kernelInterrupt'; scope: Scope; payload: { kernelId: string } }
  | { op: 'write'; kind: 'kernelShutdown'; scope: Scope; payload: { kernelId: string } };

// ─── 通知(声明后台触发器;平台评估 + 推送,见 baseline §7.1)────────
// when 加菜只扩 union(不删 / 不重排,加非破坏性 minor):
//   - agentResult     agent「完成」事件(Stop / SubagentStop)→ 弹「CC 完成」。
//   - approvalPending PreToolUse 到达、用户却在后台 → 弹「CC 待审批」。
//   - idle            N 秒无 agentEvent(长任务卡住?)。
//   - regex           事件 JSON regex 命中(自由兜底,留扩展点)。
export interface NotifyTrigger {
  id: string;
  when: 'agentResult' | 'approvalPending' | 'idle' | 'regex';
  idleSec?: number; // when='idle'
  /** when='regex'(事件 JSON 命中)/ when='agentResult'(可选,叠加匹配 PostToolUse 工具)。 */
  pattern?: string;
  title: string;
  body: string;
  deepLink?: string;
}
// 两形状二选一(trigger 注册 / immediate 立即弹),语义正交:
//   trigger   声明式:登记触发器,平台评估 agentEvents 命中才弹(插件的"闹钟")。
//   immediate 即时弹(L2 加菜,2026-08-27 Q10):插件代码算出结论当场弹(如 CPU 超阈值)——
//             前台 toast / 后台系统通知的分派与评估器同款。速率窗(全局 60s/20 条)防失控循环 spam。
export type NotifyImmediate = { title: string; body?: string };
export type NotifyCap =
  | { op: 'notify'; trigger: NotifyTrigger; scope: Scope }
  | { op: 'notify'; immediate: NotifyImmediate; scope: Scope };

// ─── 执行(通用哑管道:在被控机跑一条命令,无 shell、捕输出)────────────
// 门禁(permissions.ts):manifest.permissions.execCommands 程序名白名单(首 token 精确匹配);
// ce 侧用 execFile 无 shell(防注入 —— args 无法链式起别的程序)。v1 官方可信插件放行;
// v2 第三方沙箱插件默认无 execCommands → 拒。command = "program arg1 arg2"(空格分,支持引号)。
export type ExecCap = { op: 'exec'; command: string; cwd?: string; scope: Scope };

// ─── 请求(插件把数据交给底座,请平台跑一条通用流程)────────────────────
// 与 write 的区别:write 是插件对某台服务器的数据动作(路径走 manifest 白名单);
// request 是「请平台帮我做一件事」—— 插件只交数据,流程与目标选择(服务器/目录)全在
// 平台 UI,插件零感知。加菜只扩 kind union(不删/不重排,加非破坏性 minor)。
//   - saveToServer:把手里的文件交给底座「选服务器 → 选目录 → 上传」保存流(与系统
//     分享/「用其他应用打开」进来的保存流同一条)。scope 恒 global —— 插件不挑服务器,
//     用户在流程里挑。content = base64(建议 ≤ 几 MB;更大的文件应走 write+readFileRange 组合)。
export type RequestCap = {
  op: 'request';
  kind: 'saveToServer';
  scope: Scope;
  payload: { name: string; content: string; mime?: string };
};

export type Capability = SubscribeCap | ReadCap | WriteCap | NotifyCap | ExecCap | RequestCap;
export type CapabilityOp = Capability['op'];

// ─── RPC envelope(postMessage 形状;v1 in-process 不序列化,但形状已就位)─
export interface RpcReq {
  id: string;
  cap: Capability;
}

/** 流式数据块(subscribe 的 sink 收这个) */
export type RpcStreamChunk =
  | { streamId: string; data: unknown }
  | { streamId: string; error: { code: string; message: string } }
  | { streamId: string; done: true };

// ─── 响应类型映射(消费端类型安全)──────────────────────────────────
export type CapabilityResult<C extends Capability> =
  C extends { op: 'read'; kind: 'listDir' }
    ? ContentEntry[]
    : C extends { op: 'read'; kind: 'readFile' }
      ? FileReadResult
      : C extends { op: 'read'; kind: 'readFileRange' }
        ? FileRangeChunk
        : C extends { op: 'read'; kind: 'agentSupportedModels' }
          ? AgentModelInfo[]
          : C extends { op: 'write'; kind: 'kernelStart' }
          ? { kernelId: string; attached: boolean }
          : C extends { op: 'write'; kind: 'kernelExecute' }
            ? { msgId: string }
            : C extends { op: 'write' }
              ? { acknowledged: true }
              : C extends { op: 'notify'; immediate: NotifyImmediate }
            ? { notified: true }
            : C extends { op: 'notify' }
              ? { triggerId: string }
              : C extends { op: 'request' }
                ? { accepted: true }
                : C extends { op: 'exec' }
                    ? { stdout: string; stderr: string; exitCode: number }
                    : C extends { op: 'subscribe' }
                      ? never // subscribe 走 subscribe(),不经 invoke()
                      : unknown;
