/**
 * 能力作用域。每个订阅/写入能力都带 scope(baseline §7.4 #4):
 * 免得日后每个 API 签名返工。manifest 声明插件绑哪层(如 CC 审查 = per-terminal)。
 */
export type Scope =
  | { kind: 'global' }
  | { kind: 'server'; serverId: string }
  | { kind: 'terminal'; serverId: string; terminalId: string };

export function scopeEquals(a: Scope, b: Scope): boolean {
  if (a.kind !== b.kind) return false;
  if (a.kind === 'global' || b.kind === 'global') return a.kind === b.kind;
  if (a.kind === 'server' && b.kind === 'server') return a.serverId === b.serverId;
  if (a.kind === 'terminal' && b.kind === 'terminal') {
    return a.serverId === b.serverId && a.terminalId === b.terminalId;
  }
  return false;
}

/** outer 是否覆盖 inner(provider 注册在 outer,可服务 inner 的 cap)。 */
export function scopeContains(outer: Scope, inner: Scope): boolean {
  if (outer.kind === 'global') return true;
  if (outer.kind === 'server') {
    return (
      (inner.kind === 'server' || inner.kind === 'terminal') && inner.serverId === outer.serverId
    );
  }
  // terminal
  return (
    inner.kind === 'terminal' &&
    inner.serverId === outer.serverId &&
    inner.terminalId === outer.terminalId
  );
}

/**
 * 挂载层级校验:mount scope 的 kind 不能比 manifest 声明的 scope 更宽。
 * (global 声明可挂任意;server 可挂 server/terminal;terminal 只能挂 terminal)
 */
export function scopeKindAllows(declared: Scope['kind'], mount: Scope['kind']): boolean {
  if (declared === 'global') return true;
  if (declared === 'server') return mount === 'server' || mount === 'terminal';
  return mount === 'terminal';
}
