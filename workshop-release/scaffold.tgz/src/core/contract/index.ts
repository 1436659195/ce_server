// 能力契约 public API
export type {
  Capability,
  CapabilityOp,
  SubscribeCap,
  ReadCap,
  WriteCap,
  NotifyCap,
  NotifyTrigger,
  PluginLifecycle,
  RpcReq,
  RpcStreamChunk,
  CapabilityResult,
  FileRangeChunk,
  AgentModelInfo,
} from './types';
export type { CapabilityProvider, InvokeResult, SubscribeResult, RpcErrorShape } from './provider';
export { RpcBus, RpcErrorThrowable } from './rpc';
export type { RpcClient } from './rpc';
export { scopeEquals, scopeContains, scopeKindAllows } from './scope';
export type { Scope } from './scope';

// 插件契约类型(manifest 形状 + 组件 ctx)—— 插件从 @core/contract 拿,不直 import plugin/manifest。
// type-only re-export:plugin/manifest 反向 type-only 引用 contract/scope+types,无运行时循环。
export type {
  PluginManifest,
  PluginContext,
  PluginProps,
  SessionProps,
  PluginHealth,
  PluginIconName,
  FileActionProps,
  FileViewerProps,
  FileViewerContribution,
  FileActionContribution,
} from '../plugin/manifest';
// ANY_EXTENSION 是运行时常量（fileViewers 通配兜底），值导出
export { ANY_EXTENSION } from '../plugin/manifest';

// 文件读取结果(readFile 能力返回类型)—— 契约层暴露给插件
export type { FileReadResult, ContentEntry } from '../../types/file';
