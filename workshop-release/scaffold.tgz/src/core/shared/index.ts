/**
 * 共享组件库 —— 插件可用的 UI 组件(工坊 SDK 瘦身版,由集装箱生成,勿手改)。
 *
 * 插件只应从 `@core/shared` 导入这些组件,不要自己造基础控件(保证全 app 视觉统一)。
 * SDK 面冻结:与仓内真实索引的差异 = 不含平台网关 installExternalPlugin 系列。
 */

// 基础控件
export { Button } from '@/components/shared/Button';
export { InputSheet } from '@/components/shared/InputSheet';
export { Card } from '@/components/shared/Card';
export { Icon } from '@/components/shared/Icon';
export { Text } from '@/components/shared/Text';

// 布局组件
export { Modal } from '@/components/shared/Modal';
export { Sheet } from '@/components/shared/Sheet';
export { Popover } from '@/components/shared/Popover';
export { ConfirmSheet } from '@/components/shared/ConfirmSheet';

// 数据展示
export { CodeBlock } from '@/components/shared/CodeBlock';
export { JSONViewer } from '@/components/shared/JSONViewer';
export { DiffView } from '@/components/shared/DiffView';
export { Approval } from '@/components/shared/Approval';
export { Markdown, renderMarkdown } from '@/components/shared/Markdown';
export { ProgressBar } from '@/components/shared/ProgressBar';

// 其他
export { AppErrorBoundary } from '@/components/shared/AppErrorBoundary';
export { CloudCodeIcon } from '@/components/shared/CloudCodeIcon';
export { ClaudeIcon, PluginIcon } from '@/components/shared/PluginIcons';

// 反馈(插件用 toast 提示,不直 import core/feedback)
export { showToast } from '@/core/feedback/useToast';

// 通用工具
// 流式下载到 Cache(「下载」系统动作 + APK 安装插件共用;调用方塞 readRange 闭包)
export { downloadToCache, basename, CHUNK_BYTES } from '@/core/shared/download';
// 字节 → 人类可读(文件 size 显示;text-view 等查看器插件用)
export { formatSize } from '@/components/files/formatSize';

// notebook/Python(零依赖纯函数;ipynb 查看与 IDE 两类插件共用,2026-09-25)
export { parseNotebook, serializeNotebook } from '@/core/shared/nbformat';
export type { Notebook, NbCell, NbOutput } from '@/core/shared/nbformat';
export { tokenizePython, PY_KIND_CLASS } from '@/core/shared/pyHighlight';
export type { PyToken, PyTokenKind } from '@/core/shared/pyHighlight';
export type { ReadRangeFn, DownloadResult } from '@/core/shared/download';

// 主题 token(CSS 变量名)
export const themeTokens = {
  // 颜色
  colorFg: 'text-fg',
  colorFgMuted: 'text-fg-muted',
  colorBg: 'bg-panel',
  colorBorder: 'border-border',
  colorDanger: 'text-danger',
  colorAccent: 'text-accent',

  // 字号
  fontSizeXs: 'var(--fs-xs)',
  fontSizeSm: 'var(--fs-sm)',
  fontSizeMd: 'var(--fs-md)',
  fontSizeLg: 'var(--fs-lg)',
  fontSizeXl: 'var(--fs-xl)',

  // 圆角
  radiusSm: 'var(--radius-sm)',
  radiusMd: 'var(--radius-md)',
  radiusLg: 'var(--radius-lg)',
} as const;
