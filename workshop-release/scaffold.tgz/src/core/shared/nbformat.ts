/**
 * .ipynb(nbformat)解析/序列化(纯函数,零依赖)—— jupyter-ide(执行/保存)的数据层。
 * 2026-09-25 随插件提升进共享层(查看件当日撤销后由 IDE 件独享;留共享层是
 * 未来任何 notebook 形态件的公共地基,升 @core/shared 见 contract-extension-spec)。
 *
 * 把 nbformat 4.x 的 JSON 归一成渲染友好的形状:source 字符串/行数组两种形态拼接、
 * outputs 各型归一(stream/error/image/text)。**丢弃型**:text/html 等富媒体输出
 * v1 不渲染(knownIssues 已声明,防任意 HTML;要时再走 sandbox 加菜)。
 *
 * 内核执行(IDE 会话)是下一列车:需契约加菜(kernel 会话/执行/输出流),不在本层。
 */

export interface NbCell {
  type: 'code' | 'markdown' | 'raw';
  source: string;
  /** code cell 的执行序号(未执行 = null) */
  execCount: number | null;
  outputs: NbOutput[];
}

export type NbOutput =
  | { kind: 'stream'; text: string }
  | { kind: 'error'; ename: string; evalue: string; traceback: string }
  | { kind: 'image'; mime: 'image/png' | 'image/jpeg'; base64: string }
  | { kind: 'text'; text: string };

export interface Notebook {
  cells: NbCell[];
  /** 丢弃的输出块数(text/html 等未渲染型;详情页提示用) */
  skippedOutputs: number;
}

type RawJson = Record<string, unknown>;

const isObj = (v: unknown): v is RawJson => typeof v === 'object' && v !== null && !Array.isArray(v);

/** source 两种形态(字符串 / 行数组)归一拼接;行数组每行自带 \n(nbformat 惯例)。 */
function joinSource(v: unknown): string {
  if (typeof v === 'string') return v;
  if (Array.isArray(v)) return v.filter((x) => typeof x === 'string').join('');
  return '';
}

/** 单个 output 归一;不可渲染的型返回 null(计入 skipped)。 */
function normalizeOutput(o: unknown): NbOutput | null {
  if (!isObj(o)) return null;
  switch (o.output_type) {
    case 'stream':
      return { kind: 'stream', text: joinSource(o.text) };
    case 'error':
      return {
        kind: 'error',
        ename: typeof o.ename === 'string' ? o.ename : 'Error',
        evalue: typeof o.evalue === 'string' ? o.evalue : '',
        traceback: Array.isArray(o.traceback) ? o.traceback.filter((t) => typeof t === 'string').join('\n') : '',
      };
    case 'execute_result':
    case 'display_data': {
      const data = isObj(o.data) ? o.data : {};
      // 图片优先(matplotlib 输出的大头);png > jpeg
      if (typeof data['image/png'] === 'string') {
        return { kind: 'image', mime: 'image/png', base64: data['image/png'] };
      }
      if (typeof data['image/jpeg'] === 'string') {
        return { kind: 'image', mime: 'image/jpeg', base64: data['image/jpeg'] };
      }
      if (typeof data['text/plain'] === 'string') {
        return { kind: 'text', text: data['text/plain'] };
      }
      if (Array.isArray(data['text/plain'])) {
        return { kind: 'text', text: joinSource(data['text/plain']) };
      }
      return null; // text/html 等富媒体:v1 不渲染(防任意 HTML,knownIssues 声明)
    }
    default:
      return null;
  }
}

/** 解析整本 notebook;任何形状问题给人话错误(查看器错误态展示),不抛。 */
export function parseNotebook(src: string): { ok: true; nb: Notebook } | { ok: false; error: string } {
  let json: unknown;
  try {
    json = JSON.parse(src);
  } catch (e) {
    return { ok: false, error: `不是合法 JSON:${(e as Error).message}` };
  }
  if (!isObj(json) || !Array.isArray(json.cells)) {
    return { ok: false, error: '不是 notebook(缺 cells 数组)' };
  }
  const cells: NbCell[] = [];
  let skipped = 0;
  for (const c of json.cells) {
    if (!isObj(c)) continue;
    const type = c.cell_type === 'code' || c.cell_type === 'markdown' || c.cell_type === 'raw' ? c.cell_type : 'raw';
    const outputs: NbOutput[] = [];
    if (Array.isArray(c.outputs)) {
      for (const o of c.outputs) {
        const n = normalizeOutput(o);
        if (n) outputs.push(n);
        else skipped += 1;
      }
    }
    cells.push({
      type,
      source: joinSource(c.source),
      execCount: typeof c.execution_count === 'number' ? c.execution_count : null,
      outputs,
    });
  }
  return { ok: true, nb: { cells, skippedOutputs: skipped } };
}

/** 输出项 → nbformat 原始形状(解析的逆;kind 与 output_type 的映射)。 */
function outputToRaw(o: NbOutput): Record<string, unknown> {
  switch (o.kind) {
    case 'stream':
      return { output_type: 'stream', name: 'stdout', text: o.text };
    case 'error':
      return {
        output_type: 'error',
        ename: o.ename,
        evalue: o.evalue,
        traceback: o.traceback ? o.traceback.split('\n') : [],
      };
    case 'image':
      return { output_type: 'display_data', data: { [o.mime]: o.base64 }, metadata: {} };
    case 'text':
      return { output_type: 'execute_result', data: { 'text/plain': o.text }, metadata: {} };
  }
}

/**
 * cells → .ipynb JSON 文本(jupyter-ide 保存用;parseNotebook 的逆)。
 * source 按行拆(nbformat 惯例行数组带换行,非末行补 \n)。
 */
export function serializeNotebook(cells: NbCell[]): string {
  const raw = {
    cells: cells.map((c) => ({
      cell_type: c.type,
      source: c.source.length === 0 ? [] : c.source.split('\n').map((l, i, arr) => (i < arr.length - 1 ? l + '\n' : l)),
      ...(c.type === 'code'
        ? { outputs: c.outputs.map(outputToRaw), execution_count: c.execCount }
        : {}),
      metadata: {},
    })),
    metadata: {},
    nbformat: 4,
    nbformat_minor: 5,
  };
  return JSON.stringify(raw, null, 1);
}
