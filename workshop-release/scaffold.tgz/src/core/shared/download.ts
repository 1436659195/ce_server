/**
 * 流式下载到本地 Cache —— 通用下载原语(「下载」系统动作 + APK 安装插件共用)。
 *
 * 设计:本函数只管「分段拉字节 + 写 Cache」,不知道字节从哪来、拉完干啥:
 *  - 怎么取一段(readRange 闭包)由调用方塞:系统下载塞 store.readFileRange、插件塞 ctx.rpc.invoke。
 *  - 拉完干嘛由调用方决定:系统下载 → Share 分享;APK 插件 → ApkInstaller 拉安装器。
 * 这就是「下载是基础,APK = 下载 + 唤安装器」的事实分层。
 *
 * 为什么必须分段(不走 readFile 全量):readFile 把整文件 content 塞进 RPC resp,
 * JSON.stringify(中文 \uXXXX 转义放大)+ encode + 加密三个大 buffer 同存,几 MB 的二进制
 * (base64 后更长)就能把 ce 进程 OOM 顶崩(已踩过)。分段每次只持单段(~512KB),内存恒定。
 * ce-server bridge 用 HTTP Range 保证非末段返恰好 length 字节(→ base64 无 padding,append 不破坏字节流)。
 *
 * 移植自旧 app src/composables/useFiles.ts 的 streamBase64ToCache + relayBase64Chunks + downloadToCache
 * (逐行审计、合并;旧版直连分支不需要 —— 系统下载/插件都只在中继环境跑)。
 */
import { Filesystem, Directory } from '@capacitor/filesystem';
import type { FileRangeChunk } from '@/core/contract';
import { recordDownload } from './downloadHistory';

/**
 * 每段字节数:必须是 3 的倍数(base64 每 3 字节 → 4 字符,非末段若带 padding 会破坏字节流)。
 * ce-server readFileRange 用 HTTP Range 保证非末段返恰好该长度(→ 无 padding)。约 512KB/段。
 */
export const CHUNK_BYTES = 524286; // = 3 × 174762

/** 取一段字节(调用方提供:store.readFileRange / ctx.rpc.invoke)。 */
export type ReadRangeFn = (offset: number, length: number) => Promise<FileRangeChunk>;

export interface DownloadResult {
  /** Cache 文件 file:// URI(供 Share / ApkInstaller 用)。 */
  uri: string;
  filename: string;
}

/** 取 path 末段作文件名(无则 'download')。 */
export function basename(p: string): string {
  const i = p.lastIndexOf('/');
  const base = i >= 0 ? p.slice(i + 1) : p;
  return base || 'download';
}

/**
 * 流式下载到 Cache。
 *
 * @param readRange  取段闭包(系统下载 = store.readFileRange;插件 = ctx.rpc.invoke)
 * @param path       远端文件绝对路径(raw,URL 编码在 ce-server bridge 侧);仅取 basename 作文件名
 * @param onProgress 进度回调(ratio 0..1,节流 ~250ms)
 * @param cancelled  取消探针;返真则抛「已取消」
 * @returns Cache 文件 file:// URI + 文件名
 */
export async function downloadToCache(
  readRange: ReadRangeFn,
  path: string,
  onProgress?: (ratio: number) => void,
  cancelled?: () => boolean,
): Promise<DownloadResult> {
  const filename = basename(path);
  let offset = 0;
  let totalSize = 0;
  let uri = '';
  let first = true;
  let lastReport = 0;
  for (;;) {
    if (cancelled?.()) throw new Error('已取消');
    const chunk = await readRange(offset, CHUNK_BYTES);
    if (!totalSize) totalSize = chunk.totalSize;
    if (first) {
      // 首段建文件(recursive 免手动建父目录);拿 file:// uri
      const r = await Filesystem.writeFile({
        path: filename,
        data: chunk.data,
        directory: Directory.Cache,
        recursive: true,
      });
      uri = r.uri;
      first = false;
    } else {
      // 后续段追加(base64 段 → Filesystem 自动解码成字节拼接)
      await Filesystem.appendFile({ path: filename, data: chunk.data, directory: Directory.Cache });
    }
    offset += chunk.bytes;
    if (onProgress && totalSize > 0) {
      const ratio = Math.min(offset / totalSize, 1);
      const now = Date.now();
      if (now - lastReport > 250 || chunk.eof) {
        onProgress(ratio);
        lastReport = now;
      }
    }
    if (chunk.eof) break;
  }
  if (!uri) throw new Error('下载失败:无数据');
  // 落下载记录(设置 → 下载记录;成功才记,取消/失败不记)。单一挂点:系统下载与
  // APK 安装插件都经此,记录一处齐;按 filename upsert(Cache 同名覆盖语义,见 downloadHistory)。
  recordDownload(filename, path, totalSize || offset);
  return { uri, filename };
}
