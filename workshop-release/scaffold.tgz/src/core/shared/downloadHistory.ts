/**
 * 下载记录 store —— 本机 Cache 下载历史(设置 → 下载记录)。
 *
 * 背景:downloadToCache 写的是应用私有 Cache,系统按需才回收 → 短期反复下大文件一直占存储,
 * 用户无感知也无入口管理。本模块补两块:①记录「下载过什么」;②删除记录时**顺手清掉 Cache
 * 里的文件**(真正释放存储;被控机原件不受影响)。
 *
 * 记录按 **filename 为键 upsert**:Cache 目录是扁平的、同名后下覆盖先下 —— 记录与磁盘真实
 * 状态一一对应(不会出现「删 A 的记录误删 B 的文件」)。上限 MAX_RECORDS 裁最老,防 localStorage
 * 无界增长。模块级 external store + useSyncExternalStore(对齐 useToast / externalPlugins 模式)。
 *
 * 归属说明:放 core/shared(与 download.ts 同层,同管 Cache 生命周期),但不进 shared/index 导出面
 * —— 插件不需要「下载历史」这个 API;外部插件 bundle 里的 downloadToCache 副本会带着本模块,
 * 经 allow-same-origin 同源落进同一份 localStorage,记录照常可见(顺带的老 bundle 没有记录,无碍)。
 */
import { useSyncExternalStore } from 'react';
import { Filesystem, Directory } from '@capacitor/filesystem';

/** 一条下载记录(Cache 扁平目录的一员;filename 即 Cache 里的文件名)。 */
export interface DownloadRecord {
  /** Cache 文件名(= 远端 basename;同键 upsert) */
  filename: string;
  /** 远端绝对路径(展示来源;app 内下载才有,插件下载可能只有文件名) */
  path: string;
  /** 字节数 */
  size: number;
  /** 下载完成时刻(ms) */
  at: number;
}

const STORAGE_KEY = 'ce_download_history';
/** 记录上限:裁最老(下载记录是低频事件,200 条足够回溯;防 localStorage 无界)。 */
const MAX_RECORDS = 200;

function load(): Record<string, DownloadRecord> {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return {};
    const parsed = JSON.parse(raw) as unknown;
    if (!parsed || typeof parsed !== 'object' || Array.isArray(parsed)) return {};
    const out: Record<string, DownloadRecord> = {};
    for (const [k, v] of Object.entries(parsed as Record<string, unknown>)) {
      const r = v as Partial<DownloadRecord>;
      if (typeof r?.filename === 'string' && typeof r.size === 'number' && typeof r.at === 'number') {
        out[k] = { filename: r.filename, path: String(r.path ?? ''), size: r.size, at: r.at };
      }
    }
    return out;
  } catch {
    return {}; // 损坏 → 弃(下次下载重建)
  }
}

let records: Record<string, DownloadRecord> = load();
const listeners = new Set<() => void>();

function persist(): void {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(records));
  } catch {
    /* 隐私模式 / 配额 → 仅内存 */
  }
}

function emit(): void {
  listeners.forEach((l) => l());
}

/** 快照缓存:useSyncExternalStore 要求 getSnapshot 引用稳定(两次变更间同数组,对照
 *  externalPlugins 的 manifestsCache 同款)—— 变更时置 null,读时惰性重建。 */
let snapshotCache: DownloadRecord[] | null = null;

/** 记录一次下载完成(成功才记;按 filename upsert,Cache 同名覆盖语义)。 */
export function recordDownload(filename: string, path: string, size: number): void {
  records = { ...records, [filename]: { filename, path, size, at: Date.now() } };
  // 超限裁最老(O(n log n) 低频路径,不值得维护堆)
  const all = Object.values(records);
  if (all.length > MAX_RECORDS) {
    const keep = new Set(
      all.sort((a, b) => b.at - a.at).slice(0, MAX_RECORDS).map((r) => r.filename),
    );
    const next: Record<string, DownloadRecord> = {};
    for (const r of all) if (keep.has(r.filename)) next[r.filename] = r;
    records = next;
  }
  snapshotCache = null;
  persist();
  emit();
}

/** 快照(按时间倒序;引用稳定 —— 未变时返回同一数组)。 */
export function listDownloads(): DownloadRecord[] {
  if (!snapshotCache) snapshotCache = Object.values(records).sort((a, b) => b.at - a.at);
  return snapshotCache;
}

/** 删除记录(不删文件;文件清理由 UI 调 deleteCachedFile,职责分开、UI 可提示)。 */
export function deleteDownload(filename: string): void {
  if (!(filename in records)) return;
  const next = { ...records };
  delete next[filename];
  records = next;
  snapshotCache = null;
  persist();
  emit();
}

/** 清空全部记录(同样只动记录,不动文件)。 */
export function clearDownloads(): void {
  records = {};
  snapshotCache = null;
  persist();
  emit();
}

/** 删 Cache 里的已下载文件(尽力而为:文件已不在/系统拒 → 静默,记录层不受影响)。 */
export async function deleteCachedFile(filename: string): Promise<void> {
  try {
    await Filesystem.deleteFile({ path: filename, directory: Directory.Cache });
  } catch {
    /* 已不存在(系统已回收/从未落盘)→ 目的已达到 */
  }
}

function subscribe(cb: () => void): () => void {
  listeners.add(cb);
  return () => {
    listeners.delete(cb);
  };
}

/** 订阅增删变化(导出供测试断言订阅语义;React 侧走 useDownloadHistory)。 */
export function subscribeDownloads(cb: () => void): () => void {
  return subscribe(cb);
}

/** React 订阅(下载记录页用;record/delete/clear 后自动重渲染)。 */
export function useDownloadHistory(): DownloadRecord[] {
  return useSyncExternalStore(subscribe, listDownloads, listDownloads);
}
