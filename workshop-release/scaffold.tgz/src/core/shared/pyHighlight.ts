/**
 * Python 词法着色(零依赖,纯函数)—— 2026-09-25 从 py-editor 插件提升进共享层:
 * jupyter-ide 的 code cell 展示与 py-editor 共用(插件间禁互 import,升 @core/shared)。
 *
 * 为什么不用 prism/shiki:全家桶只差 Python 一门语言,拖一个高亮库进 APK 不划算
 * (宁可慢不要脏);~60 行手写扫描器覆盖移动端阅读场景的 95%:
 * 关键字/内建/字符串(含三引号与前缀 r/f/b)/注释/数字/装饰器/def-class 名。
 *
 * 已知边界(有意接受):跨行表达式内的字符串拼接不合并、Unicode 标识符外的怪字符
 * 落 plain;要完美换 prism 是加菜,不是本插件的事。
 */

/** 着色档位 → 主题 token 类名(全部走主题变量,深浅色自动协调)。 */
export type PyTokenKind =
  | 'plain'
  | 'comment'
  | 'string'
  | 'keyword'
  | 'builtin'
  | 'number'
  | 'decorator'
  | 'defname';

export interface PyToken {
  text: string;
  kind: PyTokenKind;
}

/** 关键字(Python 3 官方词表 + match/case)。 */
const KEYWORDS = new Set([
  'False', 'None', 'True', 'and', 'as', 'assert', 'async', 'await', 'break',
  'class', 'continue', 'def', 'del', 'elif', 'else', 'except', 'finally',
  'for', 'from', 'global', 'if', 'import', 'in', 'is', 'lambda', 'nonlocal',
  'not', 'or', 'pass', 'raise', 'return', 'try', 'while', 'with', 'yield',
  'match', 'case',
]);

/** 高频内建(self/cls 也归此,阅读时最需要跳出的两个)。 */
const BUILTINS = new Set([
  'self', 'cls', 'print', 'len', 'range', 'int', 'str', 'float', 'list',
  'dict', 'set', 'tuple', 'bool', 'open', 'enumerate', 'zip', 'map', 'filter',
  'sum', 'min', 'max', 'abs', 'sorted', 'isinstance', 'type', 'super',
  'Exception', 'ValueError', 'TypeError', 'KeyError', 'IndexError',
  'StopIteration', 'repr', 'format', 'any', 'all', 'round', 'input', 'bytes',
  'object', 'getattr', 'setattr', 'hasattr', 'id', 'hash', 'iter', 'next',
  'pow', 'divmod', 'reversed', '__init__', '__name__', '__main__',
]);

/** 三引号串(最长匹配,须先于单行串);前缀串(r/f/b 组合);数字;装饰器;标识符。 */
const RE_TRIPLE = /^(?:[rRbBfFuU]{0,2})("""[\s\S]*?"""|'''[\s\S]*?''')/;
const RE_COMMENT = /^#.*/;
const RE_STRING = /^(?:[rRbBfFuU]{0,2})("(?:[^"\\\n]|\\.)*"?|'(?:[^'\\\n]|\\.)*'?)/;
const RE_NUMBER = /^(?:0[xXbBoO][0-9a-fA-F_]+|\d[\d_]*(?:\.\d[\d_]*)?(?:[eE][+-]?\d+)?)/;
const RE_DECORATOR = /^@[A-Za-z_]\w*/;
const RE_IDENT = /^[A-Za-z_]\w*/;
/** 非 token 起点的普通字符(run 合并减 DOM);含换行的 run 会打断 def 前瞻。 */
const RE_PLAIN = /^[^A-Za-z_0-9#"']+/;

/**
 * 扫描器:pos 游标逐档匹配(顺序敏感:三引号 > 注释 > 前缀串 > 数字 > 装饰器 > 标识符)。
 * 邻接同色 token 合并(把 DOM 节点数压到接近"每色一段")。
 */
export function tokenizePython(src: string): PyToken[] {
  const out: PyToken[] = [];
  let i = 0;
  // def/class 前瞻:上一个关键字是 def/class 且中间没隔换行 → 下一个标识符是定义名
  let pendingDef = false;
  const push = (text: string, kind: PyTokenKind): void => {
    const last = out[out.length - 1];
    if (last && last.kind === kind) last.text += text;
    else out.push({ text, kind });
  };
  while (i < src.length) {
    const rest = src.slice(i);
    let m: RegExpExecArray | null;
    if ((m = RE_TRIPLE.exec(rest))) {
      push(m[0], 'string');
      i += m[0].length;
      pendingDef = false;
      continue;
    }
    if ((m = RE_COMMENT.exec(rest))) {
      push(m[0], 'comment');
      i += m[0].length;
      continue; // 注释不吃 def 前瞻(行尾 def 后不会立刻接名,无所谓)
    }
    if ((m = RE_STRING.exec(rest))) {
      push(m[0], 'string');
      i += m[0].length;
      pendingDef = false;
      continue;
    }
    if ((m = RE_NUMBER.exec(rest))) {
      push(m[0], 'number');
      i += m[0].length;
      pendingDef = false;
      continue;
    }
    if ((m = RE_DECORATOR.exec(rest))) {
      push(m[0], 'decorator');
      i += m[0].length;
      pendingDef = false;
      continue;
    }
    if ((m = RE_IDENT.exec(rest))) {
      const w = m[0];
      if (pendingDef) {
        push(w, 'defname');
        pendingDef = false;
      } else if (KEYWORDS.has(w)) {
        push(w, 'keyword');
        if (w === 'def' || w === 'class') pendingDef = true;
      } else if (BUILTINS.has(w)) {
        push(w, 'builtin');
      } else {
        push(w, 'plain');
      }
      i += w.length;
      continue;
    }
    if ((m = RE_PLAIN.exec(rest))) {
      push(m[0], 'plain');
      i += m[0].length;
      // 换行打断 def 前瞻(空行后出现的名字不是定义名);同行空白/括号不打断
      if (m[0].includes('\n')) pendingDef = false;
      continue;
    }
    // 兜底:落单的引号/数字等(未闭合串的残尾)按 plain 吞一个字符
    push(src[i], 'plain');
    i += 1;
  }
  return out;
}

/** 档位 → 展示类名(defname 在色上叠加粗;builtin 用次级灰,克制不抢戏)。 */
export const PY_KIND_CLASS: Record<PyTokenKind, string> = {
  plain: '',
  comment: 'text-fg-muted italic',
  string: 'text-success',
  keyword: 'text-accent',
  builtin: 'text-fg-secondary',
  number: 'text-warn',
  decorator: 'text-warn',
  defname: 'text-accent font-semibold',
};
