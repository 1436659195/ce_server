# 三档模板 + 测试底线(按档读,别全读)

> SKILL.md §1 第 2/4 步的参考。**只读自己那档**:L1 → 「L1」;L2 → 「L2」+「测试底线」;
> L3 → 「L3 会话页」或「L3 迷你查看器」+「测试底线」。模板完整可跑,照抄改。

## L1:CC 完工提醒(P1-M1 验收件,零代码)

`src/plugins/cc-done-remind/manifest.ts`(**没有** main.tsx):

```ts
import type { PluginManifest } from '@core/contract';

export const ccDoneRemindManifest: PluginManifest = {
  id: 'cc-done-remind',
  name: 'CC 完工提醒',
  version: '0.1.0',
  icon: 'bell',
  description: 'CC 一轮收尾(成功/失败)弹通知,熄屏也能收到。',
  capabilities: ['notify'],          // 平台评估 triggers,不需要别的
  permissions: {},                    // L1 零权限
  scope: 'global',
  triggers: [
    { id: 'done', when: 'agentResult', title: 'CC 完工', body: '状态:{{status}},回去看看' },
    { id: 'need-approval', when: 'approvalPending', title: 'CC 待审批', body: '工具:{{tool}}' },
  ],
};
```

## L2:CPU 超 80% 提醒(lifecycle + exec + 动态 notify)

`manifest.ts` 关键字段(lifecycle 声明 + exec 白名单):

```ts
export const cpuAlertManifest: PluginManifest = {
  id: 'cpu-alert',
  name: 'CPU 高位提醒',
  version: '0.1.0',
  capabilities: ['subscribe', 'exec', 'notify'],
  permissions: { execCommands: ['top'] },   // 只许跑 top,别的不行
  scope: 'server',
  lifecycle: ['mount', 'unmount'],
};
```

`main.tsx` 关键形状(lifecycle 钩子 = 同名 export;节奏 = 订阅 tick,**不要自管计时器**):

```tsx
import type { PluginContext } from '@core/contract';

let running = false;
let cancelTick: (() => void) | undefined;

/** mount:进 scope 时平台调用 —— 订阅心跳定节奏(P1 第六坑:熄屏 JS 定时器被冻结,tick 源在原生层) */
export function mount(ctx: PluginContext): void {
  running = true;
  void ctx.rpc.subscribe(
    { op: 'subscribe', stream: 'tick', intervalMs: 60_000, scope: ctx.scope },
    () => { void pollOnce(ctx); },
  ).then((h) => {
    if (!running) h.cancel();  // 订阅落地前就被卸载 → 立即退订
    else cancelTick = h.cancel;
  });
}

async function pollOnce(ctx: PluginContext): Promise<void> {
  if (!running) return;
  const r = await ctx.rpc.invoke({
    op: 'exec', command: 'top -b -n 1', scope: ctx.scope,
  });
  // 解析 CPU 占用,超阈值 → 当场弹(Q10 immediate):
  await ctx.rpc.invoke({
    op: 'notify',
    immediate: { title: `CPU ${pct}% ≥ 80%`, body: '回去看看' },
    scope: ctx.scope,
  });
}

/** unmount:离 scope —— 必须清理,否则泄漏 */
export function unmount(): void {
  running = false;
  cancelTick?.();
  cancelTick = undefined;
}
```

> 注 1:notify immediate 有**全局速率窗**(60s/20 条)——做迟滞/去抖(如 ≥80% 报一次、
> 回落到 70% 以下才允许再报),别每轮都发,撞窗回 `NOTIFY_RATE_LIMITED`。
> 注 2:外部 L2 件的常驻方式已定稿(Q9):声明 lifecycle 的工件装上后由宿主渲染隐藏
> iframe 保活,mount/unmount 在 iframe 里被调起;插件侧无感知,按上述契约形状写即可。
> 注 3:轮询节奏一律订阅 `tick`(间隔宿主钳 10s~1h);上一拍没干完自己丢拍防堆积
> (inFlight 岗哨,范例见 `src/plugins/cpu-report/main.tsx`)。

## L3:会话页插件(系统监控式 —— 「+」菜单里的独立页)

`manifest.ts` 关键字段(contributes.sessions):

```ts
export const sysMonitorManifest: PluginManifest = {
  id: 'sys-monitor',
  name: '系统监控',
  version: '0.1.0',
  icon: 'activity',                     // 从 SKILL.md §2 图标清单挑,必填
  capabilities: ['subscribe', 'exec'],
  permissions: { execCommands: ['top', 'free'] },  // 只列真正要跑的
  scope: 'server',
  contributes: {
    sessions: [
      {
        sessionType: 'sys-monitor',     // 「+」菜单按它新建会话;kebab-case,别用 'terminal'(保留字)
        entry: 'monitor',               // main.tsx 同名 export
        label: '系统监控',
        singleton: true,                // 单开件(见下)
      },
    ],
  },
};
```

`main.tsx`(entry 名 = export 名):

```tsx
import type { SessionProps } from '@core/contract';

export function monitor(props: SessionProps): JSX.Element {
  // props = { ctx }; 数据照常走 ctx.rpc(subscribe tick 定节奏 + exec 拿数)
  return <div>…页面…</div>;
}
```

> **L3 会话组件无需声明 lifecycle**:tick 铁律是按 L2 模块级 mount/unmount 讲的;
> 会话页的正确节奏 = 组件 `useEffect` 里 `ctx.rpc.subscribe(tick)`、cleanup 里
> `h.cancel()` 退订——**打开才轮询、关 tab 即停**(比 L2 常驻对被控机更客气)。
> 别写成"lifecycle + 组件内订阅"双份轮询。
> **完整范例:`src/plugins/sys-monitor/`**(与 cpu-report 之于 L2 对应,含 22 个测试;
> 采样多路独立降级 = 每路判 `exitCode === 0`,单路挂了不拖整页)。

**singleton 判断规则**(2026-08-27 用户反馈:「系统监控1」的序号暗示能多开,单开件不该有):

| 判断 | singleton | 例 |
|---|---|---|
| 页面看的是**这台机器/这份状态本身**,开两个只是重复看同一份东西 | `true` | 系统监控、仪表盘、日志页、扫传接收 |
| 每个会话有**独立上下文/独立目标**,多开各干各的 | 不写(默认 false) | CC 对话(每个会话不同任务)、不同目录的终端 |

- `singleton: true` → 名字不带 N 序号(「系统监控」而非「系统监控1」),已存在时点「+」菜单直接切过去。
- 判断口径:**用户会不会想同时开两个?** 不会 → true;会 → 不写。
- server 单开件按"本台服务器"匹配:另一台服务器上开着的不挡本台新建。

## L3:迷你查看器(仿 text-view)

`manifest.ts` 关键字段:

```ts
contributes: {
  fileViewers: [
    { id: 'view', entry: 'view', extensions: ['xyz'] },  // 精确扩展名;['*'] = 兜底一切
  ],
},
```

`main.tsx`(entry 名 = export 名):

```tsx
import type { FileViewerProps } from '@core/contract';

export function view(props: FileViewerProps): JSX.Element {
  // props = { ctx, path };读文件:ctx.rpc.invoke({ op:'read', kind:'readFile', path, scope: ctx.scope })
  return <div>…渲染…</div>;
}
```

- 查看型(fileViewers,点开自动路由)与动作型(fileActions,长按菜单手动点)**别混**:
  "打开看"= fileViewers;"对它做一件事(安装/转换)"= fileActions。装 .apk 自动执行是语义事故。

## 测试底线(L2/L3;SKILL.md §1 第 4 步的展开)

L1 至少一条 manifest 校验测试;L2/L3 测核心逻辑/组件渲染。组件渲染的最小假 ctx(照抄改):

```tsx
// __tests__/x.test.tsx
const invoke = vi.fn(async (cap: { command?: string }) => {
  // 按命令名回灌 fixture;模拟失败就 throw(新 Error)——真实 invoke 对硬错误走 reject
});
const cancel = vi.fn();
const subscribe = vi.fn(async () => ({ streamId: 't1', cancel }));  // 返回 {streamId, cancel}
const props = {
  ctx: { scope: { kind: 'terminal', serverId: 's1', terminalId: 't1' },
         rpc: { invoke, subscribe }, storage: {} as never },
} as unknown as SessionProps;
render(createElement(monitor, props));  // 小写 entry 名不能当 JSX 标签 → createElement
```

- **import barrier 的测试豁免**:插件**源码**只许 import `@core/contract` + `@core/shared`,
  但**测试文件不受此限**——manifest 校验用 `validateExternalManifest`
  (import `@/core/plugin/externalPlugins`;范例 `src/plugins/cpu-report/__tests__/manifest.test.ts`),
  升级路径实证用 `describeInstallConflicts`(来自 `@core/shared`)。守规矩不写这两类测试是浪费豁免。
- 组件渲染范例:`src/plugins/sys-monitor/__tests__/main.test.tsx`(L3)/
  `src/plugins/qr-receive/__tests__/QrReceive.test.tsx`(小写 entry 用 createElement 的出处)。
