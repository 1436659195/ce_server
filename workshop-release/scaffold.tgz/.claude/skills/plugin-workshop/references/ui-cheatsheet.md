# UI / 采数扩展速查(L3 与 exec 用户才读)

> SKILL.md §2 契约速查的扩展:**分档 = L3**(要写 UI)或**要用 exec 采数**(选通道前)时读。
> 三张表都带 CI 对账区(skill-sync.test.ts 对账),漂移即红。

## UI 贡献点速查(L3 选哪个;与 `src/core/plugin/manifest.ts` CI 对账)

<!-- contract:ui-contribs -->
| 贡献点 | 适用 | 关键字段 |
|---|---|---|
| `sessions` | 占一个 tab 的会话页(工具型/对话型:系统监控、CC 对话、扫传接收) | `entry` + `sessionType` + `label` + `icon`;`keyBar`(终端按键栏,默认 false);工具型设 `singleton: true`;`cwd`(固定启动目录,缺省=文件栏当前目录) |
| `slots` | 侧栏/浮窗/底栏/全屏/omnibox/内联 面板 | `slot` + `entry` + `label?` + `priority?` |
| `commands` | 命令/菜单项(平台原生渲染) | `entry` + `id` + `label` + `icon?` |
| `settings` | 设置项(平台原生渲染,JSON Schema) | `id` + `label` + `schema` + `defaultValue?` |
| `fileActions` | 长按菜单手动点(「对它做一件事」:安装/转换) | `id` + `label` + `entry` + `extensions` |
| `fileViewers` | 点开文件自动路由(「打开看」;`['*']`=兜底一切) | `id` + `entry` + `extensions` + `priority?` |
| `fileCreates` | 文件树「创建」菜单(「新建 XXX 文件」;模板工厂 `() => string`) | `id` + `entry` + `label` + `extension` |
<!-- /contract:ui-contribs -->

- **sessions 组件收 `SessionProps`**:`{ ctx, sessionId, serverId, terminalId?, cwd?,
  persist<T>/restore<T>(会话快照,杀 app 重开还在) }`——测试渲染照 `references/templates.md`
  「测试底线」的假 ctx。
- **查看型(fileViewers)与动作型(fileActions)别混**:"打开看"= fileViewers;
  "对它做一件事(安装/转换)"= fileActions。装 .apk 自动执行是语义事故。
- **创建型(fileCreates)**:文件树创建菜单里的「新建 XXX」(entry = 模板工厂返回文件内容);
  新文件长什么样全在插件,core 只写盘+打开。

## 采数通道速查(read 管道 vs exec;exec 返回形状与 `types.ts` CI 对账)

**read = Jupyter contents API,沙箱内**:路径**相对 Jupyter root_dir**;`/proc`、`/sys`
等 root_dir 外的伪文件**一律 404**——想读系统状态别走 read,走 exec 采样。

**exec = 程序名白名单,警惕逃逸**:白名单按**首 token 精确匹配、args 不受限**——
放行 `cat`/`head` = 任意文件读取逃逸(read 的 readPaths 挡不住 exec 的 cat);放行 `ip` =
可 `ip link set down` 断网。**可安全放行的采数程序参考**:`top` / `free` / `df` /
`nvidia-smi`(只读汇总、无文件内容输出、无副作用)。

<!-- contract:exec-shape -->
| 字段 | 语义 |
|---|---|
| `stdout` | 标准输出(字符串) |
| `stderr` | 标准错误(字符串) |
| `exitCode` | 进程退出码;**非 0 = 命令失败,不走 reject,自己判**(如没装 nvidia-smi 时) |
<!-- /contract:exec-shape -->

## 共享组件速查(UI 红线的具体清单;组件名与 `@core/shared` 导出 CI 对账)

<!-- contract:ui-components -->
| 组件 | 关键 props |
|---|---|
| `Button` | `variant: default\|accent\|ghost\|danger;size: sm\|md` |
| `Card` | 原生 div 属性(bg-panel 卡片容器) |
| `Text` | `muted?` / `secondary?`(三档字色) |
| `Icon` | `icon: LucideIcon 组件`(注意:manifest 的 icon 是**字符串名**,两套约定别混) |
| `PluginIcon` | `name: 图标名字符串;fallback?: 兜底文字` |
| `Modal` | `open, onClose, title?, dismissible?` |
| `CodeBlock` | `code, lang?` |
| `Markdown` | `children: string` |
| `JSONViewer` / `DiffView` / `Approval` | 数据展示三件套 |
| `showToast` | `(message, kind: 'info'\|'success'\|'error')` |
<!-- /contract:ui-components -->

- **`formatSize` 只到 B/KB/MB**(文件场景的取舍)——内存/显存是 GB 档,**别用它**,自己写
  GB 档格式化。
- 视觉惯用类(别写死颜色/字号):`bg-elevated` / `bg-accent` / `text-on-accent` / `text-fg-muted`
  / `tap-scale` / `text-[length:var(--fs-sm)]` / `rounded-[var(--radius-md)]`。
- 最小范例 markup:

  ```tsx
  <Card className="flex flex-col gap-2">
    <Text secondary>当前 CPU</Text>
    <Text className="text-[length:var(--fs-lg)] font-medium">23%</Text>
    <Button variant="accent" size="sm" onClick={refresh}>刷新</Button>
  </Card>
  ```
