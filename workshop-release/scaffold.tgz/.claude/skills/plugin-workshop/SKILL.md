---
name: plugin-workshop
description: 造 ce-platform 插件:接一句话需求 → 先查重(撞已有件默认扩展升级)→ 评估服务器资源(超载拒绝/偏重要用户同意)→ 分档(L1 纯触发器/L2 后台件/L3 界面件,能低不高)→ 按模板写 manifest(+main.tsx)→ 自检(tsc/eslint/vitest)→ 打 .ceplugin 工件交付。造插件前必读。
---

# 插件工坊 · 生成手册

给 AI(你)的操作手册:用户一句话需求 → 一个可安装的 `.ceplugin` 工件。
规则按顺序执行,别跳。

> **渐进加载**:本页只放每次都要的主干(工作流/分档/红线/契约小表)。两份参考**按需再 Read,别上来全读**:
> - `references/templates.md` —— 第 2 步生成时,**只读分档命中那一节**(L1/L2/L3 模板 + 测试底线);
> - `references/ui-cheatsheet.md` —— **分档 = L3** 要写 UI,或**要用 exec 选采数通道**时读。

## 0. 第一条铁律:先分档,再动手(能低不高)

| 档 | 判据(满足即选) | 形态 | 代码量 |
|---|---|---|---|
| **L1 纯触发器** | 只需"某事件发生 → 手机收到通知" | 只有 `manifest.ts`(triggers 纯数据) | **零代码** |
| **L2 后台件** | 需要定时/轮询/在后台持续跑逻辑(如监控 CPU) | `manifest.ts` + `main.tsx`(lifecycle 钩子) | 无 UI |
| **L3 界面件** | 需要任何界面(查看器/会话页/面板/长按动作) | `manifest.ts` + `main.tsx`(UI 组件) | 有 UI |

- **能低不高**:L1 够就不写 L2;L2 够就不上 L3。界面是最高成本档。
- **判了 L3 → 写 UI 前先读 `references/ui-cheatsheet.md`**(UI 贡献点选哪个 + 共享组件清单);
  要用 exec 采数的(常见于 L2/L3 监控件)也在选通道前读它的「采数通道速查」。
- 判断拿不准 → 问用户一句"需要界面吗,还是通知就够?"。
- 常见误判:"CPU 超 80% 提醒我" = **L2**(要轮询);"CC 干完活叫我" = **L1**(平台评估事件);
  **"监控 X 的实时状态" = L3**(要看的是当前值,不是等事件;notify 的 60s 速率窗/toast 承载不了看板)。
  这两类是孪生需求,分档最容易摇摆的一句话就是"实时"。

## 1. 工作流(七步,前有两小步)

0. **资源评估**(动手前先掂量被控机扛不扛得住,详见 §1.5):
   - 先自己查家底:`free -h`(内存)/ `nproc` + `top -b -n 1`(CPU)/ `df -h <目录>`(磁盘)。
   - **明显超出** → 明说做不了 + 给降级方案(降频率/缩范围/只看不做),不许硬上。
   - **偏重但可行** → 用大白话给用户列风险清单(占多少内存/CPU、可能拖慢什么、断电断网会怎样),
     **等用户明确同意才开工**;用户没点头就停在清单这一步。
   - **轻量**(绝大多数 L1/L2/查看型 L3)→ 直接往下走。
0.5. **查重**(分档前先看生态位,别造重复件):`ls plugins/`(工坊机布局;仓内开发是 `src/plugins/`)扫一眼;语义相近的件**只读它的
   `manifest.ts`**(description 一眼判撞车,**别通读实现**——那是造件最贵的时间坑)。撞车三分支,**默认扩展**:
   - **扩展**(默认):需求 = 同一件事的更大覆盖 → 升 minor 版本改现有件(一个插件一件事,不开两个重叠看板);
   - **并存**:需求 = 相邻但独立的事(如"看资源" vs "超标告警")→ 新 id,manifest 里注明与近邻的边界;
   - **弃造**:已被完全覆盖 → 直接指给用户现有工件,不造。
   - 对话式工坊里用户后续直接提修改意见时,**别发问卷干等**——按默认分支走,交付时说明
     "我这么处理了,不同意就说"(迭代成本本来就低)。
1. **分档**(§0)。把结论和理由先说给用户。
2. **生成** `plugins/<id>/`(工坊机布局;仓内开发在 `src/plugins/<id>`,打包脚本两处都认):
   - id = 小写 kebab-case,取自需求语义(如 `cc-done-remind`、`cpu-alert`)。
   - L1 只有 `manifest.ts`;L2/L3 加 `main.tsx` + `__tests__/`。
   - **照抄 `references/templates.md` 里分档命中的那一节**(L1/L2/L3 模板完整可跑;别把三档全读)。
3. **自检**(L2/L3 必跑;L1 只跑 5):**开局先跑 `node scripts/check-env.mjs`** —— 它把本机
   事实一次说清(可打包?tsc/vitest 装没装?),**按它的结论干活,别按本手册的历史许诺干活**:
   - 打包(第 5 步)是硬闸,必须过;
   - tsc/vitest **可用才跑**,缺席就在交付说明里如实写「跳过 X(本机未装)」—— 绝不假装跑过、
     也不许为凑"三绿"去装全局工具;
   - **禁跑全仓 `npm test`**——那是平台维护者的回归套件(1300+ 个 app 用例),与你的插件无关;
     汇报里出现"全仓 N 项测试通过"= 做错了。有错自己修到绿。
4. **测试底线**:L1 至少一条 manifest 校验测试;L2/L3 测核心逻辑/组件渲染。
   组件渲染的最小假 ctx + 测试 import 豁免 + 范例文件 → `references/templates.md`「测试底线」一节,照抄改。
5. **打包**:`node scripts/build-plugin.mjs <id>` → `dist/plugins/<id>.ceplugin`(单文件工件,L1 自动出 manifest-only 版,bundle='')。
6. **交付**:工件放 `/data/`(或用户指定处),告诉用户:手机上**长按该文件 → 安装插件**;确认页看清权限摘要,声明了 exec/联网/写路径的还要**逐条勾选高危授权**才能装(L1 纯通知件无勾选,一键可装)。工坊会话里完工回复写明:分档结论(L1/L2/L3 + 一句理由)、插件 id、插件名、图标名、**工件绝对路径**。**升级件(已有旧版在装)另加两条**:
   - 必附**相对上版的变更摘要**(新增什么/砍掉什么/权限变化)——别让变更只活在汇报文本里;
   - 必**实证升级路径**:测试里用 `describeInstallConflicts` 跑一遍"旧版在场 + 新版到达",
     确认提示的是 update 而非 reinstall/replace——**不许嘴上说会提示**。
     (manifest 加 `changes` 字段让确认页直接显差异是平台加菜候选,别等它。)

## 1.5 资源评估细则(第 0 步的依据)

**为什么**:插件跑在用户的被控机上,那是人家干活的机器,不是我们的试验田。超载需求做出来
= 用户服务器卡死,比不做更糟。

**判级**(拿不准就往重了算):

| 信号 | 判级 |
|---|---|
| 常驻内存需求 > 服务器空闲内存的 1/3 | **拒绝**,给降级方案 |
| 轮询频率 < 10s 或单次 exec > 5s | **偏重**,列风险清单等同意 |
| 需要编译/训练/跑模型/全盘扫描 | 基本都是**拒绝**级,除非用户明确知道自己在干什么 |
| 普通查看/通知/分钟级轮询 | **轻量**,直接做 |

**风险清单怎么写**(大白话,别堆术语):说清"会占多少""会拖慢什么""坏了会怎样"三件事。
例:"这个插件每 10 秒查一次 GPU,大约多吃 2% CPU;服务器现在内存只剩 1G,插件常驻约再吃 100M,
如果同时跑训练可能挤爆内存导致任务被杀。要继续吗?"

**红线**:用户不同意就不做,不改口不磨;降级方案要具体(别只说"做个轻量版")。

## 2. 契约速查(与 `src/core/contract/types.ts` CI 对账,漂移即红)

能力 op 全集(manifest.capabilities 从这里选,用了什么声明什么):

<!-- contract:ops -->
| op | 用途 |
|---|---|
| `subscribe` | 订阅流:terminalOutput / agentEvents / fileEvents / tick(定时心跳,熄屏可活;轮询件定节奏**只用它**,别自己 setTimeout——熄屏 JS 定时器会被冻结) |
| `read` | 一次性读:listDir / readFile / readFileRange(大文件分段) |
| `write` | 动作:stdin / resolveApproval / createDir / writeFile / rename / deleteFile / createTerminal / deleteTerminal |
| `notify` | 两形状:trigger(manifest.triggers,平台评估,插件零代码)/ immediate(代码里当场弹,前台 toast、后台/熄屏系统通知,L2 轮询件的主流出口) |
| `exec` | 在被控机执行命令(受 permissions.execCommands 白名单,高危;返回 `{stdout,stderr,exitCode}`,**失败不抛错、自己判 `exitCode === 0`**;白名单按**首 token 程序名**精确匹配。选采数通道/read 沙箱边界/白名单逃逸警示 → `references/ui-cheatsheet.md`「采数通道速查」) |
| `request` | 请平台跑通用流程:saveToServer(把文件交给保存流) |
<!-- /contract:ops -->

scope(作用域,三选一):

<!-- contract:scopes -->
| scope | 含义 |
|---|---|
| `global` | 不绑服务器(全局件) |
| `server` | 绑一台被控机 |
| `terminal` | 绑一个终端 |
<!-- /contract:scopes -->

- **声明是上限,实际 ctx.scope 可能收窄**:声明 `server` 的插件,在 sessions 会话组件里实际拿到
  terminal 级(`{kind:'terminal', serverId, terminalId}`)。把 `ctx.scope` 原样传回能力调用永远无害;
  但**别按 `scope.kind` 写分支逻辑**——session 场景下它不是你声明的那个值。

触发器 when(L1 的全部表达力;平台评估,事件来自 agentEvents):

<!-- contract:whens -->
| when | 语义 |
|---|---|
| `agentResult` | agent 一轮收尾(turn-end);pattern 可叠加 regex 过滤(如只报失败) |
| `approvalPending` | 到达审批请求(canUseTool blocking) |
| `idle` | idleSec 秒无事件(卡住提醒) |
| `regex` | 事件 JSON 命中 pattern(自由兜底) |
<!-- /contract:whens -->

- 标题/正文支持 `{{field}}` 插值(取事件扁平字段,如 `{{tool}}`、`{{status}}`)。
- **前端/后台分派**:app 在前台 → toast;后台/熄屏 → 系统通知。插件不用管。

图标名全集(manifest.icon 从这里挑,registry 在 `src/components/shared/PluginIcons.tsx`,CI 对账):

<!-- contract:icons -->
| 图标 | 适用 |
|---|---|
| `bell` | 提醒/通知类 |
| `gauge` | 监控面板/仪表 |
| `activity` | 资源监控/脉搏波形 |
| `cpu` | CPU/硬件 |
| `calendar` | 日历/日程/定时 |
| `clock` | 时间/倒计时 |
| `terminal` | 终端/命令行 |
| `file` | 文件/文档 |
| `folder` | 目录/文件管理 |
| `database` | 数据库/存储 |
| `wifi` | 网络/连通性 |
| `message` | 聊天/消息 |
| `shield` | 安全/防护 |
| `search` | 搜索/查找 |
| `download` | 下载/获取 |
| `image` | 图片/相册 |
| `music` | 音乐/音频 |
| `zap` | 快速/自动化/一击 |
| `chart` | 图表/统计/报表 |
| `globe` | 网站/全球/站点 |
| `bot` | AI/机器人 |
| `camera` | 拍摄/截屏 |
| `puzzle` | 通用插件(拿不准时) |
| `claude` | CC 相关 |
| `md` | Markdown 相关 |
| `json` | JSON 相关 |
| `apk` | 安装包相关 |
| `scan` | 扫码/扫传 |
<!-- /contract:icons -->

- **icon 必填**(2026-08-27 用户反馈:不许空白图标)。从上表挑语义最贴的;实在没有贴切的
  就填 `puzzle`,**不许留空、不许自造名字** —— 名字是联合类型(`PluginIconName`),仓内拼错
  编译期就红;工坊件拼错渲染成"首字字母头像"(能用但难看),留空则什么都不显。
- **不要联网搜 SVG / 不要自己画 path 塞进 manifest**(版权/断网/夹带脚本三个硬伤)。

### 自动刷新件标准配方(断流自测;2026-09-30 沉淀,sys-monitor v0.2.2~v0.2.4 三轮真机排障换来的)

数据流(tick/订阅)会**静默死亡**(熄屏冻结、桥抖动),而宿主暂不推「流停了」信号
(流活性 seq/stalled 是平台加菜候选,**升级触发器:第二个需要自动刷新的插件出现时升契约**;
在那之前别在插件层各造各的观测,照抄这套):

1. **收到 chunk 就碰心跳**:`setLastTickAt(Date.now())` —— 唯一探测点,别自己数节奏;
2. **双时钟**:另设 1s 的「秒针」effect 只看表不产数据(熄屏冻结恢复后它自己追上);
3. **超时即显**:超过 ~3 个周期没心跳 → 界面出「数据已断流」横幅 + `ctx.health?.report(['自动刷新已断流'])`;心跳恢复 → 清横幅 + `report([])`;
4. **降级诚实**:`ctx.health` 是可选字段(老宿主可能没有),一律 `ctx.health?.` 调用 —— 上报不进去时界面横幅还在,观测不丢。

UI 贡献点 / 采数通道 / 共享组件三张扩展速查(均带 CI 对账区)→ `references/ui-cheatsheet.md`,
触发条件见页首「渐进加载」。

## 2.5 会话与入口声明(打标规则全集,2026-09-28;造 L3 会话件必读)

manifest 是插件的**身份卡**:平台(工坊/文件树/任务列表/「+」菜单)不认识任何插件,
**全靠 manifest 上的标路由**。标打错 = 入口全错(进错菜单/不进菜单/被当错形态)。
**一个标都不是白打的 —— 下面每个标都对应平台的一个具体行为。**

### 会话四标(contributes.sessions[] 上,全部可选,默认 false)

| 标 | 声明什么 | 平台行为(打了对它意味着什么) | 典型 |
|---|---|---|---|
| `agent: true` | 本会话是「编码智能体会话」(对话式 coding agent) | 工坊「选择打开方式」的智能体清单收录(用户备好插件目录后挑智能体进去干活);**与 openExtensions 互斥**(文件接管型的创建=新建文件,不进工坊清单) | CC 对话;未来的 codex 对话件 |
| `folderBound: true` | 本会话「在某个文件夹里干活」(该文件夹=它的项目) | **同时**进文件树底部「＋创建」菜单(在该目录建会话,cwd=目录;有固定 cwd 用固定的);「+」菜单照旧保留(双入口,同终端先例) | CC 对话 |
| `openExtensions: ['ipynb']` | 文件树点开这些扩展名 = 建/切本会话(经 SessionProps.openPath 带入文件路径) | 接管这些扩展名的「点开」(不再进文件 tab);同文件再点=切已有会话;**不进「+」菜单**(文件树是唯一入口,空会话无意义);组件须按 openPath 直开 | jupyter-ide 接管 .ipynb |
| `ide: true` | 本会话是 IDE 会话(可执行/调试的文档工作区) | 任务列表归「IDE」组(独立分区);tab 栏蓝左条;关闭菜单按 IDE 语义定制(内核保留文案) | jupyter-ide |

另外两个会话字段(非布尔,同样重要):

- `singleton: true` = 全局(本 server)只许一份:「+」菜单点它时已存在 → 不新建直接切。
  双开有害的工具型会话用(扫传双开会抢相机;监控双开双倍轮询)。**普通可多开件别打**(CC 多项目多会话)。
- `cwd: '相对路径'` = 会话固定启动目录(相对 jupyter root):「会话天生绑某个项目」才用;
  用户当前浏览到哪不应影响它。绝大多数插件**不要**写它。

### 入口总纲(两入口两语义,2026-09-27 用户定规)

- **「+」菜单**(主屏右上)= 建**任务页**(无文件夹归属):终端/扫传/监控…;不声明 openExtensions 的会话默认都在。
- **文件树底部「＋创建」**(目标文件夹内)= 建**绑这个文件夹的东西**:终端(cwd=此夹)/文件夹/上传/
  fileCreates 模板文件/folderBound 会话。
- **判据一句话**:我的插件「在某个文件夹里干活」吗?是 → folderBound;绑的是**固定机器目录**(如工坊根)而非当前文件夹 → **不打**(工坊就是因此撤出的);纯手机/全局工具 → 不打。

### fileCreates(文件创建贡献点,与 openExtensions 配套)

`contributes.fileCreates: [{ id, entry, label, extension, icon? }]` —— 文件树「＋创建」菜单出现
「新建 XXX」项;entry 指向 main.tsx 同名导出的**模板工厂** `() => string`(返回新文件完整内容);
创建后自动走文件打开总入口(声明了 openExtensions 的扩展名 → 直开会话)。jupyter-ide 的
「新建 Jupyter 笔记本」即此(nbjformat 骨架模板)。**core 只写盘+打开,模板内容全在插件。**

### 形态 → 打标速查(造件时对号入座)

| 你要造的插件 | 打的标 |
|---|---|
| 编码智能体对话(像 CC) | `agent` + `folderBound` |
| IDE/可执行文档(像 jupyter) | `ide` + `openExtensions` + `fileCreates`(模板) |
| 工具型会话(双开有害:相机/监控) | `singleton`(仅此) |
| 普通会话面板(可多开) | 一个标都不打 |
| 文件查看/动作件(非会话) | 不适用本节(fileViewers/fileActions,见 ui-cheatsheet) |
| 后台件(L1/L2,无 UI) | 不适用本节(无 sessions) |

### 红线

- **标是给平台读的纯数据**,别在插件代码里读自己的标写逻辑(平台行为,轮不到你)。
- **openExtensions 与 agent 互斥**(文件接管型的入口=文件树,不进工坊智能体清单)。
- 标**只加不改**(semver):新增标=minor;改标的含义=major,别干。
- 拿不准打不打 → **不打**(少个入口无伤,错个入口误导)。

## 3. 三档模板(→ `references/templates.md`,只读分档命中那一节)

- **L1**:纯 manifest 触发器,零代码(cc-done-remind 范例)。
- **L2**:lifecycle 钩子 + exec 轮询 + notify immediate(cpu-alert 范例;tick 节奏/速率窗/inFlight 岗哨三注)。
- **L3 会话页**:contributes.sessions(sys-monitor 范例;无需 lifecycle、useEffect 订阅/退订、singleton 判断表);
  **L3 查看器**:contributes.fileViewers(仿 text-view)。
- **测试底线**(L2/L3):fake ctx 片段 + import 豁免 + 范例文件,都在同文件末节。

## 4. 红线(踩了 CI 直接红 / 装不上)

1. **只 import `@core/contract` + `@core/shared`**,禁碰 core 内部(ESLint 强制)。
   **测试文件豁免**:校验/升级路径测试可 import `@/core/plugin/externalPlugins`
   (`validateExternalManifest`)与 `@core/shared`(`describeInstallConflicts`),
   见 `references/templates.md`「测试底线」。
2. **manifest 纯数据**:禁止组件/函数对象(`component:`、`icon: Component`);entry 用字符串。
3. **id 小写 kebab-case;version 必须 x.y.z**。
4. **capabilities 与实际使用一致**:没声明就调 → 运行时拒;声明了不用 = 审计噪音。
5. **exec 是高危**:execCommands 白名单最小化(只列真正要跑的程序名);路径敏感件(.env/.ssh/密钥)ALWAYS-DENY,声明 `/**` 也读不到。
6. **UI 只用 `@core/shared` 组件 + 主题 token**,别写死颜色/字号。
   **样式只用清单内的类**:宿主 CSS 是编译期产物,**清单外的类静默退化不报错、只是丑**
   (一线报告§三)。写 UI 前查 `.claude/skills/plugin-workshop/safe-classes.txt`(一行一类,
   从宿主产物 CSS 提取);打包时脚本会核对并警告清单外的类 —— 警告=改,别硬交付。
7. **wasm 资产不支持**(打包是自包含单文件;qr-receive 式 `wasm?url` 会被排除)。

## 5. 自检命令(开局先跑 check-env;按结论跑,缺席明说)

```bash
node scripts/check-env.mjs                        # ① 开局体检:可打包?SDK 齐不齐?tsc/vitest 在不在?
node scripts/build-plugin.mjs <id> --with-source  # ② 硬闸:出 dist/plugins/<id>.ceplugin(样式警告也看这里)
npx vitest run plugins/<id>                       # ③ vitest 可用才跑(仓内开发是 src/plugins/<id>)
```

- ② 是唯一**必过**项;③ 和 tsc 类型检查**可用才跑**,缺席如实标注「跳过(本机未装)」——
  假装跑过比跳过严重得多(交付可信度是工坊的命)。
- **红线:不要跑全仓 `npm test`**(那是 app 平台自身的 1300+ 用例回归,插件任务跑它是浪费时间、
  还会在完工汇报里制造"1302 项全过"这种吓人噪音 —— 你不对整个 app 的质量负责)。

## 6. 执行层防坑(AI 自己的坑,与插件设计无关但每次都浪费时间)

1. **CodeGraph 索引冻结时别绕路**:报 "auto-sync DISABLED" 就立刻 fallback 直接读文件,
   别换个姿势再查第二轮(白跑)。
2. **验证 .ceplugin 工件别猜格式**:工件是 `{format, manifest, bundle}` 包一层,**不是**裸
   manifest JSON。验证要么用平台 `parseArtifact`,要么先看 `scripts/build-plugin.mjs`
   的输出长什么样。
3. **Edit 的 old_string 逐字对照原文件再发**:全角/半角标点、"三路/四路"这类新旧文案混写
   会直接 miss 返工。

## 6. 声明文件 + 安装层级 + 检测门禁 + 源码包 + 健康上报(2026-08-28 定约,2026-09-25 升级)

1. **安装层级(必填判定,2026-09-25)**:先回答一个问题 —— **被控机要不要额外装东西**?
   - 要(某命令/包/服务必须在主机上,如 `claude`、`top`、jupyter)→ `installLevel: 'server'`
     (**服务器级**:每台被控机显式安装,安装前过环境检测门禁;检测挂会被拦下);
   - 不要(纯手机侧能力或只用 ce 自带的文件读写通道)→ `installLevel: 'global'`
     (**全局级**:装一次全服务器通用)。
   - 判据不是"碰不碰主机":Python 编辑器读写主机文件但主机零依赖 → global;判据只有"额外装东西"。
2. **服务器级产物必填四件**(全局件免 platform/requirements,其余仍必填):
   - `installLevel: 'server'`;
   - `platform`:支持的平台数组,如 `['linux','darwin']`(只填真能跑的);
   - `requirements`:**结构化检测声明**(安装门禁逐项验证;声明式优先,别上来就用脚本):
     ```ts
     requirements: [
       { check: 'binary', name: 'claude' },              // 命令存在(which)
       { check: 'pip', pkg: 'pandas', minVersion: '2.0' },// Python 包(可带最低版本)
       { check: 'path', glob: '/data/*.ipynb' },          // 文件存在(单层 *;** 不支持)
       { check: 'port', host: '127.0.0.1', port: 8888 },  // 端口可达
       { check: 'script', command: 'python3 check.py' },  // 逃生舱:exit 0=过;首 token 必须在
     ]                                                    // permissions.execCommands 白名单里
     ```
     旧字符串档(`requirements: ['top']`)只展示不检测 —— 新产物一律写结构化;
   - `iconSvg`(可选但推荐):svg 源码字符串(商店显示自有图标;不填则用 `icon` 图标名)。
3. **manifest 环境声明(必填意识)**:`environment`(开发环境)、`knownIssues`(已知坑/兼容边界,
   如 win 专属能力 Linux 不可用)。全部诚实披露,随工件走。
4. **源码包(可选授权)**:`node scripts/build-plugin.mjs <id> --with-source` 随工件携带源码 = **同意他人修复/改造**;不带 = 纯使用。交付时问用户要不要带。
5. **健康上报(ctx.health,2026-09-30 契约化)**:插件有降级/异常时调
   `ctx.health?.report(['…'])`(恢复即 `report([])`),宿主「插件修复」入口据此显隐。
   旧写法(直写 `window.__CE_PLUGIN_STATUS__`)仍兼容 —— 老宿主没有 ctx.health 时用它兜底。
6. **修复对话诚实原则**:被报修时,本机实现不了 → 坦诚说不能;能实现但要装包/库 → 列清单由用户决策,**绝不擅自安装**。

## 7. 工坊自举与依赖(2026-08-28)

- 新被控机的工坊环境由**首条初始化消息**携带脚手架(技能/打包脚本/bootstrap/package.json):按原样保存到指定根目录,然后**自己执行 npm install**(esbuild/react 是打包依赖,本机跑,不问用户)。装完先跑 `node scripts/check-env.mjs` 体检,再开工。之后造件/打包全走本地。
- 打包命令:node scripts/build-plugin.mjs <id> [--with-source];交付工件到用户指定路径。
