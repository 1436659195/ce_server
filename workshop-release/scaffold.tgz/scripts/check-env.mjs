#!/usr/bin/env node
/**
 * 工坊环境体检 —— 开局先跑我,按结论干活(2026-09-30 一线报告§一/§二落地)。
 *
 * 为什么:章程承诺的能力要环境兑现才算数。瘦身 SDK 曾带着断链上架(打包 0 工件)、
 * 自检工具在本机缺席而章程让跑 —— 执行者被迫在「假装三绿」和「卡死」之间二选一。
 * 本脚本把事实一次说清:布局在哪、SDK 齐不齐、自检工具哪些可用,并给结论。
 *
 * 结论:退出码 0 = 可打包(esbuild + SDK 关键件齐);1 = 不可打包(缺什么印出来)。
 * 自检工具(tsc/vitest/eslint)缺席**不算**不可打包 —— 只是该项自检降级,交付时如实标注。
 *
 * 用法:cd <工坊根> && node scripts/check-env.mjs
 */
import { existsSync, readdirSync, statSync } from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const root = path.resolve(fileURLToPath(import.meta.url), '../..');
const problems = [];
const notes = [];
const check = (ok, okLine, badLine) => {
  if (ok) console.log(`  ✓ ${okLine}`);
  else {
    console.log(`  ✗ ${badLine}`);
    problems.push(badLine);
  }
};

console.log(`工坊根: ${root}`);

// ── ① 打包硬依赖:esbuild ──────────────────────────────────────────────────
console.log('\n[1/4] 打包硬依赖');
let esbuild = false;
try {
  await import('esbuild');
  esbuild = true;
} catch {
  /* 下面报 */
}
check(esbuild, 'esbuild 可用(打包器)', 'esbuild 不可用 —— 跑 npm install 装依赖,否则无法打包');

// ── ② 插件布局(双目录,与 build-plugin.mjs 同口径)────────────────────────
console.log('\n[2/4] 插件布局');
/** 有 manifest.ts 的插件 id 列表(仓内布局 src/plugins / 工坊机布局 plugins)。 */
function discoverIds(rel) {
  const dir = path.join(root, rel);
  if (!existsSync(dir)) return null;
  return readdirSync(dir, { withFileTypes: true })
    .filter((d) => d.isDirectory() && existsSync(path.join(dir, d.name, 'manifest.ts')))
    .map((d) => d.name)
    .sort();
}
const inSrc = discoverIds('src/plugins');
const inPlugins = discoverIds('plugins');
const ids = [...new Set([...(inSrc ?? []), ...(inPlugins ?? [])])].sort();
if (ids.length === 0) {
  check(false, '', '两个候选目录(src/plugins、plugins)都没发现带 manifest.ts 的插件 —— 先建插件目录');
} else {
  console.log(`  ✓ 发现插件 ${ids.length} 个: ${ids.join(', ')}`);
  if (inSrc?.length) console.log(`    - src/plugins: ${inSrc.join(', ')}`);
  if (inPlugins?.length) console.log(`    - plugins:    ${inPlugins.join(', ')}`);
}

// ── ③ SDK 关键件(瘦身断链史:缺一个 = 打包必炸)──────────────────────────
console.log('\n[3/4] SDK 关键件');
for (const rel of [
  'src/core/shared/index.ts', // @core/shared 瘦身索引
  'src/core/contract/index.ts', // @core/contract 入口
  'src/core/plugin/iframe/bootstrap.tsx', // 自举运行时
  'src/components/feedback/Toaster.tsx', // bootstrap 闭包
  'src/core/shared/downloadHistory.ts', // download 闭包
  'src/core/plugin/iframe/cap-stubs/capacitor-filesystem.ts', // @capacitor 打包桩
]) {
  check(existsSync(path.join(root, rel)), rel, `${rel} 缺失 —— SDK 断链,打包大概率挂;让平台维护者重打集装箱`);
}
// 知识件(缺失不挡打包,提醒补)
for (const rel of [
  '.claude/skills/plugin-workshop/SKILL.md', // 造件手册
  '.claude/skills/plugin-workshop/safe-classes.txt', // 可用样式清单(UI 件)
]) {
  check(existsSync(path.join(root, rel)), rel, `${rel} 缺失(知识件,不挡打包)—— 让平台维护者重打集装箱`);
}

// ── ④ 自检工具(缺席 = 对应自检降级,不算不可打包)────────────────────────
console.log('\n[4/4] 自检工具(缺席就明说「跳过」,不装、不假装)');
const bin = (name) => existsSync(path.join(root, 'node_modules', '.bin', name));
const tsc = bin('tsc');
const vitest = bin('vitest');
const eslint = bin('eslint');
check(tsc, 'tsc(类型检查)可用 → 自检跑它', 'tsc 未装 → 交付说明如实标注「类型检查跳过(本机未装)」');
check(vitest, 'vitest(测试)可用 → 自检跑它', 'vitest 未装 → 交付说明如实标注「测试跳过(本机未装)」');
check(eslint, 'eslint(import barrier)可用 → 自检跑它', 'eslint 未装 → import 边界靠自律:只 import @core/contract + @core/shared');
for (const [name, has] of [['tsc', tsc], ['vitest', vitest], ['eslint', eslint]]) {
  if (has) notes.push(`${name} ✓`);
}

// ── 结论 ────────────────────────────────────────────────────────────────
console.log('\n== 结论 ==');
// 硬伤 = esbuild 缺 / 无插件 / SDK 断链;知识件缺失与自检工具缺席都只是提醒
const hard = problems.filter((p) => p.includes('SDK 断链'));
if (!esbuild || ids.length === 0 || hard.length > 0) {
  console.log('可打包:否 —— 先解决上面的 ✗ 再开工');
  if (!esbuild) console.log('  - esbuild 不可用');
  if (ids.length === 0) console.log('  - 没有可打包的插件');
  for (const p of hard) console.log(`  - ${p}`);
  process.exit(1);
}
console.log(`可打包:是 —— node scripts/build-plugin.mjs <id> --with-source`);
console.log(`自检能力: ${notes.length ? notes.join(' / ') : '全缺席(只能打包验证;交付说明里逐项标注跳过)'}`);
