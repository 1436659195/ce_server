#!/usr/bin/env node
/**
 * 插件打包脚本（P0 交付管线 · 被控机侧）
 *
 * 输入  插件目录(双布局自动发现,2026-09-30:仓内 src/plugins/<id> / 工坊机 plugins/<id>,
 *       有 manifest.ts 即是 —— 同一份脚本两处跑零改动;一线报告§二「三方不同步」的根治)
 * 输出  dist/plugins/
 *         <id>.bundle.js   自包含自举 IIFE(React/@core 全内联;spike/开发直连 iframe 用)
 *         <id>.ceplugin    **安装工件**(单文件 JSON):{ format, manifest, bundle, sha256 }
 *                          —— 长按「安装插件」吃的就是它(Q3:与 apk-installer 同模式;
 *                          Q2:sha256 安装时校验,防传输损坏)
 *
 * 为什么"自举":bundle 不只是导出组件,而是加载后自己跑起来 —— 内联的 iframe bootstrap
 * 会建 ctx(rpc 走 postMessage)、等宿主发 init、渲染 entry。iframe 里 <script src=bundle>
 * 一执行插件就活了。插件源码一行不改(仍是普通插件),bootstrap 是宿主注入的运行时。
 *
 * 关键点:
 *   - 生成"自举入口"(临时 <id>.entry.tsx):import 插件 main + 调 ceIframeBoot。
 *     临时件写 os.tmpdir() 且 finally 必清(2026-09-30:此前写在 dist 且失败路径不清理,
 *     失败现场留垃圾,一线报告§六-1)。
 *   - manifest 提取:esbuild 把 manifest.ts 编成临时 ESM 再 import(类型导入已擦除,
 *     无运行时依赖),取第一个 {id,version} 形状的导出 → 装进安装工件。
 *   - `@core`/`@` 是 Vite 别名,靠 esbuild 原生 alias 映射(@core 在前,对齐 vite.config)。
 *   - jsx: 'automatic'(React 18);format: 'iife'(单文件、无模块解析,iframe 直接跑最省心)。
 *   - 源码包(--with-source)排除 CLAUDE.md/AGENTS.md:章程由 app 亲自落盘并随优化/修复
 *     重新生成,源码包带回会把旧章程盖在新章程上(2026-09-30)。
 *   - 可用样式核对(工坊机):根下带 safe-classes.txt 时扫插件源码的 className,清单外的
 *     类打警告不挡 —— 宿主 CSS 是编译期产物,清单外的类**静默退化**只是丑不报错
 *     (一线报告§三;清单由 APK 构建时 scripts/extract-safe-classes.mjs 从产物 CSS 提取)。
 *
 * 用法:
 *   node scripts/build-plugin.mjs              # 打全部插件(自动发现)
 *   node scripts/build-plugin.mjs text-view    # 只打指定插件
 *   node scripts/build-plugin.mjs --out /tmp/p # 指定输出目录(测试用)
 */
import { build } from 'esbuild';
import { createHash } from 'node:crypto';
import { fileURLToPath, pathToFileURL } from 'node:url';
import { tmpdir } from 'node:os';
import path from 'node:path';
import fs from 'node:fs';

const root = path.resolve(fileURLToPath(import.meta.url), '../..');

// ─── 参数:插件 id 列表 + --out 覆盖输出目录 ────────────────────────────────
const argv = process.argv.slice(2);
const outIdx = argv.indexOf('--out');
const outDirArg = outIdx >= 0 ? argv[outIdx + 1] : undefined;
if (outIdx >= 0) argv.splice(outIdx, 2);
// --with-source:随工件携带源码包 = 开发者授权「他人可修复/改造」;不带 = 纯使用,无修复入口
const withSource = argv.includes('--with-source');
if (withSource) argv.splice(argv.indexOf('--with-source'), 1);
const outDir = outDirArg ? path.resolve(outDirArg) : path.join(root, 'dist/plugins');

// ─── 插件发现(双布局)────────────────────────────────────────────────────
// 排除:qr-receive —— 它用 Vite 专有的 `wasm?url` 资产引法,与"自包含单文件"冲突;
// wasm 资产插件要走单独的资产打包策略(P1 议题,工坊生成件暂不含 wasm)。
const EXCLUDED = new Set(['qr-receive']);
const PLUGIN_DIRS = ['src/plugins', 'plugins'];

/** id → 插件目录绝对路径(双布局就近解析;两处都有时仓内优先)。 */
function pluginDirOf(id) {
  for (const rel of PLUGIN_DIRS) {
    const dir = path.join(root, rel, id);
    if (fs.existsSync(path.join(dir, 'manifest.ts'))) return dir;
  }
  return null;
}

/** 全部插件 id(双目录合并去重排序;不硬编码清单,新插件免改脚本)。 */
function discoverPlugins() {
  const ids = new Set();
  for (const rel of PLUGIN_DIRS) {
    const dir = path.join(root, rel);
    if (!fs.existsSync(dir)) continue;
    for (const d of fs.readdirSync(dir, { withFileTypes: true })) {
      if (d.isDirectory() && fs.existsSync(path.join(dir, d.name, 'manifest.ts'))) ids.add(d.name);
    }
  }
  return [...ids].filter((id) => !EXCLUDED.has(id)).sort();
}

/** 插件目录里的源码文件(排除测试/章程;源码包与样式核对共用一份名单)。 */
function sourceFiles(dir) {
  const walk = (d, prefix = '') =>
    fs
      .readdirSync(d, { withFileTypes: true })
      .flatMap((e) =>
        e.isDirectory()
          ? walk(path.join(d, e.name), `${prefix}${e.name}/`)
          : [[`${prefix}${e.name}`, path.join(d, e.name)]],
      );
  return walk(dir).filter(
    ([p]) =>
      !p.startsWith('__tests__/') &&
      !/\.test\.(t|j)sx?$/.test(p) &&
      p !== 'CLAUDE.md' &&
      p !== 'AGENTS.md', // 章程由 app 亲自落,不随源码包回带
  );
}

// ─── 可用样式核对(工坊机才有清单;仓内开发跳过)──────────────────────────
/** safe-classes.txt → Set(一行一类;APK 构建时从产物 CSS 提取)。 */
function loadSafeClasses() {
  const p = path.join(root, '.claude/skills/plugin-workshop/safe-classes.txt');
  if (!fs.existsSync(p)) return null;
  return new Set(
    fs
      .readFileSync(p, 'utf8')
      .split('\n')
      .map((l) => l.trim())
      .filter(Boolean),
  );
}

/** 粗提源码 className 的 token(模板串只取静态段;动态拼接本就有误报,警告不挡)。 */
function classNameTokens(text) {
  const tokens = [];
  for (const m of text.matchAll(/className=\{?[`'"]([^`'"`]*)[`'"]/g)) {
    tokens.push(...m[1].replace(/\$\{[^}]*\}/g, ' ').split(/\s+/));
  }
  return tokens.filter((t) => /^[a-zA-Z][^\s'"`{}]*$/.test(t));
}

const ALL = discoverPlugins();
const ids = argv.length ? argv : ALL;
const unknown = ids.filter((id) => !ALL.includes(id));
if (unknown.length) {
  console.error(`✗ 未知插件: ${unknown.join(', ')}(可用: ${ALL.join(', ')})`);
  process.exit(1);
}

fs.mkdirSync(outDir, { recursive: true });

// 本轮全部中间件进临时目录;无论成败 finally 必清(dist 里永远只剩交付物)
const tmp = fs.mkdtempSync(path.join(tmpdir(), 'ce-plugin-build-'));
const safeClasses = loadSafeClasses();

try {
  for (const id of ids) {
    const dir = pluginDirOf(id);
    const mainAbs = path.join(dir, 'main.tsx');
    const manifestAbs = path.join(dir, 'manifest.ts');
    // L1 纯触发器(D4):无 main.tsx = 零代码零 bundle,manifest 即全部。
    // 工件仍按同一 format:1 出(bundle='',sha=空串摘要),安装路径与 L2/L3 完全一致(Q5 定稿)。
    const isL1 = !fs.existsSync(mainAbs);

    // 0) 可用样式核对(先于打包;与成败无关,清单外类提醒插件作者)
    if (safeClasses) {
      const unknownClasses = new Set();
      for (const [p, abs] of sourceFiles(dir)) {
        if (!/\.(t|j)sx?$/.test(p)) continue;
        for (const t of classNameTokens(fs.readFileSync(abs, 'utf8'))) {
          if (!safeClasses.has(t)) unknownClasses.add(t);
        }
      }
      if (unknownClasses.size) {
        console.warn(
          `⚠ ${id}: 这些类宿主 CSS 可能没有(清单外 → 静默退化只是丑): ${[...unknownClasses].slice(0, 12).join(' ')}${unknownClasses.size > 12 ? ' …' : ''}`,
        );
      }
    }

    // 1) 生成"自举入口":把插件 main 和 iframe 运行时 bootstrap 绑在一起(L1 无 main,跳过)
    const entryPath = path.join(tmp, `${id}.entry.tsx`);
    const bundlePath = path.join(outDir, `${id}.bundle.js`);
    if (!isL1) {
      fs.writeFileSync(
        entryPath,
        [
          `import * as plugin from '${mainAbs}';`,
          `import { ceIframeBoot } from '@core/plugin/iframe/bootstrap';`,
          `ceIframeBoot(plugin as Record<string, unknown>);`,
          '',
        ].join('\n'),
      );

      // 2) 打包成自包含 IIFE
      await build({
        entryPoints: [entryPath],
        bundle: true,
        format: 'iife',
        platform: 'browser',
        target: ['es2020'],
        jsx: 'automatic',
        outfile: bundlePath,
        define: { 'process.env.NODE_ENV': '"production"' },
        // esbuild 原生 alias(对齐 vite.config.ts):@core → src/core,@ → src(@core 在前防误吞)
        alias: {
          '@core': path.join(root, 'src/core'),
          '@': path.join(root, 'src'),
          // Capacitor 桩:外部插件跑 iframe,真桥在宿主 —— 工件不得打包第二份假 @capacitor
          // (真机实证:apk-installer 工件的 Filesystem 调用挂死,下载进度恒 0)。
          '@capacitor/core': path.join(root, 'src/core/plugin/iframe/cap-stubs/capacitor-core.ts'),
          '@capacitor/filesystem': path.join(root, 'src/core/plugin/iframe/cap-stubs/capacitor-filesystem.ts'),
          '@capacitor/share': path.join(root, 'src/core/plugin/iframe/cap-stubs/capacitor-share.ts'),
        },
        loader: { '.tsx': 'tsx', '.ts': 'ts' },
        logLevel: 'warning',
      });
    }

    // 3) manifest 编成临时 ESM → import → 取 {id,version} 形状的导出
    const manifestJsPath = path.join(tmp, `${id}.manifest.mjs`);
    await build({
      entryPoints: [manifestAbs],
      bundle: true,
      format: 'esm',
      platform: 'neutral',
      outfile: manifestJsPath,
      alias: {
        '@core': path.join(root, 'src/core'),
        '@': path.join(root, 'src'),
      },
      loader: { '.tsx': 'tsx', '.ts': 'ts' },
      logLevel: 'warning',
    });
    const mod = await import(pathToFileURL(manifestJsPath).href);
    const manifest = Object.values(mod).find(
      (v) =>
        typeof v === 'object' &&
        v !== null &&
        typeof v.id === 'string' &&
        typeof v.version === 'string',
    );
    if (!manifest) {
      console.error(`✗ ${id}: manifest.ts 里找不到 {id,version} 形状的导出`);
      process.exit(1);
    }

    // 4) 产出安装工件 .ceplugin(单文件:manifest + bundle + sha256 [+ source])
    const bundle = isL1 ? '' : fs.readFileSync(bundlePath, 'utf8');
    const sha256 = createHash('sha256').update(bundle).digest('hex');
    const artifactPath = path.join(outDir, `${id}.ceplugin`);
    let source;
    if (withSource && !isL1) {
      source = sourceFiles(dir).map(([p, abs]) => ({ path: p, content: fs.readFileSync(abs, 'utf8') }));
    }
    fs.writeFileSync(
      artifactPath,
      JSON.stringify({ format: 1, manifest, bundle, sha256, ...(source ? { source } : {}) }),
    );

    const kb = (n) => `${(n / 1024).toFixed(0)}KB`;
    console.log(
      isL1
        ? `✓ ${id} → ${id}.ceplugin(${kb(fs.statSync(artifactPath).size)},L1 manifest-only)`
        : `✓ ${id} → ${id}.bundle.js(${kb(bundle.length)}) + ${id}.ceplugin(${kb(fs.statSync(artifactPath).size)})`,
    );
  }

  // 输出目录可提交提示(仅默认目录;--out 是测试临时目录,免噪音)
  if (!outDirArg) {
    console.log(`目录: ${outDir}(被控机上发给手机任意可达位置即可)`);
  }
} finally {
  fs.rmSync(tmp, { recursive: true, force: true });
}
