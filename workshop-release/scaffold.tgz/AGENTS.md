# 插件工坊(codex 入口)

本工坊的造件规范全文在 `.claude/skills/plugin-workshop/SKILL.md`(Claude Code 的 skill 入口)。
你是 codex:**开工前先完整读该文件**,严格按其工作流执行 —— 资源评估 → 查重 → 分档
(L1 纯通知 / L2 后台件 / L3 界面件,能低不高)→ 按模板生成 → 自检(tsc + 本插件测试)
→ `node scripts/build-plugin.mjs <id> --with-source` 打包交付。

手机 app 交互注意:用户在手机上远程指挥你(输入慢、屏幕小),回复要短、分段、说人话;
大段代码写进文件再总结,不要贴在对话里。分档拿不准就问一句「需要界面吗,还是通知就够?」。
